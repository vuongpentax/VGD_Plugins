# VGD Image Importer — bàn giao

Ngày 05/10/2026, phiên bản 1.1.0-beta.1. Nguồn gốc: `%APPDATA%/SketchUp/SketchUp 2022/SketchUp/Plugins/vgd_image_importer.rb` và folder cùng tên (bản 1.0.0). Snapshot nguyên bản ở `reference/`.

## Cấu trúc

- `runtime/vgd_image_importer.rb`: đăng ký extension, version, namespace cũ `VGD_ImageImporter`.
- `engine.rb`: validation, nguồn ảnh, tính kích thước theo inch nội bộ, tạo component/vật liệu, bố trí, operation và kết quả.
- `main.rb`: singleton HtmlDialog, callback `vgd_importer`, JSON settings, chọn file/folder, toolbar/menu.
- `dialog.html/css/js`: UI tiếng Việt, màu và control theo VGD Scenes; CSS không dùng các tính năng Chromium mới như color-mix. Theme và settings được ghi qua Sketchup defaults; khóa localStorage `vgd.theme` dùng làm fallback lúc mở trang, không phải bus đồng bộ theme trực tiếp giữa plugin.
- `icon.svg`: toolbar VGD mới; `vgd_icon.png` giữ icon gốc để tương thích/snapshot và dùng làm dữ liệu test.
- `dev/`: fixture Ruby và kiểm tra UI, đóng gói RBZ/source ZIP, deploy chính xác file có backup.

## Quy tắc tiếp tục

Giữ đường dẫn loader và namespace để nâng cấp tại chỗ. Không sửa hoặc deploy các plugin VGD khác. Vật liệu nhập phải tạo mới, không đổi texture của material sẵn có. Số ảnh mỗi hàng tính theo ảnh nhập thành công. Khi tất cả ảnh lỗi, abort operation. Không thay model/selection để kiểm tra tự động trên file người dùng.

Tăng version ở loader và package.json trước release. Chạy `node dev/check_ruby.cjs`, `node dev/test_ui.cjs`, rồi `node dev/package.cjs`. UI screenshots nằm ở outputs, được tạo từ dữ liệu minh họa. Chạy `dev/deploy.ps1 -VerifyOnly` trước deploy. Kiểm tra report và hash sau deploy. Cần khởi động lại SketchUp sau cập nhật; bản 1.0.0 tự đăng ký toolbar không có file_loaded guard.

## Giới hạn đã biết

Đã qua kiểm tra Ruby WASM với fixture và UI trên Edge, chưa kiểm tra model thực tế trong SketchUp. Nạp ảnh/batch đồng bộ, chưa có hủy giữa lượt hoặc import nền. TIFF không preview bằng HTML. Các folder con không truy cập được sẽ báo lỗi quét và giữ queue cũ. Không tự đồng bộ theme trực tiếp hay hợp nhất toolbar/menu với các extension đang chạy khác; đây là Image Importer được chuẩn hóa để gia nhập bộ VGD.
