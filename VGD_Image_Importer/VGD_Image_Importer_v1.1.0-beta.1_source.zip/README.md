# VGD Image Importer

Thành viên bộ plugin VGD cho SketchUp 2022+, nâng cấp từ folder `vgd_image_importer` trên máy. Phiên bản `1.1.0-beta.1` giữ namespace và đường dẫn extension cũ để cập nhật tại chỗ.

## Chức năng

- Nhập component ảnh 2D dựng đứng, tùy chọn luôn hướng camera; ảnh nằm phẳng XY; hoặc chỉ thêm vật liệu vào Materials.
- Chọn cả thư mục, tùy chọn thư mục con; thêm từng file qua hộp thoại SketchUp; xem danh sách và bỏ ảnh trước khi nhập. Cancel kết thúc chọn ảnh lẻ; Cancel ngay giữ danh sách.
- Hỗ trợ JPG/JPEG, PNG, BMP, TIF/TIFF. Hình xem trước hỗ trợ JPG/PNG/BMP; TIFF hiển thị nhãn định dạng.
- Sắp tên tự nhiên (ảnh 2 trước ảnh 10), bỏ đường dẫn trùng, giữ tỉ lệ ảnh theo mm/pixel, chiều cao hoặc chiều rộng cố định.
- Bố trí theo hàng tại gốc tọa độ của `active_entities`; khoảng hở cho phép bằng 0. Với ảnh dựng đứng, khoảng cách hàng theo chiều cao ảnh là quy tắc bố trí kế thừa bản cũ.
- Vật liệu mới không ghi đè vật liệu sẵn có; SketchUp tự tạo tên riêng khi trùng. Lỗi một ảnh không chặn các ảnh còn lại; thông báo số thành công và từng ảnh lỗi. Undo một lần cho cả lượt nhập thành công.
- Theme sáng/tối, header VGD, màu nâu đồng và kiểu control theo VGD Scenes. Lưu theme, thông số và thư mục gần nhất trên máy. Danh sách ảnh giữ khi đóng/mở dialog trong cùng phiên SketchUp, không lưu qua lần khởi động.

## Cài đặt

Trong SketchUp: **Extension Manager → Install Extension**, chọn `VGD_Image_Importer_v1.1.0-beta.1.rbz`. Thoát và mở lại SketchUp để bản mới được nạp đầy đủ; không nạp chồng main.rb lên bản cũ trong Ruby Console vì bản cũ không có chặn đăng ký toolbar lặp.

Mở bằng **Extensions → VGD Tools → VGD Image Importer** hoặc toolbar **VGD Image Importer**. Nếu toolbar chưa hiện, bật ở **View → Toolbars**.

Đồng bộ từ mã nguồn trên Windows:

```powershell
powershell -ExecutionPolicy Bypass -File VGD_Image_Importer/dev/deploy.ps1 -VerifyOnly
powershell -ExecutionPolicy Bypass -File VGD_Image_Importer/dev/deploy.ps1
```

Mặc định cài vào SketchUp 2022; dùng `-PluginRoot` để chỉ định bản khác. Chỉ ghi tám file của Image Importer, có kiểm tra quyền sở hữu loader, sao lưu trước khi ghi và kiểm tra SHA256. Bản sao lưu và báo cáo nằm ở `outputs/install_<timestamp>/`. Muốn khôi phục, đóng SketchUp, chép các file đã sao lưu về đúng đường dẫn, bỏ các file mới được đánh dấu `false` trong `existed_before`, rồi mở lại SketchUp.

## Phát triển và kiểm tra

`runtime/` là mã để đóng gói; `reference/` giữ nguyên loader, main.rb và icon bản 1.0.0 đã lấy từ Plugins. Không đóng gói reference vào RBZ. `dev/dependencies.cjs` ưu tiên dependency cài tại chỗ, có thể dùng dependency đang có của VGD Scenes/Cabinet.

```powershell
cd VGD_Image_Importer/dev
npm install
npm test
npm run package
```

Giao diện kiểm tra bằng Playwright + Edge headless, hoặc đặt `VGD_BROWSER_EXECUTABLE` tới Chromium phù hợp. Ruby được kiểm tra cú pháp và chạy fixture bằng Ruby 3.2 WASM. Fixture mô phỏng SketchUp; Windows WASI không hỗ trợ đọc directory entries nên test traversal dùng danh sách entry cố định, còn kiểm tra file và tính toán chạy qua engine.

Đã kiểm tra tự động: chuyển đổi kích thước, bảo toàn tỉ lệ, số liệu không hợp lệ, thứ tự/quét con, bố trí khi ảnh lỗi, cleanup đối tượng lỗi, vật liệu trùng tên, commit/abort, callback dialog, lưu cấu hình, payload UI, theme sáng/tối và cửa sổ 540×500. Gói RBZ được mở lại và so từng file với runtime. Chưa xác nhận tạo hình, chất lượng ảnh và Undo trong SketchUp thực tế.

Kiểm tra thực tế sau khi mở lại SketchUp: nhập PNG có alpha ở ba chế độ; thử mm/pixel và chiều rộng/cao; chọn 2 ảnh/hàng và khoảng hở 0; thêm ảnh hỏng; xác nhận hướng camera, texture size và Undo. Lượt nhập lớn chạy đồng bộ trong Ruby nên có thể khiến SketchUp bận trong thời gian xử lý; dialog báo trạng thái và giữ mở sau kết quả.

API dùng theo tài liệu SketchUp: [ImageRep](https://ruby.sketchup.com/Sketchup/ImageRep.html), [Texture](https://ruby.sketchup.com/Sketchup/Texture.html), [HtmlDialog](https://ruby.sketchup.com/UI/HtmlDialog.html).
