/* Compatible with the Chromium version bundled in SketchUp 2022. */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var state = { importType: 'comp_2d', files: [], busy: false, native: !!window.sketchup };
  function call(action, data) {
    if (window.sketchup && window.sketchup.vgd_importer) window.sketchup.vgd_importer(action, JSON.stringify(data || {}));
    else if (action !== 'ready') status('Mở plugin trong SketchUp để chọn và nhập ảnh.', true);
  }
  function status(message, error, success) {
    $('status').textContent = message;
    $('status').className = error ? 'error' : success ? 'success' : '';
  }
  function theme(dark) {
    document.body.classList.toggle('dark', dark);
    $('theme').setAttribute('aria-pressed', String(dark));
    try { localStorage.setItem('vgd.theme', dark ? 'dark' : 'light'); } catch (_) {}
  }
  function config() {
    return { importType: state.importType, scaleMethod: $('scaleMethod').value,
      mmPerPixel: Number($('mmPerPixel').value), targetHeight: Number($('targetHeight').value),
      targetWidth: Number($('targetWidth').value), spacing: Number($('spacing').value),
      itemsPerRow: Number($('itemsPerRow').value), alwaysFaceCamera: $('alwaysFaceCamera').checked,
      recursive: $('recursive').checked, theme: document.body.classList.contains('dark') ? 'dark' : 'light' };
  }
  function valid(show) {
    var cfg = config();
    var fields = ['mmPerPixel', 'targetHeight', 'targetWidth', 'spacing', 'itemsPerRow'];
    for (var i = 0; i < fields.length; i++) {
      var key = fields[i], value = cfg[key];
      if (!Number.isFinite(value) || (key === 'spacing' ? value < 0 : value <= 0) ||
          (key === 'itemsPerRow' && (!Number.isInteger(value) || value > 1000))) {
        if (show) { status('Kiểm tra kích thước, khoảng hở và số ảnh mỗi hàng.', true); $(key).focus(); }
        return false;
      }
    }
    return true;
  }
  function update() {
    ['pixel', 'height', 'width'].forEach(function (method) { $(method + 'Row').hidden = $('scaleMethod').value !== method; });
    $('layoutCard').hidden = state.importType === 'texture_only';
    $('faceCamRow').hidden = state.importType !== 'comp_2d';
    document.querySelectorAll('[data-type]').forEach(function (button) { button.setAttribute('aria-pressed', String(button.dataset.type === state.importType)); });
    $('import').disabled = state.busy || !state.files.length;
    $('import').textContent = state.busy ? 'Đang nhập…' : 'Nhập ' + (state.files.length ? state.files.length + ' ' : '') + (state.importType === 'texture_only' ? 'vật liệu' : 'ảnh');
    $('clear').disabled = state.busy || !state.files.length;
    $('chooseFolder').disabled = $('chooseFiles').disabled = state.busy;
    document.querySelectorAll('#config input, #config select, #config button, #recursive, #theme, .remove').forEach(function (element) { element.disabled = state.busy; });
  }
  function fileUrl(path) {
    var normalized = path.replace(/\\/g, '/');
    return (normalized.slice(0, 2) === '//' ? 'file:' : 'file:///') + normalized.split('/').map(function (part, index) {
      return index === 0 && /^[A-Za-z]:$/.test(part) ? part : encodeURIComponent(part);
    }).join('/');
  }
  function renderFiles(files) {
    state.files = files;
    var list = $('fileList');
    list.textContent = '';
    $('count').textContent = files.length + ' ảnh';
    $('empty').hidden = files.length > 0;
    files.forEach(function (file) {
      var row = document.createElement('div'); row.className = 'file-row';
      var placeholder = document.createElement('span'); placeholder.className = 'thumb thumb-placeholder';
      placeholder.textContent = (file.name.split('.').pop() || 'ẢNH').toUpperCase();
      if (/\.(png|jpe?g|bmp)$/i.test(file.name)) {
        var image = document.createElement('img'); image.className = 'thumb'; image.alt = ''; image.loading = 'lazy';
        image.onerror = function () { image.replaceWith(placeholder); };
        image.src = fileUrl(file.path); row.appendChild(image);
      } else row.appendChild(placeholder);
      var info = document.createElement('div'); info.className = 'file-info';
      var name = document.createElement('strong'); name.textContent = file.name; name.title = file.name;
      var path = document.createElement('small'); path.textContent = file.path; path.title = file.path;
      info.appendChild(name); info.appendChild(path); row.appendChild(info);
      var remove = document.createElement('button'); remove.className = 'remove'; remove.textContent = '×';
      remove.setAttribute('aria-label', 'Bỏ ' + file.name); remove.onclick = function () { call('remove', { id: file.id }); };
      row.appendChild(remove); list.appendChild(row);
    });
    update();
  }
  window.VGDImporter = { receive: function (event, data) {
    if (event === 'settings') {
      Object.keys(data).forEach(function (key) {
        if (key === 'importType') state.importType = data[key];
        else if ($(key) && $(key).tagName !== 'BUTTON') {
          if ($(key).type === 'checkbox') $(key).checked = data[key]; else $(key).value = data[key];
        }
      });
      theme(data.theme === 'dark');
      $('version').textContent = 'VGD TOOLS · v' + data.version;
      update();
    } else if (event === 'files') renderFiles(data);
    else if (event === 'status') { state.busy = false; status(data.message, data.error); update(); }
    else if (event === 'result') {
      state.busy = false; update();
      var summary = 'Đã nhập ' + data.imported + ' ảnh / vật liệu' + (data.failed ? ' · ' + data.failed + ' ảnh lỗi.' : '.');
      status(summary, data.imported === 0, data.imported > 0);
      $('resultSummary').textContent = summary; $('errors').textContent = '';
      data.errors.forEach(function (error) { var item = document.createElement('li'); item.textContent = error.name + ': ' + error.message; $('errors').appendChild(item); });
      if (!$('resultDialog').open) $('resultDialog').showModal();
    }
  } };
  document.querySelectorAll('[data-type]').forEach(function (button) { button.onclick = function () { state.importType = button.dataset.type; update(); if (valid(false)) call('save', config()); }; });
  $('config').addEventListener('submit', function (event) { event.preventDefault(); });
  $('config').addEventListener('change', function () { update(); if (valid(false)) call('save', config()); });
  $('recursive').onchange = function () { if (valid(false)) call('save', config()); };
  $('theme').onclick = function () { theme(!document.body.classList.contains('dark')); if (valid(false)) call('save', config()); };
  $('chooseFolder').onclick = function () { call('choose', { kind: 'folder', recursive: $('recursive').checked }); };
  $('chooseFiles').onclick = function () { call('choose', { kind: 'files' }); };
  $('clear').onclick = function () { call('clear'); };
  $('closeResult').onclick = function () { $('resultDialog').close(); };
  $('import').onclick = function () {
    if (state.busy || !state.files.length || !valid(true)) return;
    if (!state.native) { status('Mở plugin trong SketchUp để nhập ảnh.', true); return; }
    state.busy = true; update(); status('Đang nhập ảnh. Lượt nhập lớn có thể mất một lúc…');
    // Let Chromium paint feedback before entering the native import callback.
    setTimeout(function () { call('import', config()); }, 30);
  };
  try { theme(localStorage.getItem('vgd.theme') === 'dark'); } catch (_) {}
  update(); call('ready');
}());
