const fs = require('fs'), path = require('path'), assert = require('assert');
const { pathToFileURL } = require('url'), { resolve } = require('./dependencies.cjs');
const { chromium } = require(resolve('playwright'));
(async () => {
  const outputs = path.resolve(__dirname, '../outputs'); fs.mkdirSync(outputs, { recursive: true });
  const browser = await chromium.launch({headless:true,...(process.env.VGD_BROWSER_EXECUTABLE ? {executablePath:process.env.VGD_BROWSER_EXECUTABLE} : {channel:'msedge'})});
  try {
    const page = await browser.newPage({viewport:{width:860,height:720}}), errors=[];
    page.setDefaultTimeout(6000);
    page.on('pageerror', error => errors.push(error.message));
    await page.addInitScript(() => { window.calls=[]; window.sketchup={vgd_importer:(action,data)=>calls.push({action,data:JSON.parse(data)})}; });
    await page.goto(pathToFileURL(path.resolve(__dirname,'../runtime/vgd_image_importer/dialog.html')).href);
    const last = () => page.evaluate(() => calls.at(-1));
    const receive = (event,data) => page.evaluate(([event,data]) => VGDImporter.receive(event,data), [event,data]);
    assert((await last()).action==='ready','Missing ready handshake');
    assert(await page.locator('#import').isDisabled(),'Empty queue enabled import');
    await receive('settings',{theme:'light',importType:'comp_2d',version:'1.1.0-beta.1'});
    await page.check('#recursive'); await page.click('#chooseFolder');
    assert.deepStrictEqual((await last()).data,{kind:'folder',recursive:true},'Recursive folder callback wrong');
    await page.click('#chooseFiles'); assert((await last()).data.kind==='files','File picker callback wrong');
    const iconPath = path.resolve(__dirname,'../runtime/vgd_image_importer/vgd_icon.png');
    const samples = [
      {id:0,name:'Cây xanh 01.png',path:iconPath},
      {id:1,name:'Người đi bộ 02.png',path:iconPath},
      {id:2,name:'Mặt bằng tầng 1.tiff',path:'C:/VGD/Photos/Mặt bằng tầng 1.tiff'},
      {id:3,name:'Ảnh tham chiếu 04.png',path:iconPath}
    ];
    await receive('files',samples);
    await page.screenshot({path:path.join(outputs,'vgd_image_importer_light.png')});
    await page.locator('.remove').first().click(); assert((await last()).action==='remove' && (await last()).data.id===0,'Removal callback wrong');
    await page.selectOption('#scaleMethod','width'); assert(await page.locator('#widthRow').isVisible() && !await page.locator('#pixelRow').isVisible(),'Width UI missing');
    await page.fill('#targetWidth','2400'); await page.fill('#spacing','0'); await page.click('[data-type=flat]');
    assert(!await page.locator('#faceCamRow').isVisible(),'Flat billboard setting visible');
    await page.click('#import'); await page.waitForFunction(() => calls.some(c=>c.action==='import'));
    let imported = await page.evaluate(() => calls.filter(c=>c.action==='import').at(-1));
    assert(imported.data.spacing===0 && imported.data.targetWidth===2400 && imported.data.importType==='flat','Import options wrong');
    assert(await page.locator('#import').isDisabled() && await page.locator('#clear').isDisabled(),'Busy controls enabled');
    await receive('result',{imported:3,failed:1,errors:[{name:'<img src=x onerror="window.injected=true">',message:'Không đọc được ảnh'}]});
    assert(await page.locator('#resultDialog').isVisible(),'Result missing');
    assert(!await page.evaluate(()=>window.injected),'Error name injected HTML');
    await page.click('#closeResult');
    await page.click('[data-type=texture_only]'); assert(!await page.locator('#layoutCard').isVisible(),'Materials layout visible');
    await page.click('[data-type=comp_2d]'); await page.selectOption('#scaleMethod','pixel');
    await page.fill('#itemsPerRow','0'); const before=await page.evaluate(()=>calls.filter(c=>c.action==='import').length);
    await page.click('#import'); assert((await page.evaluate(()=>calls.filter(c=>c.action==='import').length))===before,'Zero row count sent');
    assert(await page.locator('#status.error').count()===1,'Invalid input feedback missing');
    await page.fill('#itemsPerRow','10'); await page.click('#theme');
    assert(await page.locator('body.dark').count()===1 && (await last()).data.theme==='dark','Theme not persisted');
    await receive('status',{message:'Đã chọn 4 ảnh. Kiểm tra cấu hình rồi nhập.'});
    await page.screenshot({path:path.join(outputs,'vgd_image_importer_dark.png')});
    await page.setViewportSize({width:540,height:500});
    assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Minimum width overflows');
    assert(await page.locator('#import').isVisible(),'Compact import button hidden');
    await page.screenshot({path:path.join(outputs,'vgd_image_importer_compact.png')});
    await page.click('#clear'); assert((await last()).action==='clear','Clear callback wrong');
    await receive('files',[]); assert(await page.locator('#import').isDisabled() && await page.locator('#empty').isVisible(),'Empty state not restored');
    assert.deepStrictEqual(errors,[],'Browser script errors');
    console.log('PASS: source callbacks, queue, safe filenames, scale/mode controls, zero spacing, validation, busy state, native payload, summary, dark theme and 540×500 layout.');
  } finally { await browser.close(); }
})().catch(error=>{console.error(error);process.exitCode=1;});
