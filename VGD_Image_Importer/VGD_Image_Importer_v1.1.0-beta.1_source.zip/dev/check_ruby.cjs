const fs = require('fs'), path = require('path'), { WASI } = require('wasi');
const { resolve } = require('./dependencies.cjs');
const { RubyVM } = require(path.join(resolve('@ruby/wasm-wasi'), 'dist/cjs/vm.js'));
(async () => {
  const root = path.resolve(__dirname, '..'), outputs = path.join(root, 'outputs');
  fs.mkdirSync(outputs, { recursive: true });
  const temp = fs.mkdtempSync(path.join(outputs, 'ruby-'));
  const wasm = await WebAssembly.compile(fs.readFileSync(path.join(resolve('@ruby/3.2-wasm-wasi'), 'dist/ruby+stdlib.wasm')));
  const wasi = new WASI({ version: 'preview1', returnOnExit: true, preopens: { '/workspace': root, '/tmp': temp } });
  const { vm } = await RubyVM.instantiateModule({ module: wasm, wasip1: wasi });
  const files = ['vgd_image_importer.rb', 'vgd_image_importer/engine.rb', 'vgd_image_importer/main.rb'];
  for (const file of files) {
    vm.eval('RubyVM::InstructionSequence.compile(' + JSON.stringify(fs.readFileSync(path.join(root, 'runtime', file), 'utf8')).replace(/#/g, '\\#') + ')');
    console.log('Syntax OK:', file);
  }
  vm.eval(fs.readFileSync(path.join(__dirname, 'fixture.rb'), 'utf8'));
  for (const file of files) vm.eval(fs.readFileSync(path.join(root, 'runtime', file), 'utf8').replace(/^require(?:_relative)? [^\n]*\n/gm, ''));
  vm.eval(fs.readFileSync(path.join(__dirname, 'test_engine.rb'), 'utf8'));
  vm.eval('$stdout.flush');
})().catch(error => { console.error(error); process.exitCode = 1; });
