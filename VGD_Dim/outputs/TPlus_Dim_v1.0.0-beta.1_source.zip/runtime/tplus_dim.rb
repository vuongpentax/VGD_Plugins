# encoding: UTF-8
require 'sketchup.rb'
require 'extensions.rb'

module TPlus
  module Dim
    VERSION = '1.0.0-beta.1'.freeze unless const_defined?(:VERSION)
    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new('T+ Dim', 'TPlus_Dim/main')
      extension.description = 'Chuẩn hóa Dimension và Text trong vùng chọn. Giao diện đồng bộ T+ Cabinet.'
      extension.version = VERSION
      extension.creator = 'T+'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
