# T+ Dim · 1.0.0-beta.1

Plugin chuẩn hóa các Dimension có sẵn trong vùng chọn, tương thích SketchUp 2022.
Font giao diện, palette sáng/tối và hình nền icon lấy theo mẫu T+ Cabinet người dùng cung cấp.

## Sử dụng

1. Quét chọn dim hoặc Group/Component chứa dim.
2. Mở menu Extensions → T+ Dim hoặc toolbar T+ Dim.
3. Chọn màu, kiểu đầu đường dim, hướng/vị trí chữ và khoảng cách cần thay đổi.
4. Bấm ÁP DỤNG VÙNG CHỌN. Undo hoàn tác thao tác chỉnh dim.

Dialog theo dõi vùng chọn khi bạn tiếp tục chọn trong model. Nút Lấy vùng chọn cập nhật lại số lượng.
Mặc định quét sâu trong nhóm/component được chọn; bỏ chọn mục này để chỉ xử lý các dim được chọn trực tiếp.
Có thể bật thêm việc đổi màu Text ghi chú. Không xử lý chữ 3D tạo bằng mặt/cạnh.

## Phạm vi và tính năng

- Chỉnh dim thẳng và dim bán kính/đường kính có sẵn, giữ các điểm tham chiếu đo.
- Khoảng cách và vị trí chữ chỉ áp dụng cho dim thẳng. Khoảng cách tính theo mm trong model kể cả nhóm có scale, giữ phía đặt dim.
- Màu material được lưu theo giá trị màu; không đổi material đang dùng bởi dim ngoài vùng chọn.
- Component/Group có definition dùng chung được make_unique trước khi chỉnh, kể cả nhóm lồng nhau. Vì vậy các instance được chọn trở thành bản riêng.
- Bỏ qua nhóm/component khóa. Nếu đang mở chế độ sửa trong definition dùng chung, đóng nhóm và chọn instance ở bên ngoài để plugin tách riêng trước khi cập nhật.
- Trả chữ về giá trị đo thực là lựa chọn riêng, mặc định tắt; khi bật sẽ xóa nội dung người dùng đã nhập đè lên dim.
- Đổi đơn vị là tùy chọn rõ ràng cho **toàn model**, mặc định tắt mỗi lần mở dialog. Định dạng chiều dài được chuyển về Decimal; không đổi kích thước hình học.
- Lưu thông số dùng lần trước; plugin không tự mở dialog lúc khởi động SketchUp.

## Font trên SketchUp 2022

Ruby API của SketchUp 2022 không cung cấp setter font/cỡ chữ cho Dimension và Text.
Mục Chữ & font mở Model Info → Dimensions / Text. Chọn trực tiếp các dim cần đổi font,
đặt font, cỡ, đậm/nghiêng rồi dùng Update selected dimensions của SketchUp.
Nếu dim nằm trong nhóm, cần mở nhóm và chọn trực tiếp các dim bên trong.
Nút Áp dụng của T+ Dim không báo đã đổi font và không giả lập font bằng hình học.

Tham khảo: https://ruby.sketchup.com/Sketchup/Dimension.html và
https://ruby.sketchup.com/file.ReleaseNotes.html (Text#font= bổ sung từ 2026.2).

## Cài đặt

RBZ có thể cài qua Extensions → Extension Manager → Install Extension.
Trong môi trường phát triển này, `dev/deploy.ps1` chỉ đồng bộ bảy file thuộc T+ Dim
vào thư mục Plugins của SketchUp 2022. Script sao lưu file cũ và kiểm tra SHA256.
Không thay đổi T+ Cabinet hoặc plugin khác.

SketchUp đang mở: có thể nạp loader một lần bằng Ruby Console:

```ruby
load 'C:/Users/PC/AppData/Roaming/SketchUp/SketchUp 2022/SketchUp/Plugins/tplus_dim.rb'
TPlus::Dim.show_dialog
```

Sau khi nâng bản trong cùng phiên, nên mở lại SketchUp để nạp mã mới.

## Kiểm tra

`node dev/check_ruby.cjs`: syntax Ruby và fixture mô phỏng vùng chọn, nested/shared component,
nhóm khóa, model edit context, material, scaled offset, units và abort khi lỗi.
`node dev/test_ui.cjs`: callback/payload, chống target cũ, nhập sai, đơn vị opt-in,
sáng/tối và layout ở 580×680 / 470×530 bằng Chrome headless.

Các test này không thay thế native SketchUp. `dev/native_smoke.rb` chỉ được chạy trong
một model mới của SketchUp 2022; script từ chối file hiện có và ghi kết quả thực tế vào outputs.

Kiểm tra native ngày 01/10/2026: đã xác nhận menu T+ Dim xuất hiện trong SketchUp 2022.
Chưa xác minh thao tác áp dụng và Undo bằng kernel SketchUp: Windows Computer Use gặp lỗi
điều khiển Ruby Console trên màn hình phụ (phần tử không thuộc cached state / tọa độ ngoài
window bounds), sau đó get_window_state timeout. Không có kết quả PASS từ native_smoke.rb.
Các tiến trình khởi chạy bằng shell dừng ở Welcome; không sử dụng chúng làm bằng chứng chạy plugin.

Các dependency test của bản giao việc sử dụng Ruby WASM đã có trong thư mục Cabinet tham chiếu
(chỉ đọc), Playwright trong runtime Codex và Python để đóng gói. Runtime plugin không cần chúng.
