const fs = require('fs');
const path = require('path');
const {pathToFileURL} = require('url');
const {chromium} = require('C:/Users/PC/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const assert = (ok, message) => { if (!ok) throw new Error(message); };
(async () => {
  const browser = await chromium.launch({headless:true, channel:'chrome'});
  const page = await browser.newPage({viewport:{width:580,height:680}});
  const errors=[]; page.on('pageerror', error => errors.push(error.message));
  await page.addInitScript(() => { window.calls=[]; window.sketchup=new Proxy({}, {get:(_target,action)=>payload=>calls.push({action,payload})}); });
  await page.goto(pathToFileURL(path.resolve(__dirname,'../runtime/TPlus_Dim/dialog.html')).href);
  assert(await page.locator('#apply').isDisabled(), 'Apply enabled without selection');
  assert(await page.evaluate(()=>calls[0].action === 'ready'), 'Missing ready callback');
  await page.evaluate(()=>TPlusDim.receive({dimensions:12,texts:0,selected:2,locked:0,shared:1,blocked:null,can_apply:true,context_token:'test-selection'}, {}));
  await page.selectOption('#arrow','closed'); await page.click('#apply');
  let call = await page.evaluate(()=>calls.at(-1)); let data = JSON.parse(call.payload);
  assert(call.action==='apply' && data.arrow==='closed' && data.context_token==='test-selection' && !data.change_units && !data.include_text, 'Apply target/default payload');
  assert(await page.locator('#apply').isDisabled(), 'Duplicate submission enabled');
  await page.evaluate(()=>TPlusDim.receive({dimensions:12,texts:0,selected:2,locked:0,shared:1,blocked:null,can_apply:true,context_token:'new-selection'}, {arrow:'slash'}));
  assert(await page.locator('#arrow').inputValue()==='closed', 'Live selection erased form choices');
  await page.check('#change_offset'); await page.fill('#offset_mm','0'); await page.click('#apply');
  assert((await page.locator('#model_status').innerText()).includes('lớn hơn 0'), 'Invalid offset not rejected');
  await page.fill('#offset_mm','125'); await page.click('#apply');
  call = await page.evaluate(()=>calls.at(-1)); assert(JSON.parse(call.payload).offset_mm===125, 'Offset payload');
  await page.evaluate(()=>TPlusDim.receive({dimensions:12,texts:0,selected:2,locked:0,shared:0,blocked:null,can_apply:true,context_token:'new-selection'}, {}));
  await page.click('[data-page="text"]'); await page.selectOption('#alignment','screen');
  assert(await page.locator('#position').isDisabled(), 'Screen-aligned position enabled');
  await page.check('#include_text'); assert(await page.locator('#apply').isDisabled(), 'Scope change retained stale selection token');
  call=await page.evaluate(()=>calls.at(-1)); assert(call.action==='refresh' && JSON.parse(call.payload).include_text, 'Text scan scope missing');
  await page.evaluate(()=>TPlusDim.receive({dimensions:12,texts:3,selected:2,locked:0,shared:0,blocked:null,can_apply:true,context_token:'text-selection'}, {}));
  await page.click('#dim_info'); call=await page.evaluate(()=>calls.at(-1)); assert(call.action==='model_info' && call.payload==='Dimensions', 'Native font button');
  await page.click('[data-page="units"]'); assert(await page.locator('#unit').isDisabled(), 'Model-wide units enabled by default');
  await page.check('#change_units'); await page.selectOption('#precision','3'); await page.click('#apply');
  data=JSON.parse((await page.evaluate(()=>calls.at(-1))).payload); assert(data.change_units && data.precision===3, 'Unit opt-in payload');
  await page.evaluate(()=>TPlusDim.receive({dimensions:12,texts:0,selected:2,locked:0,shared:0,blocked:'Ngữ cảnh dùng chung',can_apply:false,context_token:'blocked'}, {}));
  assert(await page.locator('#apply').isDisabled(), 'Blocked editing context enabled');
  fs.mkdirSync(path.resolve(__dirname,'../outputs'),{recursive:true});
  await page.click('[data-page="dimension"]'); await page.uncheck('#change_offset'); await page.selectOption('#arrow','slash');
  await page.click('[data-page="text"]'); await page.uncheck('#include_text');
  await page.click('[data-page="units"]'); await page.uncheck('#change_units');
  await page.evaluate(()=>TPlusDim.receive({dimensions:12,texts:0,selected:2,locked:0,shared:0,blocked:null,can_apply:true,context_token:'preview'}, {}));
  for (const [width,height] of [[580,680],[470,530]]) {
    await page.setViewportSize({width,height});
    for (const panel of ['dimension','text','units']) {
      await page.click('[data-page="'+panel+'"]');
      const layout=await page.evaluate(()=>({overflow:document.documentElement.scrollWidth>innerWidth,footer:document.querySelector('footer').getBoundingClientRect().bottom<=innerHeight,pane:document.querySelector('main').scrollWidth<=document.querySelector('main').clientWidth}));
      assert(!layout.overflow && layout.footer && layout.pane, 'Clipped layout at '+width+' / '+panel);
    }
  }
  await page.setViewportSize({width:580,height:680}); await page.click('[data-page="dimension"]');
  await page.screenshot({path:path.resolve(__dirname,'../outputs/dialog_light.png')});
  await page.click('#theme'); await page.screenshot({path:path.resolve(__dirname,'../outputs/dialog_dark.png')});
  await page.click('[data-page="text"]'); await page.screenshot({path:path.resolve(__dirname,'../outputs/dialog_font.png')});
  assert(errors.length===0, 'Browser errors: '+errors.join('; '));
  await browser.close(); console.log('PASS: dialog payload, selection changes, validation, native-font routing, units opt-in, light/dark and responsive layout');
})().catch(error=>{console.error(error);process.exit(1);});
