const fs = require('fs');
const path = require('path');
const deps = path.resolve(__dirname, '../../TPlus_Cabinet_Codex_Handoff_2026-10-01/cabinet_dev/node_modules');
const {DefaultRubyVM} = require(path.join(deps, '@ruby/wasm-wasi/dist/cjs/node.js'));
(async () => {
  const wasm = await WebAssembly.compile(fs.readFileSync(require.resolve(path.join(deps, '@ruby/3.2-wasm-wasi/dist/ruby+stdlib.wasm'))));
  const {vm} = await DefaultRubyVM(wasm);
  const root = path.resolve(__dirname, '../runtime');
  const files = ['tplus_dim.rb', 'TPlus_Dim/main.rb', 'TPlus_Dim/engine.rb'];
  const rubyLiteral = value => JSON.stringify(value).replace(/#/g, '\\#');
  for (const file of files) {
    vm.eval('RubyVM::InstructionSequence.compile(' + rubyLiteral(fs.readFileSync(path.join(root, file), 'utf8')) + ')');
    console.log('Syntax OK:', file);
  }
  vm.eval(fs.readFileSync(path.join(__dirname, 'test_engine.rb'), 'utf8'));
  vm.eval(fs.readFileSync(path.join(root, 'TPlus_Dim/engine.rb'), 'utf8'));
  vm.eval('run_engine_tests; $stdout.flush');
})().catch(error => {console.error(error); process.exitCode = 1;});
