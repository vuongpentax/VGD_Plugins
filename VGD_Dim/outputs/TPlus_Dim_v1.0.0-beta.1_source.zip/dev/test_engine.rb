# A small SketchUp-shaped fixture. These tests are not native SketchUp tests.
require 'json'
module Length
  Decimal = 0
end
class Numeric
  def mm; to_f / 25.4; end
end
module Geom
  class Transformation
    attr_reader :scale
    def initialize(scale = 1.0); @scale = scale; end
    def *(other); Transformation.new(scale * other.scale); end
  end
  class Vector3d
    attr_accessor :length
    def initialize(length = 1.0); @length = length; end
    def transform(transform); Vector3d.new(length * transform.scale); end
  end
end
module Sketchup
  class Entity
    @@next_id = 0
    def initialize; @@next_id += 1; @pid = @@next_id; end
    def persistent_id; @pid; end
    def valid?; true; end
  end
  class Dimension < Entity
    ARROW_NONE = 0; ARROW_SLASH = 1; ARROW_DOT = 2; ARROW_CLOSED = 3; ARROW_OPEN = 4
    attr_accessor :material, :arrow_type, :text
    def initialize; super; @arrow_type = ARROW_OPEN; @text = 'OS'; @aligned = false; end
    def has_aligned_text=(value); @aligned = value; end
    def has_aligned_text?; @aligned; end
  end
  class DimensionLinear < Dimension
    ALIGNED_TEXT_ABOVE = 0; ALIGNED_TEXT_CENTER = 1; ALIGNED_TEXT_OUTSIDE = 2
    attr_accessor :aligned_text_position
    def initialize; super; @vector = Geom::Vector3d.new(2.0); end
    def offset_vector; @vector.dup; end
    def offset_vector=(vector); @vector = vector; end
  end
  class Text < Entity
    attr_accessor :material
  end
  class Color
    attr_reader :red, :green, :blue
    def initialize(r, g, b); @red = r; @green = g; @blue = b; end
  end
  Material = Struct.new(:name, :color)
  class Materials
    attr_reader :items
    def initialize; @items = {}; end
    def [](name); items[name]; end
    def add(name)
      candidate = name
      candidate += '_' while items.key?(candidate)
      items[candidate] = Material.new(candidate, Color.new(0, 0, 0))
    end
  end
  Definition = Struct.new(:entities, :instances)
  class ComponentInstance < Entity
    attr_accessor :definition, :transformation, :locked
    def initialize(definition, scale = 1.0)
      super(); @definition = definition; definition.instances << self
      @transformation = Geom::Transformation.new(scale); @locked = false
    end
    def locked?; @locked; end
    def make_unique
      old = definition; old.instances.delete(self)
      copies = old.entities.map do |entity|
        if entity.is_a?(ComponentInstance)
          entity.class.new(entity.definition, entity.transformation.scale)
        else
          entity.dup
        end
      end
      @definition = Definition.new(copies, [self]); self
    end
  end
  class Group < ComponentInstance
    def entities; definition.entities; end
  end
  class FakeModel
    attr_accessor :selection, :active_path
    attr_reader :operations, :materials, :options, :aborts, :commits
    def initialize
      @selection = []; @active_path = nil; @operations = @aborts = @commits = 0
      @materials = Materials.new; @options = {'UnitsOptions' => {'LengthUnit' => 0, 'LengthFormat' => 1}}
    end
    def guid; 'test-model'; end
    def edit_transform; Geom::Transformation.new; end
    def start_operation(*); @operations += 1; end
    def commit_operation; @commits += 1; end
    def abort_operation; @aborts += 1; end
    def active_view; self; end
    def invalidate; end
  end
end
module TPlus
  module Dim
    DEFAULTS = {
      'deep'=>true, 'include_text'=>false, 'change_color'=>true,
      'dim_color'=>'#222222', 'text_color'=>'#222222', 'arrow'=>'slash',
      'alignment'=>'keep', 'position'=>'keep', 'change_offset'=>false,
      'offset_mm'=>100.0, 'reset_text'=>false, 'change_units'=>false,
      'unit'=>'mm', 'precision'=>0, 'show_unit'=>true
    }.freeze
  end
end

def assert(value, message)
  raise message unless value
end
def rejects(message)
  begin
    yield
  rescue ArgumentError
    return
  end
  raise message
end
def apply_test(model, overrides = {})
  config = TPlus::Dim::Engine.validate(TPlus::Dim::DEFAULTS.merge(overrides))
  TPlus::Dim::Engine.apply(model, config, TPlus::Dim::Engine.token(model, config))
end

def run_engine_tests
  engine = TPlus::Dim::Engine
  model = Sketchup::FakeModel.new
  rejects('Empty selection allowed') { apply_test(model) }
  assert(model.operations == 0 && model.materials.items.empty?, 'Empty selection mutated model')
  dim = Sketchup::DimensionLinear.new; outsider = Sketchup::DimensionLinear.new
  model.selection = [dim]
  config = TPlus::Dim::DEFAULTS.dup
  stale = engine.token(model, config)
  model.selection = [outsider]
  rejects('Stale target accepted') { engine.apply(model, config, stale) }
  model.selection = [dim]
  result = apply_test(model)
  assert(result[:dimensions] == 1 && dim.arrow_type == 1 && outsider.material.nil?, 'Selected-only update failed')
  old_material = dim.material
  apply_test(model, 'dim_color'=>'#CC3300')
  assert([old_material.color.red, old_material.color.green, old_material.color.blue] == [34,34,34], 'Shared color recolored')
  collision = model.materials.add('T+_DIM_00FF00'); collision.color = Sketchup::Color.new(1,2,3)
  apply_test(model, 'dim_color'=>'#00FF00')
  assert(collision.color.red == 1 && dim.material != collision, 'Color-name collision altered existing material')

  original = Sketchup::DimensionLinear.new
  nested_definition = Sketchup::Definition.new([original], [])
  nested = Sketchup::ComponentInstance.new(nested_definition, 2)
  parent_definition = Sketchup::Definition.new([nested], [])
  selected = Sketchup::ComponentInstance.new(parent_definition)
  unselected = Sketchup::ComponentInstance.new(parent_definition)
  model = Sketchup::FakeModel.new; model.selection = [selected]
  result = apply_test(model, 'change_offset'=>true, 'offset_mm'=>100, 'alignment'=>'aligned', 'position'=>'above', 'reset_text'=>true)
  updated = selected.definition.entities[0].definition.entities[0]
  assert(result[:unique] == 2 && original.material.nil? && unselected.definition == parent_definition, 'Nested definition leaked')
  assert(updated.text == '' && updated.has_aligned_text? && updated.aligned_text_position == 0, 'Dim text style failed')
  assert((updated.offset_vector.length * 2 - 100.mm).abs < 1e-8, 'Scaled offset was not 100 mm in world space')

  model = Sketchup::FakeModel.new; model.selection = [selected]
  rejects('Deep disabled scanned children') { apply_test(model, 'deep'=>false) }
  assert(model.operations == 0, 'Deep disabled still started operation')
  selected.locked = true
  rejects('Locked selection accepted') { apply_test(model) }
  selected.locked = false
  direct = Sketchup::DimensionLinear.new
  model.selection = [direct]; model.active_path = [unselected]
  another = Sketchup::ComponentInstance.new(parent_definition)
  rejects('Shared editing context accepted') { apply_test(model) }

  model = Sketchup::FakeModel.new; dim = Sketchup::DimensionLinear.new; text = Sketchup::Text.new
  model.selection = [dim, text]
  apply_test(model)
  assert(text.material.nil? && model.options['UnitsOptions']['LengthUnit'] == 0, 'Opt-in flags ignored')
  result = apply_test(model, 'include_text'=>true, 'change_units'=>true, 'unit'=>'mm', 'precision'=>2, 'show_unit'=>false)
  assert(result[:texts] == 1 && text.material, 'Text opt-in failed')
  assert(model.options['UnitsOptions'] == {'LengthUnit'=>2,'LengthFormat'=>0,'LengthPrecision'=>2,'SuppressUnitsDisplay'=>true}, 'Unit settings failed')
  dim.define_singleton_method(:arrow_type=) { |_value| raise 'simulated native setter failure' }
  begin
    apply_test(model)
    raise 'Setter failure not propagated'
  rescue RuntimeError => error
    raise unless error.message == 'simulated native setter failure'
  end
  assert(model.aborts == 1, 'Setter failure did not abort operation')
  rejects('Bad offset accepted') { engine.validate(TPlus::Dim::DEFAULTS.merge('change_offset'=>true,'offset_mm'=>-2)) }
  rejects('Bad precision accepted') { engine.validate(TPlus::Dim::DEFAULTS.merge('precision'=>1.5)) }
  rejects('Bad arrow accepted') { engine.validate(TPlus::Dim::DEFAULTS.merge('arrow'=>'bad')) }
  puts 'PASS: selection, stale targets, shared/nested definitions, locked context, scaling, materials, units, abort and validation'
end
