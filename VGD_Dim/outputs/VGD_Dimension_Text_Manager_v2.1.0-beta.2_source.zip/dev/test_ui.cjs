const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const deps=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
if(!deps)throw Error('Set CODEX_PRIMARY_RUNTIME_NODE_MODULES');
const {chromium}=require(path.join(deps,'playwright'));
const assert=(v,m)=>{if(!v)throw Error(m);};
(async()=>{
  const browser=await chromium.launch({headless:true,...(process.env.TPLUS_BROWSER_PATH?{executablePath:process.env.TPLUS_BROWSER_PATH}:{channel:'msedge'})});
  try {
    const page=await browser.newPage({viewport:{width:560,height:760}});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript(()=>{window.calls=[];window.sketchup=new Proxy({},{get:(_,action)=>payload=>calls.push({action,payload})});});
    await page.goto(pathToFileURL(path.resolve(__dirname,'../runtime/VGD_Dim/dialog.html')).href);
    assert((await page.title()).includes('VGD') && (await page.locator('header').innerText()).includes('VGD'), 'VGD brand absent');
    const palette=await page.evaluate(()=>({button:getComputedStyle(document.querySelector('#apply')).backgroundColor,body:getComputedStyle(document.body).backgroundColor,header:getComputedStyle(document.querySelector('header')).backgroundColor,font:getComputedStyle(document.body).fontFamily}));
    assert(palette.button==='rgb(180, 137, 99)' && palette.body==='rgb(247, 247, 245)' && palette.header==='rgb(43, 43, 43)' && palette.font.includes('Segoe UI'),'Style differs from Cabinet palette/font');
    const last=async()=>page.evaluate(()=>calls.at(-1));
    await page.click('#apply');
    let call=await last(),s=JSON.parse(call.payload);
    assert(call.action==='apply' && s.font==='Arial' && s.size_pt===10 && s.size_display==='10 pt','Defaults wrong');
    assert(s.dim_color==='#000000' && s.text_color==='#000000' && s.unit==='mm' && s.precision==='0' && s.show_unit,'Color/units defaults wrong');
    assert(!s.bold && !s.italic,'Style defaults wrong');
    await page.selectOption('#font','Tahoma');await page.fill('#size','3.5');await page.selectOption('#size_unit','mm');
    await page.check('#bold');await page.check('#italic');
    await page.locator('#dim_color').fill('#112233');await page.locator('#text_color').fill('#aabbcc');
    await page.selectOption('#unit','ft');await page.selectOption('#precision','3');await page.uncheck('#show_unit');
    await page.click('#apply');s=JSON.parse((await last()).payload);
    assert(Math.abs(s.size_pt-3.5*72/25.4)<1e-9 && s.size_display==='3.5 mm','mm conversion wrong');
    assert(s.font==='Tahoma' && s.bold && s.italic && s.dim_color==='#112233' && s.text_color==='#aabbcc' && s.unit==='ft' && s.precision==='3' && !s.show_unit,'Changed settings wrong');
    await page.locator('#open_dim_info').click();assert((await last()).action==='open_dim_info','Dimensions shortcut wrong');
    await page.locator('#open_text_info').click();assert((await last()).action==='open_text_info','Text shortcut wrong');
    await page.click('#cancel');assert((await last()).action==='cancel','Cancel wrong');
    const count=await page.evaluate(()=>calls.length);
    await page.fill('#size','400');await page.click('#apply');
    assert(await page.locator('#error').isVisible() && await page.evaluate(()=>calls.length)===count,'Invalid converted size submitted');
    assert(await page.locator('#scope,#preset,[data-page],#scan').count()===0,'Old complex controls remain');
    assert(await page.locator('input:disabled:checked').count()===2,'Deep scan defaults wrong');
    await page.fill('#size','10');await page.selectOption('#size_unit','pt');
    await page.click('#apply');
    const output=path.resolve(__dirname,'../outputs');fs.mkdirSync(output,{recursive:true});
    await page.reload();
    for(const [width,height] of [[560,760],[540,690]]){
      await page.setViewportSize({width,height});
      await page.locator('main').evaluate(e=>e.scrollTop=0);
      const layout=await page.evaluate(()=>({
        overflow:document.documentElement.scrollWidth>innerWidth,
        footer:document.querySelector('footer').getBoundingClientRect().bottom<=innerHeight,
        main:document.querySelector('main').clientHeight>100
      }));
      assert(!layout.overflow && layout.footer && layout.main,'Clipped layout '+width);
      await page.screenshot({path:path.join(output,'vgd_dimension_text_'+width+'.png')});
    }
    assert(errors.length===0,errors.join(';'));
    console.log('PASS: one-page defaults, Apply/mm conversion, Model Info shortcuts, Cancel, validation and visible footer');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
