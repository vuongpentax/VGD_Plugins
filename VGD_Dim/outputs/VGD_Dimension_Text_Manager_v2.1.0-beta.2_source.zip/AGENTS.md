# VGD Dimension & Text Manager

Yêu cầu mới nhất là mẫu `DIMENSION_TEXT_REFERENCE.rb` ngày 2026-10-02, thay thế thiết kế Annotation Manager trước đó.

- Từ 2.1.0-beta.2 dùng loader vgd_dim.rb, namespace VGD::Dim và thư mục VGD_Dim. Khi chuyển từ T+ Dim, sao lưu và gỡ bộ nạp cũ sau khi xác minh bản VGD để tránh cài trùng. Không tạo alias namespace cũ.
- Giao diện theo style T+ Cabinet: nền sáng, header tối, màu nâu đồng #B48963, Segoe UI/Inter, nút APPLY ở footer. Tên thương hiệu hiển thị VGD.
- Một cửa sổ, một APPLY: font/size pt hoặc mm, bold/italic, màu Dim/Text, Units/precision/show unit và quét sâu toàn model.
- Không có preset, tab, scope, Scan riêng, mesh/edge chữ hoặc observer chạy nền.
- mm được quy đổi sang pt theo mẫu; không gọi đây là Height native của SketchUp.
- Font native Dimension chỉnh trong Model Info. Text font chỉ áp nếu entity hỗ trợ font=; báo đúng kết quả.
- APPLY đổi UnitsOptions toàn model và material native trong một operation. Giữ nội dung, vị trí, điểm đo, hướng chữ, tag, trạng thái ẩn/khóa và geometry.
- Definition chia sẻ xử lý một lần, không make_unique. Group không đếm hai lần như Component.
- Chỉ deploy file trong dev/deploy.ps1 vào SketchUp 2022. Không sửa Cabinet/plugin khác.
- Kiểm tra Ruby, quét sâu và UI; phân biệt mô phỏng với kiểm thử thực tế trong SketchUp.
