# VGD Dimension & Text Manager · 2.1.0-beta.2

Bản đơn giản theo mẫu DIMENSION_TEXT_REFERENCE.rb, chuyển thương hiệu Dim/Text sang VGD ngày 2026-10-02. Toàn bộ runtime dùng namespace VGD::Dim, loader vgd_dim.rb và thư mục VGD_Dim. Cabinet giữ nguyên.

Giao diện theo style T+ Cabinet: nền trắng/xám sáng, header tối, màu nhấn nâu đồng #B48963, font Segoe UI/Inter và footer cố định. Giữ bố cục một trang.

1. Mở Extensions → VGD Dimension & Text Manager hoặc nút toolbar VGD.
2. Chọn font, size pt/mm, bold/italic, màu Dimension/Text và Unit/Precision/Show Unit.
3. Bấm APPLY. Plugin tự đi sâu vào Group và Component của toàn model, kể cả annotation ẩn. Text có leader cũng thuộc Text. Definition chia sẻ được xử lý một lần.
4. Chỉnh font/cỡ chữ Dim bằng nút Model Info → Dimensions và Update selected dimensions. Trên SketchUp 2022, dùng nút Model Info → Text cho font/cỡ chữ Text.
5. Ctrl+S lưu file để chuyển máy/người nhận. Màu và Units được lưu trong model; font mặc định do Model Info lưu.

APPLY có một Undo, chỉ đổi material và UnitsOptions; Text font được áp khi có font=. Giữ nội dung, vị trí, hướng chữ, điểm đo, tag, geometry và trạng thái khóa/ẩn. Không tạo chữ edge/face. Không có tab, preset, scope, bước Scan riêng hoặc dịch vụ chạy nền.

Size mm quy đổi thành pt theo mẫu (mm × 72 / 25.4), sau đó Text Font API nhận pt nguyên. Đây là quy đổi đầu vào, không phải Height native. Font Dimension không tự áp từ ô font trong cửa sổ; Model Info quản lý phần này.

## Cài đặt / nạp bản mới

RBZ: outputs/VGD_Dimension_Text_Manager_v2.1.0-beta.2.rbz. Khi cài thủ công lần đầu từ T+ sang VGD, tắt extension T+ Dim/Dimension & Text Manager cũ trong Extension Manager để tránh cài trùng, rồi Install Extension bản VGD.

Máy nhà: dev/deploy.ps1 cài 9 file VGD vào Plugins của SketchUp 2022, sao lưu và đối chiếu SHA256. Sau khi xác minh bản VGD, script sao lưu rồi gỡ riêng bộ nạp tplus_dim.rb; runtime cũ giữ để phục hồi. Lỗi cài đặt hoàn tác các file vừa ghi. Không ghi Cabinet/plugin khác.

Sau lần chuyển thương hiệu, lưu model và khởi động lại SketchUp để nạp bộ nạp/namespace mới. Những lần sửa tiếp theo, dùng menu Nạp lại VGD Dim/Text hoặc Ruby Console:

```ruby
load File.join(Sketchup.find_support_file('Plugins'), 'VGD_Dim', 'reload.rb')
```

## Kiểm tra

- dev/check_ruby.cjs: cú pháp Ruby và fixture quét sâu, definition chia sẻ/cycle, font Text tùy API, Units, bảo toàn nội dung/vị trí và abort.
- dev/test_ui.cjs: giao diện một trang trong Edge, payload APPLY, đổi mm/pt, Model Info, CANCEL, input lỗi và footer.
- dev/test_deploy.py: bộ cài thực chạy trong APPDATA mô phỏng; VerifyOnly, sao lưu/gỡ loader cũ, cài lặp, kiểm tra nhận diện loader và giữ nguyên Cabinet.
- dev/native_smoke.rb: chỉ chạy thủ công trong model thử trống; không chạy trên model đang làm.
- Xem outputs/VALIDATION.json. Bản này chưa được kiểm thử tương tác thực tế trong SketchUp.
