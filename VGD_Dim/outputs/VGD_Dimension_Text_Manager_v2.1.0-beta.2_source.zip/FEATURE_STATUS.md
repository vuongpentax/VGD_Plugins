# Trạng thái bản đơn giản · 2.1.0-beta.2

Tên hiển thị, namespace, loader, thư mục runtime, material mới và gói phát hành: VGD. Giao diện dùng palette/font của T+ Cabinet. Cabinet không đổi tên.

| Yêu cầu theo mẫu mới | Thực hiện |
|---|---|
| Một cửa sổ, APPLY/CANCEL | Có, theo bố cục Font/Dimension/Text/Deep Scan |
| Font/size pt hoặc mm, Bold/Italic | Có; mm quy đổi sang pt theo mẫu |
| Màu Dimension/Text | Material native, bao gồm Text có leader |
| Unit mm/cm/m/inch/ft, Precision, Show Unit | Áp UnitsOptions toàn model, dạng Decimal |
| Deep Scan | Tự chạy khi APPLY; Group/Component, cả entity ẩn/khóa; mỗi definition một lần |
| Font/cỡ chữ Dim | Nút mở Model Info → Dimensions; chỉnh và Update selected dimensions trong SketchUp |
| Font/cỡ chữ Text | font= nếu API hỗ trợ; SU2022 dùng nút Model Info → Text |
| Nội dung/vị trí/hướng chữ/tag/geometry | Giữ nguyên; không make_unique/explode/dựng edge chữ |
| Undo/lỗi | Một operation; lỗi setter abort toàn bộ, không báo đã thành công |
| Scope, preset, tab, Scan riêng | Đã bỏ |
| Kiểm thử | Ruby fixture + UI Edge đạt; native SketchUp, Undo và save/reopen chưa kiểm chứng |

Ô Font/Size không tự ghi font mặc định của Model Info. Để lưu font mặc định vào SKP, chỉnh trực tiếp trong Model Info như mẫu đã hướng dẫn. Báo kết quả APPLY không nhận font Dim đã thay đổi.

API đối chiếu: [Dimension](https://ruby.sketchup.com/Sketchup/Dimension.html), [Text](https://ruby.sketchup.com/Sketchup/Text.html), [Model Info](https://ruby.sketchup.com/UI.html#show_model_info-class_method).
