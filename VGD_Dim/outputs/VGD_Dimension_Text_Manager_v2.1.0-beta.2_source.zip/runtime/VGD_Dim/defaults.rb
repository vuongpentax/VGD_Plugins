# encoding: UTF-8
module VGD
  module Dim
    DEFAULTS = {
      'font' => 'Arial', 'size_pt' => 10.0, 'size_display' => '10 pt',
      'bold' => false, 'italic' => false,
      'dim_color' => '#000000', 'text_color' => '#000000',
      'unit' => 'mm', 'precision' => 0, 'show_unit' => true
    }.freeze
  end
end
