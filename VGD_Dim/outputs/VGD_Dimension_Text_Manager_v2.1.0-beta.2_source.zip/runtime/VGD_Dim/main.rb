# encoding: UTF-8
require 'sketchup.rb'
require 'json'
require_relative 'defaults'
require_relative 'engine'
module VGD
  module Dim
    extend self
    ProfileService.shutdown if defined?(ProfileService)
    def apply_payload(payload)
      settings = JSON.parse(payload)
      result = Engine.apply(Sketchup.active_model, settings)
      message = "VGD DIMENSION & TEXT\n\nĐã APPLY!\n\n" \
        "Dimension: #{result[:dimensions]}\nText: #{result[:texts]}\n" \
        "Groups: #{result[:groups]}\nComponents: #{result[:components]}\n\n" \
        "Đã áp màu và Units/precision vào model.\n"
      message += "Đã áp font cho #{result[:text_fonts]} Text.\n" if result[:text_fonts] > 0
      message += "Font/cỡ chữ của #{result[:text_fonts_pending]} Text: chỉnh trong Model Info → Text.\n" if result[:text_fonts_pending] > 0
      message += "Font/cỡ chữ Dim: Model Info → Dimensions.\nCtrl+S để lưu file."
      UI.messagebox(message)
    rescue StandardError => error
      UI.messagebox("VGD ERROR\n\n#{error.message}")
      puts "[VGD Dim/Text] #{error.class}: #{error.message}"
    end
    def open_model_info(page)
      return if UI.show_model_info(page)
      UI.messagebox("Mở Window → Model Info → #{page}.")
    rescue StandardError
      UI.messagebox("Mở Window → Model Info → #{page}.")
    end
    def reload_extension
      load File.join(__dir__, 'reload.rb')
    end
    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        return
      end
      dialog = UI::HtmlDialog.new(dialog_title: 'VGD Dimension & Text Manager',
        preferences_key: 'VGDDimTextManager', scrollable: true, resizable: false,
        width: 560, height: 760, style: UI::HtmlDialog::STYLE_DIALOG)
      @dialog = dialog
      dialog.set_file(File.join(__dir__, 'dialog.html'))
      dialog.add_action_callback('apply') { |_, payload| apply_payload(payload) }
      dialog.add_action_callback('open_dim_info') { open_model_info('Dimensions') }
      dialog.add_action_callback('open_text_info') { open_model_info('Text') }
      dialog.add_action_callback('cancel') { dialog.close }
      dialog.set_on_closed { @dialog = nil if @dialog.equal?(dialog) }
      dialog.show
    end
    unless @command
      @command = UI::Command.new('VGD Dimension & Text Manager') { show_dialog }
      @command.small_icon = @command.large_icon = File.join(__dir__, 'dim.svg')
      UI.menu('Extensions').add_item(@command) unless file_loaded?(__FILE__)
      @toolbar ||= UI::Toolbar.new('VGD Dimension & Text Manager')
      @toolbar.add_item(@command)
      UI.menu('Extensions').add_item('Hiện toolbar VGD Dim/Text') { @toolbar.show }
      UI.menu('Extensions').add_item('Nạp lại VGD Dim/Text') { reload_extension }
      file_loaded(__FILE__)
    end
    @command.tooltip = 'VGD Dimension & Text Manager'
    @command.status_bar_text = 'Màu Dim/Text, đơn vị và quét sâu toàn model. Font Dim qua Model Info.'
  end
end
