# T+ Dimension & Text Manager · 2.1.0-beta.1

Bản đơn giản theo mẫu DIMENSION_TEXT_REFERENCE.rb bạn gửi ngày 2026-10-02. Nâng cấp cùng extension T+ Dim, giữ loader tplus_dim.rb.

1. Mở Extensions → T+ Dimension & Text Manager hoặc nút toolbar T+.
2. Chọn font, size pt/mm, bold/italic, màu Dimension/Text và Unit/Precision/Show Unit.
3. Bấm APPLY. Plugin tự đi sâu vào Group và Component của toàn model, kể cả annotation ẩn. Text có leader cũng thuộc Text. Definition chia sẻ được xử lý một lần.
4. Chỉnh font/cỡ chữ Dim bằng nút Model Info → Dimensions và Update selected dimensions. Trên SketchUp 2022, dùng nút Model Info → Text cho font/cỡ chữ Text.
5. Ctrl+S lưu file để chuyển máy/người nhận. Màu và Units được lưu trong model; font mặc định do Model Info lưu.

APPLY có một Undo, chỉ đổi material và UnitsOptions; Text font được áp khi có font=. Giữ nội dung, vị trí, hướng chữ, điểm đo, tag, geometry và trạng thái khóa/ẩn. Không tạo chữ edge/face. Không có tab, preset, scope, bước Scan riêng hoặc dịch vụ chạy nền.

Size mm quy đổi thành pt theo mẫu (mm × 72 / 25.4), sau đó Text Font API nhận pt nguyên. Đây là quy đổi đầu vào, không phải Height native. Font Dimension không tự áp từ ô font trong cửa sổ; Model Info quản lý phần này.

## Cài đặt / nạp bản mới

RBZ: outputs/TPlus_Dimension_Text_Manager_v2.1.0-beta.1.rbz. Cài bằng Extension Manager → Install Extension.

Máy nhà: dev/deploy.ps1 cài 9 file được liệt kê vào Plugins của SketchUp 2022, sao lưu file thay đổi và đối chiếu SHA256. Không ghi plugin khác.

Nếu SketchUp đang mở, khởi động lại để nạp đầy đủ tên menu mới. Hoặc mở Window → Ruby Console và chạy:

```ruby
load File.join(Sketchup.find_support_file('Plugins'), 'TPlus_Dim', 'reload.rb')
```

## Kiểm tra

- dev/check_ruby.cjs: cú pháp Ruby và fixture quét sâu, definition chia sẻ/cycle, font Text tùy API, Units, bảo toàn nội dung/vị trí và abort.
- dev/test_ui.cjs: giao diện một trang trong Edge, payload APPLY, đổi mm/pt, Model Info, CANCEL, input lỗi và footer.
- dev/native_smoke.rb: chỉ chạy thủ công trong model thử trống; không chạy trên model đang làm.
- Xem outputs/VALIDATION.json. Bản này chưa được kiểm thử tương tác thực tế trong SketchUp.
