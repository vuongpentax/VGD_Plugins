# T+ Dimension & Text Manager

Yêu cầu mới nhất là mẫu `DIMENSION_TEXT_REFERENCE.rb` ngày 2026-10-02, thay thế thiết kế Annotation Manager trước đó.

- Giữ loader tplus_dim.rb, namespace TPlus::Dim và thư mục TPlus_Dim để nâng cấp cùng extension.
- Một cửa sổ, một APPLY: font/size pt hoặc mm, bold/italic, màu Dim/Text, Units/precision/show unit và quét sâu toàn model.
- Không có preset, tab, scope, Scan riêng, mesh/edge chữ hoặc observer chạy nền.
- mm được quy đổi sang pt theo mẫu; không gọi đây là Height native của SketchUp.
- Font native Dimension chỉnh trong Model Info. Text font chỉ áp nếu entity hỗ trợ font=; báo đúng kết quả.
- APPLY đổi UnitsOptions toàn model và material native trong một operation. Giữ nội dung, vị trí, điểm đo, hướng chữ, tag, trạng thái ẩn/khóa và geometry.
- Definition chia sẻ xử lý một lần, không make_unique. Group không đếm hai lần như Component.
- Chỉ deploy file trong dev/deploy.ps1 vào SketchUp 2022. Không sửa Cabinet/plugin khác.
- Kiểm tra Ruby, quét sâu và UI; phân biệt mô phỏng với kiểm thử thực tế trong SketchUp.
