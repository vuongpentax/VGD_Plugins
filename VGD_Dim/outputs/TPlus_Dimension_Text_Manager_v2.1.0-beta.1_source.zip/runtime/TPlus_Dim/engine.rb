# encoding: UTF-8
module TPlus
  module Dim
    module Engine
      extend self
      UNITS = {'mm' => 2, 'cm' => 3, 'm' => 4, 'inch' => 0, 'ft' => 1}.freeze unless const_defined?(:UNITS, false)
      def mm_to_pt(mm)
        Float(mm) * 72.0 / 25.4
      end
      def validate(settings)
        raise ArgumentError, 'Dữ liệu không hợp lệ.' unless settings.is_a?(Hash)
        config = DEFAULTS.merge(settings.select { |key, _| DEFAULTS.key?(key) })
        config['font'] = config['font'].to_s.strip
        raise ArgumentError, 'Hãy chọn font.' if config['font'].empty?
        config['size_pt'] = Float(config['size_pt'])
        raise ArgumentError, 'Cỡ chữ phải từ 1 đến 1000 pt sau quy đổi.' unless config['size_pt'].finite? && config['size_pt'].between?(1, 1000)
        %w[dim_color text_color].each do |key|
          raise ArgumentError, 'Màu không hợp lệ.' unless /\A#[0-9a-fA-F]{6}\z/.match?(config[key].to_s)
        end
        raise ArgumentError, 'Đơn vị không hợp lệ.' unless UNITS.key?(config['unit'])
        config['precision'] = Integer(config['precision'])
        raise ArgumentError, 'Precision phải từ 0 đến 4.' unless config['precision'].between?(0, 4)
        %w[bold italic show_unit].each do |key|
          raise ArgumentError, 'Giá trị checkbox không hợp lệ.' unless [true, false].include?(config[key])
        end
        config
      end
      def get_material(model, name, hex)
        # A different color gets a different material: do not recolor other entities
        # that happen to share an earlier T+ material.
        rgb = hex.delete('#').scan(/../).map { |part| part.to_i(16) }
        name = "#{name}_#{hex.delete('#').upcase}"
        material = model.materials[name]
        if material && [material.color.red, material.color.green, material.color.blue] == rgb
          return material
        end
        material = model.materials.add(name)
        material.color = Sketchup::Color.new(*rgb)
        material
      end
      def scan_entities(entities, settings, processed, stats)
        entities.each do |entity|
          next unless entity.valid?
          if entity.is_a?(Sketchup::Dimension)
            entity.material = settings.fetch('dim_material')
            stats[:dimensions] += 1
          elsif entity.is_a?(Sketchup::Text)
            entity.material = settings.fetch('text_material')
            if entity.respond_to?(:font=)
              entity.font = {name: settings['font'], size: settings['size_pt'].to_i,
                             bold: settings['bold'], italic: settings['italic']}
              stats[:text_fonts] += 1
            else
              stats[:text_fonts_pending] += 1
            end
            stats[:texts] += 1
          elsif entity.is_a?(Sketchup::Group) || entity.is_a?(Sketchup::ComponentInstance)
            stats[entity.is_a?(Sketchup::Group) ? :groups : :components] += 1
            definition = entity.definition
            next if processed[definition.object_id]
            processed[definition.object_id] = true
            scan_entities(definition.entities, settings, processed, stats)
          end
        end
      end
      def apply_units(model, settings)
        units = model.options['UnitsOptions']
        units['LengthFormat'] = Length::Decimal
        units['LengthUnit'] = UNITS.fetch(settings['unit'])
        units['LengthPrecision'] = settings['precision']
        units['SuppressUnitsDisplay'] = !settings['show_unit']
      end
      def apply(model, settings)
        config = validate(settings)
        stats = {dimensions: 0, texts: 0, groups: 0, components: 0,
                 text_fonts: 0, text_fonts_pending: 0}
        model.start_operation('T+ Dimension & Text Manager', true)
        begin
          config['dim_material'] = get_material(model, 'T+_DIM_COLOR', config['dim_color'])
          config['text_material'] = get_material(model, 'T+_TEXT_COLOR', config['text_color'])
          apply_units(model, config)
          scan_entities(model.entities, config, {}, stats)
          model.commit_operation
        rescue StandardError
          model.abort_operation
          raise
        end
        model.active_view.invalidate
        stats
      end
    end
  end
end
