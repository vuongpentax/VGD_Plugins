'use strict';
const field = id => document.getElementById(id);
function mmToPt(mm) { return mm * 72 / 25.4; }
function applySettings(event) {
  if (event) event.preventDefault();
  const size = Number(field('size').value);
  const unit = field('size_unit').value;
  const pt = unit === 'mm' ? mmToPt(size) : size;
  field('error').hidden = true;
  if (!Number.isFinite(pt) || size < 1 || pt < 1 || pt > 1000) {
    field('error').textContent = 'Cỡ chữ phải từ 1 đến 1000 pt sau quy đổi.';
    field('error').hidden = false;
    return;
  }
  const settings = {
    font: field('font').value, size_pt: pt, size_display: size + ' ' + unit,
    bold: field('bold').checked, italic: field('italic').checked,
    dim_color: field('dim_color').value, text_color: field('text_color').value,
    unit: field('unit').value, precision: field('precision').value,
    show_unit: field('show_unit').checked
  };
  sketchup.apply(JSON.stringify(settings));
}
function openDimInfo() { sketchup.open_dim_info(); }
field('settings').addEventListener('submit', applySettings);
field('open_dim_info').addEventListener('click', openDimInfo);
field('open_text_info').addEventListener('click', () => sketchup.open_text_info());
field('cancel').addEventListener('click', () => sketchup.cancel());
