# encoding: UTF-8
require 'sketchup.rb'
# Preflight before closing the old UI. Reload only this extension.
files = %w[defaults engine main].map { |name| File.join(__dir__, name + '.rb') }
files.each { |path| RubyVM::InstructionSequence.compile_file(path) }
if defined?(TPlus::Dim)
  dialog = TPlus::Dim.instance_variable_get(:@dialog)
  dialog.close if dialog
  TPlus::Dim::ProfileService.shutdown if defined?(TPlus::Dim::ProfileService)
  TPlus::Dim.detach_model if TPlus::Dim.respond_to?(:detach_model)
  timer = TPlus::Dim.instance_variable_get(:@sync_timer)
  UI.stop_timer(timer) if timer
  watch = TPlus::Dim.instance_variable_get(:@app_watch)
  Sketchup.remove_observer(watch) if watch
  TPlus::Dim.instance_variable_set(:@app_watch, nil)
  TPlus::Dim.instance_variable_set(:@sync_timer, nil)
  %i[DEFAULTS VERSION].each do |name|
    TPlus::Dim.send(:remove_const, name) if TPlus::Dim.const_defined?(name, false)
  end
  TPlus::Dim.const_set(:VERSION, '2.1.0-beta.1'.freeze)
end
files.each { |path| load path }
TPlus::Dim.show_dialog
