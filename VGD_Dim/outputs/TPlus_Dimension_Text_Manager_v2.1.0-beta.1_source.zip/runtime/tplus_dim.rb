# encoding: UTF-8
require 'sketchup.rb'
require 'extensions.rb'
module TPlus
  module Dim
    VERSION = '2.1.0-beta.1'.freeze unless const_defined?(:VERSION)
    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new('T+ Dimension & Text Manager', 'TPlus_Dim/main')
      extension.description = 'Cửa sổ đơn giản chỉnh màu Dimension/Text, Units và font Text khi API hỗ trợ; mở Model Info cho font native.'
      extension.version = VERSION
      extension.creator = 'T+'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
