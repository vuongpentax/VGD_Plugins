# encoding: UTF-8
# Optional: load from Ruby Console in an EMPTY test model, then call:
# TPlusDimNativeSmoke.run
# This script is not executed by the automated fixture checks.
module TPlusDimNativeSmoke
  def self.run
    model = Sketchup.active_model
    raise 'Use an empty test model.' unless model.entities.empty?
    model.start_operation('T+ test annotations', true)
    begin
      group = model.entities.add_group
      dim = group.entities.add_dimension_linear([0,0,0], [100.mm,0,0], [0,20.mm,0])
      text = group.entities.add_text('T+ native test', [0,30.mm,0])
      model.commit_operation
    rescue StandardError
      model.abort_operation
      raise
    end
    result = TPlus::Dim::Engine.apply(model, {'dim_color'=>'#112233','text_color'=>'#AABBCC'})
    raise 'Counts wrong' unless result[:dimensions] == 1 && result[:texts] == 1
    raise 'Native entities missing' unless dim.valid? && text.valid?
    raise 'Units wrong' unless model.options['UnitsOptions']['LengthUnit'] == 2
    puts "Native check: #{result}. Verify rendering, Undo, save/reopen manually."
    result
  end
end
