# Simulation: assertions cover traversal and operations, not native SketchUp rendering.
def check(value, message)
  raise message unless value
end
def run_engine_tests
  engine = TPlus::Dim::Engine
  model = Sketchup::FakeModel.new
  Sketchup.active_model = model
  dim = Sketchup::DimensionLinear.new
  dim.text = 'Custom dimension'; dim.layer = 'Measurements'; dim.hidden = true
  dim.has_aligned_text = true; dim.aligned_text_position = 0
  text = Sketchup::Text.new
  text.leader = false
  label = Sketchup::Text.new
  label.leader = true
  def label.font=(value); @applied_font = value; end
  def label.applied_font; @applied_font; end
  root_dim = Sketchup::DimensionRadial.new
  model.entities << root_dim
  group = model.entities.add_group
  group.locked = true
  group.entities << dim
  group.entities << text
  shared = Sketchup::Definition.new(model, [label])
  first = Sketchup::ComponentInstance.new(shared)
  second = Sketchup::ComponentInstance.new(shared)
  group.entities << first
  model.entities << second
  # Cyclic fixture exercises recursion guard; Group is a ComponentInstance subclass here.
  shared.entities << Sketchup::ComponentInstance.new(group.definition)
  edge = Sketchup::Edge.new([])
  old_material = model.materials.add('T+_DIM_COLOR')
  edge.material = old_material; model.entities << edge
  old_material.color = Sketchup::Color.new(31, 32, 33)
  snapshot = [dim.text, dim.start_point, dim.end_point, dim.offset_vector.to_a,
              dim.layer, dim.hidden?, dim.has_aligned_text?, dim.aligned_text_position,
              text.text, text.point, text.vector, text.has_leader?, label.has_leader?]
  config = {'font'=>'Tahoma', 'size_pt'=>engine.mm_to_pt(3.5),
            'size_display'=>'3.5 mm', 'bold'=>true, 'italic'=>true,
            'dim_color'=>'#112233', 'text_color'=>'#AABBCC',
            'unit'=>'ft', 'precision'=>'3', 'show_unit'=>false}
  result = engine.apply(model, config)
  check(result == {dimensions:2,texts:2,groups:1,components:3,text_fonts:1,text_fonts_pending:1}, 'Traversal counts, dedup or font capability wrong')
  check(model.operations == 1 && model.commits == 1 && model.aborts == 0, 'Expected one operation')
  check(model.operation_flags.first == ['T+ Dimension & Text Manager',true], 'Unexpected operation flags')
  check([dim.material.color.red,dim.material.color.green,dim.material.color.blue] == [17,34,51], 'Dimension color wrong')
  check(text.material.equal?(label.material) && text.material.color.blue == 204, 'Text/leader color wrong')
  check(dim.material.equal?(root_dim.material), 'Dimension materials not shared')
  check(first.definition.equal?(second.definition) && group.locked?, 'Definition/lock changed')
  check(edge.material.equal?(old_material) && old_material.color.red == 31, 'Unrelated geometry recolored')
  check(label.applied_font == {name:'Tahoma',size:9,bold:true,italic:true}, 'mm to pt/integer Text font wrong')
  check(snapshot == [dim.text,dim.start_point,dim.end_point,dim.offset_vector.to_a,
                     dim.layer,dim.hidden?,dim.has_aligned_text?,dim.aligned_text_position,
                     text.text,text.point,text.vector,text.has_leader?,label.has_leader?], 'Native content or position changed')
  units = model.options['UnitsOptions']
  check(units == {'LengthUnit'=>1,'LengthFormat'=>0,'LengthPrecision'=>3,'SuppressUnitsDisplay'=>true}, 'Global Units wrong')
  engine.apply(model,config)
  check(model.materials.items.length == 3, 'Repeated Apply creates duplicate materials')
  puts 'PASS: recursive native traversal, shared/cyclic definitions, hidden/locked annotations, preserved content/geometry, mm conversion and optional Text font'
  TPlus::Dim::Engine::UNITS.each do |unit,value|
    m = Sketchup::FakeModel.new
    engine.apply(m,{'unit'=>unit})
    check(m.options['UnitsOptions']['LengthUnit'] == value, "Wrong unit #{unit}")
  end
  invalids = [{'size_pt'=>0},{'size_pt'=>Float::NAN},{'size_pt'=>1001},
              {'precision'=>5},{'precision'=>'1.5'},{'unit'=>'bad'},
              {'dim_color'=>'#bad'}, {'font'=>''}, {'bold'=>'false'}, {'show_unit'=>nil}]
  invalids.each do |bad|
    m = Sketchup::FakeModel.new
    begin
      engine.apply(m,bad)
      raise "Accepted invalid configuration: #{bad}"
    rescue ArgumentError
      check(m.operations == 0 && m.materials.items.empty?, 'Invalid input mutated model')
    end
  end
  m = Sketchup::FakeModel.new
  broken = Sketchup::Text.new
  def broken.material=(_); raise 'Setter failed'; end
  m.entities << broken
  begin
    engine.apply(m,{})
    raise 'Apply swallowed native error'
  rescue RuntimeError => e
    check(e.message == 'Setter failed' && m.aborts == 1 && m.commits == 0, 'Failure did not abort')
  end
  puts 'PASS: model units, repeat Apply, pre-mutation validation and failure abort'
end
