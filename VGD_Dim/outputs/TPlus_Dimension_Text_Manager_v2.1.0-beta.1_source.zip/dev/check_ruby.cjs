const fs = require('fs'), path = require('path');
const deps = path.resolve(__dirname, '../../TPlus_Cabinet_Codex_Handoff_2026-10-01/cabinet_dev/node_modules');
const {DefaultRubyVM} = require(path.join(deps, '@ruby/wasm-wasi/dist/cjs/node.js'));
(async () => {
  const wasm = await WebAssembly.compile(fs.readFileSync(require.resolve(path.join(deps, '@ruby/3.2-wasm-wasi/dist/ruby+stdlib.wasm'))));
  const {vm} = await DefaultRubyVM(wasm);
  const root = path.resolve(__dirname, '../runtime');
  const runtime = ['tplus_dim.rb', ...['defaults','engine','main','reload'].map(n=>'TPlus_Dim/'+n+'.rb')];
  const literal = value => JSON.stringify(Buffer.from(value, 'utf8').toString('base64')) + '.unpack1("m0")';
  for (const file of runtime) {
    vm.eval('RubyVM::InstructionSequence.compile(' + literal(fs.readFileSync(path.join(root, file), 'utf8')) + ')');
    console.log('Syntax OK:', file);
  }
  vm.eval('RubyVM::InstructionSequence.compile(' + literal(fs.readFileSync(path.join(__dirname,'native_smoke.rb'),'utf8')) + ')');
  console.log('Syntax OK: opt-in native smoke script (not executed)');
  vm.eval(fs.readFileSync(path.join(__dirname, 'test_fixture.rb'), 'utf8'));
  for (const name of ['defaults','engine']) vm.eval(fs.readFileSync(path.join(root,'TPlus_Dim',name+'.rb'),'utf8'));
  vm.eval(fs.readFileSync(path.join(__dirname, 'test_engine.rb'), 'utf8'));
  vm.eval('run_engine_tests; $stdout.flush');
  const main = fs.readFileSync(path.join(root,'TPlus_Dim/main.rb'),'utf8').replace(/^require[^\n]*\n/gm,'');
  vm.eval(main); vm.eval(main);
  vm.eval('raise "Toolbar moved/duplicated" unless UI.toolbars.length == 1 && UI.toolbars.first.events == [:add]; raise "Background profile service installed" if defined?(TPlus::Dim::ProfileService); puts "PASS: one toolbar, no startup layout changes or background profile service"; $stdout.flush');
  vm.eval(`
    TPlus::Dim.show_dialog
    dialog = TPlus::Dim.instance_variable_get(:@dialog)
    raise "Old callbacks remain" unless dialog.callbacks.keys.sort == %w[apply cancel open_dim_info open_text_info]
    TPlus::Dim.show_dialog
    raise "Duplicate dialog" unless TPlus::Dim.instance_variable_get(:@dialog).equal?(dialog) && dialog.fronts == 1
    dialog.callbacks['open_dim_info'].call(nil)
    dialog.callbacks['open_text_info'].call(nil)
    raise "Model Info page wrong" unless UI.info_pages == %w[Dimensions Text]
    UI.info_result = false
    dialog.callbacks['open_dim_info'].call(nil)
    raise "False Model Info result ignored" unless UI.messages.last.include?('Window')
    Sketchup.active_model = Sketchup::FakeModel.new
    Sketchup.active_model.entities << Sketchup::DimensionLinear.new
    Sketchup.active_model.entities << Sketchup::Text.new
    dialog.callbacks['apply'].call(nil, '{}')
    raise "Callback did not apply" unless Sketchup.active_model.commits == 1
    raise "Unsupported font falsely successful" unless UI.messages.last.include?('Model Info → Text') && UI.messages.last.include?('Model Info → Dimensions')
    dialog.callbacks['apply'].call(nil, 'bad json')
    raise "Bad callback payload mutated model" unless Sketchup.active_model.operations == 1 && UI.messages.last.start_with?('T+ ERROR')
    dialog.callbacks['cancel'].call(nil)
    raise "Dialog reference retained" unless TPlus::Dim.instance_variable_get(:@dialog).nil?
    puts "PASS: dialog singleton, simple callbacks, Model Info, honest Apply result, malformed payload and Cancel"
    $stdout.flush
  `);
})().catch(error => {console.error(error); process.exitCode = 1;});
