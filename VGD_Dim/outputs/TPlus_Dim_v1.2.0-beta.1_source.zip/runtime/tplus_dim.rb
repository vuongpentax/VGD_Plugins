# encoding: UTF-8
require 'sketchup.rb'
require 'extensions.rb'

module TPlus
  module Dim
    VERSION = '1.2.0-beta.1'.freeze unless const_defined?(:VERSION)
    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new('T+ Dim', 'TPlus_Dim/main')
      extension.description = 'Chỉnh dim native, trả dim T+ cũ về native và mở Model Info để đồng bộ font/cỡ chữ. SketchUp 2022 trở lên.'
      extension.version = VERSION
      extension.creator = 'T+'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
