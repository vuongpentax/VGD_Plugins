(function () {
  'use strict';
  var context = null, modelId = null, busy = false;
  var el = function (id) { return document.getElementById(id); };
  function call(action, payload) {
    if (window.sketchup && typeof window.sketchup[action] === 'function') { window.sketchup[action](payload); return true; }
    return false;
  }
  function status(message, error) { el('model_status').textContent = message; el('model_status').classList.toggle('error', !!error); }
  function controls() {
    el('position').disabled = el('alignment').value === 'screen';
    el('dim_color').disabled = !el('change_color').checked;
    el('apply').disabled = busy || !context || !context.can_apply || !!context.blocked;
    el('restore').disabled = busy || !context || !context.can_apply || !!context.blocked || !context.legacy;
  }
  function receive(next, settings) {
    if (next.model_id !== modelId) {
      modelId = next.model_id;
      ['arrow', 'alignment', 'position', 'dim_color'].forEach(function (key) { if (settings[key] !== undefined) el(key).value = settings[key]; });
      ['deep', 'change_color'].forEach(function (key) { if (settings[key] !== undefined) el(key).checked = settings[key]; });
    }
    context = next; busy = false;
    el('selection_mode').textContent = next.dimensions + ' dim' + (next.legacy ? ' · ' + next.legacy + ' T+ cũ' : '');
    status(next.blocked || (next.can_apply ? 'Sẵn sàng chỉnh vùng chọn.' + (next.locked ? ' Bỏ qua nhóm khóa.' : '') : 'Chọn dim hoặc nhóm chứa dim. Font/cỡ chữ có thể chỉnh trong Model Info.'), !!next.blocked);
    controls();
  }
  function payload() {
    return {context_token: context && context.context_token, deep: el('deep').checked,
      change_color: el('change_color').checked, dim_color: el('dim_color').value,
      arrow: el('arrow').value, alignment: el('alignment').value, position: el('position').value};
  }
  function apply(action) {
    if (busy || !context || !context.can_apply || context.blocked) return;
    busy = true; controls(); status(action === 'restore' ? 'Đang khôi phục dim native…' : 'Đang chỉnh dim native…');
    if (!call(action, JSON.stringify(payload()))) { busy = false; controls(); status('Thao tác này hoạt động trong SketchUp.'); }
  }
  function refresh() {
    context = null; controls();
    if (!call('refresh', JSON.stringify({deep: el('deep').checked}))) status('Lấy vùng chọn hoạt động trong SketchUp.');
  }
  el('dim_info').addEventListener('click', function () { if (!call('model_info', 'Dimensions')) status('Mở Window → Model Info → Dimensions trong SketchUp.'); });
  el('text_info').addEventListener('click', function () { if (!call('model_info', 'Text')) status('Mở Window → Model Info → Text trong SketchUp.'); });
  el('apply').addEventListener('click', function () { apply('apply'); });
  el('restore').addEventListener('click', function () { apply('restore'); });
  el('refresh').addEventListener('click', refresh);
  el('deep').addEventListener('change', refresh);
  el('close').addEventListener('click', function () { call('close'); });
  document.addEventListener('change', controls);
  el('theme').addEventListener('click', function () {
    var dark = !document.body.classList.contains('dark');
    document.body.classList.toggle('dark', dark); el('theme').textContent = dark ? 'Sáng' : 'Tối';
    try { localStorage.setItem('tplus_theme', dark ? 'dark' : 'light'); } catch (_error) {}
  });
  try { var dark = localStorage.getItem('tplus_theme') === 'dark'; document.body.classList.toggle('dark', dark); el('theme').textContent = dark ? 'Sáng' : 'Tối'; } catch (_error) {}
  window.TPlusDim = {receive: receive, status: status};
  controls();
  if (!call('ready')) status('Bản xem trước. Chỉnh dim và mở Model Info trong SketchUp.');
})();
