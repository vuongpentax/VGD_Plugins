# encoding: UTF-8
require 'sketchup.rb'
require 'json'
require_relative 'defaults'
require_relative 'custom_dim'
require_relative 'engine'

module TPlus
  module Dim
    extend self
    PREF_KEY = 'TPlus_Dim'.freeze unless const_defined?(:PREF_KEY, false)
    # Shut down beta 2 services if this source is loaded into an existing session.
    ProfileService.shutdown if defined?(ProfileService)

    class SelectionWatch < Sketchup::SelectionObserver
      def onSelectionBulkChange(_selection); Dim.queue_sync; end
      def onSelectionAdded(_selection, _entity); Dim.queue_sync; end
      def onSelectionRemoved(_selection, _entity); Dim.queue_sync; end
      def onSelectionCleared(_selection); Dim.queue_sync; end
    end
    class ModelWatch < Sketchup::ModelObserver
      def onActivePathChanged(_model); Dim.queue_sync; end
      def onTransactionUndo(_model); Dim.queue_sync; end
      def onTransactionRedo(_model); Dim.queue_sync; end
      def onTransactionCommit(_model); Dim.queue_sync; end
    end
    class AppWatch < Sketchup::AppObserver
      def onActivateModel(_model); Dim.attach_model; Dim.queue_sync; end
      def onNewModel(_model); Dim.attach_model; Dim.queue_sync; end
      def onOpenModel(_model); Dim.attach_model; Dim.queue_sync; end
    end
    def settings
      return @settings if @settings
      saved = JSON.parse(Sketchup.read_default(PREF_KEY, 'native_settings', '{}')) rescue {}
      @settings = Engine.validate(saved.is_a?(Hash) ? saved : {})
    rescue ArgumentError
      @settings = DEFAULTS.dup
    end
    def attach_model
      model = Sketchup.active_model
      return if @watched_model == model
      detach_model
      @watched_model = model
      @selection_watch = SelectionWatch.new
      @model_watch = ModelWatch.new
      model.selection.add_observer(@selection_watch)
      model.add_observer(@model_watch)
    end
    def detach_model
      if @watched_model
        @watched_model.selection.remove_observer(@selection_watch) if @selection_watch
        @watched_model.remove_observer(@model_watch) if @model_watch
      end
      @watched_model = @selection_watch = @model_watch = nil
    rescue StandardError
      @watched_model = @selection_watch = @model_watch = nil
    end
    def queue_sync
      return unless @dialog && @ready
      UI.stop_timer(@sync_timer) if @sync_timer
      @sync_timer = UI.start_timer(0.12, false) { @sync_timer = nil; sync }
    end
    def sync
      return unless @dialog && @ready
      attach_model
      context = Engine.context(Sketchup.active_model, settings)
      @dialog.execute_script("TPlusDim.receive(#{JSON.generate(context)}, #{JSON.generate(settings)});")
    rescue StandardError => error
      report(error.message, true)
    end
    def report(message, error = false)
      @dialog.execute_script("TPlusDim.status(#{JSON.generate(message)}, #{error ? 'true' : 'false'});") if @dialog && @ready
    end
    def apply_payload(payload, restore_only = false)
      data = payload.is_a?(String) ? JSON.parse(payload) : payload
      raise ArgumentError, 'Cấu hình không hợp lệ.' unless data.is_a?(Hash)
      config = Engine.validate(data)
      result = Engine.apply(Sketchup.active_model, config, data['context_token'], restore_only)
      @settings = config
      Sketchup.write_default(PREF_KEY, 'native_settings', JSON.generate(config)) unless restore_only
      sync
      message = restore_only ? "Đã trả #{result[:restored]} dim/text T+ về native" : "Đã chỉnh #{result[:dimensions]} dim native"
      message += " · khôi phục #{result[:restored]} dim/text T+ cũ" if !restore_only && result[:restored] > 0
      message += " · tách riêng #{result[:unique]} nhóm" if result[:unique] > 0
      message += " · bỏ qua #{result[:locked]} nhóm khóa" if result[:locked] > 0
      report(message + '. Có thể Undo; Ctrl+S để lưu SKP.')
    rescue StandardError => error
      puts "[T+ Dim] #{error.class}: #{error.message}\n#{error.backtrace.join("\n")}"
      sync
      report(error.message, true)
    end
    def open_model_info(page)
      name = page == 'Text' ? 'Text' : 'Dimensions'
      ok = UI.show_model_info(name)
      report(ok ? 'Chỉnh Font, Points/Height trong Model Info; bấm Update selected dimensions để cập nhật dim đã chọn. Ctrl+S để lưu theo file.' : 'Mở Window → Model Info → Dimensions để chỉnh font và cỡ chữ.', !ok)
    end
    def reload_extension
      load File.join(__dir__, 'reload.rb')
    end
    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        return
      end
      @ready = false
      @settings = nil
      dialog = UI::HtmlDialog.new(
        dialog_title: 'T+ Dim · Dim native', preferences_key: PREF_KEY,
        scrollable: true, resizable: true, width: 470, height: 720,
        min_width: 380, min_height: 500, style: UI::HtmlDialog::STYLE_DIALOG
      )
      @dialog = dialog
      dialog.set_file(File.join(__dir__, 'dialog.html'))
      dialog.add_action_callback('ready') { @ready = true; attach_model; sync }
      dialog.add_action_callback('refresh') do |_, payload|
        data = payload.is_a?(String) ? JSON.parse(payload) : payload
        settings['deep'] = data['deep'] == true if data.is_a?(Hash)
        sync
      end
      dialog.add_action_callback('apply') { |_, payload| apply_payload(payload) }
      dialog.add_action_callback('restore') { |_, payload| apply_payload(payload, true) }
      dialog.add_action_callback('model_info') { |_, page| open_model_info(page) }
      dialog.add_action_callback('close') { dialog.close }
      dialog.set_on_closed do
        if @dialog.equal?(dialog)
          UI.stop_timer(@sync_timer) if @sync_timer
          @sync_timer = nil
          @dialog = nil
          @ready = false
          detach_model
          Sketchup.remove_observer(@app_watch) if @app_watch
          @app_watch = nil
        end
      end
      @app_watch ||= AppWatch.new
      Sketchup.add_observer(@app_watch)
      dialog.show
    end
    unless @command
      @command = command = UI::Command.new('T+ Dim') { show_dialog }
      command.small_icon = command.large_icon = File.join(__dir__, 'dim.svg')
      command.tooltip = 'T+ Dim · Dim native / Model Info'
      command.status_bar_text = 'Chỉnh dim native và mở Model Info để đồng bộ font/cỡ chữ.'
      UI.menu('Extensions').add_item(command) unless file_loaded?(__FILE__)
      unless @toolbar
        @toolbar = UI::Toolbar.new('T+ Dim')
        @toolbar.add_item(command)
      end
      UI.menu('Extensions').add_item('Hiện toolbar T+ Dim') { @toolbar.show }
      UI.menu('Extensions').add_item('Nạp lại T+ Dim') { reload_extension }
      file_loaded(__FILE__)
    end
  end
end
