# encoding: UTF-8
# Compatibility only: restore native sources from beta 2. Never create geometry.
module TPlus
  module Dim
    module CustomDim
      extend self
      DICT = 'TPlus_Dim_Custom'.freeze unless const_defined?(:DICT, false)
      def kind(entity); entity.get_attribute(DICT, 'kind', nil); end
      def view?(entity); %w[dimension text].include?(kind(entity)); end
      def source?(entity); kind(entity) == 'source'; end
      def collection(entity)
        parent = entity.parent
        parent.respond_to?(:entities) ? parent.entities : parent
      end
      def partner(entity)
        pair = entity.get_attribute(DICT, 'pair', nil)
        return nil unless pair
        others = collection(entity).select { |e| e.valid? && e != entity && e.get_attribute(DICT, 'pair', nil) == pair }
        if source?(entity)
          others.select { |e| view?(e) }.min_by(&:persistent_id)
        else
          native = others.find { |e| source?(e) }
          return nil unless native
          displays = collection(entity).select { |e| e.valid? && view?(e) && e.get_attribute(DICT, 'pair', nil) == pair }
          displays.min_by(&:persistent_id) == entity ? native : nil
        end
      end
      def redundant_source?(entity); source?(entity) && partner(entity); end
      def source(entity); view?(entity) ? partner(entity) : entity; end
      def restore(native)
        view = partner(native)
        view.erase! if view && view.valid?
        native.hidden = native.get_attribute(DICT, 'original_hidden', false)
        native.delete_attribute(DICT)
        native
      end
    end
  end
end
