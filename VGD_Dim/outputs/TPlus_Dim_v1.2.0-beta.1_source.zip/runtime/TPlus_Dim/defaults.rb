# encoding: UTF-8
module TPlus
  module Dim
    DEFAULTS = {
      'deep' => true, 'change_color' => false, 'dim_color' => '#0000FF',
      'arrow' => 'keep', 'alignment' => 'aligned', 'position' => 'above'
    }.freeze unless const_defined?(:DEFAULTS, false)
  end
end
