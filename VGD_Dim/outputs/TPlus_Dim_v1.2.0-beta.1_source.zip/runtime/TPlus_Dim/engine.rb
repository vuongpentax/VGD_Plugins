# encoding: UTF-8
module TPlus
  module Dim
    module Engine
      extend self
      def container?(e); e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance); end
      def locked?(e); container?(e) && e.locked?; end
      def children(e); e.is_a?(Sketchup::Group) ? e.entities : e.definition.entities; end
      def target?(e)
        e.is_a?(Sketchup::Dimension) || CustomDim.view?(e) || (e.is_a?(Sketchup::Text) && CustomDim.source?(e))
      end
      def inspect_entities(entities, deep, stats, path = [], ancestry = [])
        entities.each do |e|
          next unless e.valid?
          next if CustomDim.redundant_source?(e) && entities.include?(CustomDim.partner(e))
          current = path + [e.persistent_id]
          if locked?(e)
            stats[:locked] += 1
            stats[:fingerprint] << current + ['locked']
          elsif target?(e)
            stats[:dimensions] += 1 if e.is_a?(Sketchup::Dimension) || CustomDim.kind(e) == 'dimension'
            stats[:legacy] += 1 if CustomDim.view?(e) || CustomDim.source?(e)
            stats[:fingerprint] << current
          elsif deep && container?(e) && !ancestry.include?(e.definition)
            inspect_entities(children(e), deep, stats, current, ancestry + [e.definition])
          end
        end
        stats
      end
      def blocked_context(model)
        path = model.active_path || []
        return 'Đóng nhóm khóa trước khi chỉnh dim.' if path.any? { |e| locked?(e) }
        return 'Đóng chế độ sửa và chọn nhóm cha để chỉnh riêng bản này.' if path.any? { |e| e.definition.instances.length > 1 }
        nil
      end
      def context(model, config)
        stats = inspect_entities(model.selection.to_a, config['deep'], {dimensions: 0, legacy: 0, locked: 0, fingerprint: []})
        token = JSON.generate([model.guid, (model.active_path || []).map(&:persistent_id),
          model.selection.to_a.map(&:persistent_id).sort, config['deep'], stats[:fingerprint]])
        {'model_id' => model.guid, 'dimensions' => stats[:dimensions], 'legacy' => stats[:legacy],
         'locked' => stats[:locked], 'context_token' => token, 'blocked' => blocked_context(model),
         'can_apply' => stats[:dimensions] + stats[:legacy] > 0 && blocked_context(model).nil?}
      end
      def validate(data)
        config = Dim::DEFAULTS.merge(data).select { |k, _| Dim::DEFAULTS.key?(k) }
        %w[deep change_color].each { |k| raise ArgumentError, 'Tùy chọn không hợp lệ.' unless [true, false].include?(config[k]) }
        raise ArgumentError, 'Màu phải ở dạng #RRGGBB.' unless config['dim_color'].is_a?(String) && config['dim_color'].match?(/\A#[0-9a-fA-F]{6}\z/)
        {'arrow' => %w[keep none slash dot closed open], 'alignment' => %w[keep aligned screen], 'position' => %w[keep above center outside]}.each do |k, values|
          raise ArgumentError, "Thông số #{k} không hợp lệ." unless values.include?(config[k])
        end
        config
      end
      def contains_target?(entities, deep, ancestry = [])
        entities.any? do |e|
          next false unless e.valid?
          next false if locked?(e)
          next true if target?(e)
          deep && container?(e) && !ancestry.include?(e.definition) && contains_target?(children(e), deep, ancestry + [e.definition])
        end
      end
      def mutate(entities, config, material, stats, restore_only, ancestry = [])
        entities.reject { |e| CustomDim.redundant_source?(e) && entities.include?(CustomDim.partner(e)) }.each do |e|
          next unless e.valid?
          if locked?(e)
            stats[:locked] += 1
          elsif target?(e)
            native = CustomDim.source(e)
            raise ArgumentError, 'Dim T+ mất nguồn hoặc chỉ sao chép phần chữ. Giữ nguyên đối tượng; cần vẽ lại dim này.' unless native && native.valid?
            if CustomDim.source?(native)
              CustomDim.restore(native)
              stats[:restored] += 1
            end
            next if restore_only || !native.is_a?(Sketchup::Dimension)
            native.material = material if config['change_color']
            unless config['arrow'] == 'keep'
              native.arrow_type = {'none' => Sketchup::Dimension::ARROW_NONE, 'slash' => Sketchup::Dimension::ARROW_SLASH,
                'dot' => Sketchup::Dimension::ARROW_DOT, 'closed' => Sketchup::Dimension::ARROW_CLOSED, 'open' => Sketchup::Dimension::ARROW_OPEN}.fetch(config['arrow'])
            end
            native.has_aligned_text = config['alignment'] == 'aligned' unless config['alignment'] == 'keep'
            if native.is_a?(Sketchup::DimensionLinear) && native.has_aligned_text? && config['position'] != 'keep'
              native.aligned_text_position = {'above' => Sketchup::DimensionLinear::ALIGNED_TEXT_ABOVE,
                'center' => Sketchup::DimensionLinear::ALIGNED_TEXT_CENTER, 'outside' => Sketchup::DimensionLinear::ALIGNED_TEXT_OUTSIDE}.fetch(config['position'])
            end
            stats[:dimensions] += 1
          elsif config['deep'] && container?(e) && !ancestry.include?(e.definition) && contains_target?(children(e), true, ancestry + [e.definition])
            if e.definition.instances.length > 1
              e.make_unique
              stats[:unique] += 1
            end
            mutate(children(e).to_a, config, material, stats, restore_only, ancestry + [e.definition])
          end
        end
      end
      def apply(model, config, token, restore_only = false)
        current = context(model, config)
        raise ArgumentError, 'Vùng chọn đã đổi. Bấm Lấy vùng chọn rồi thử lại.' unless current['context_token'] == token
        raise ArgumentError, current['blocked'] if current['blocked']
        raise ArgumentError, 'Chọn dim hoặc nhóm chứa dim trước.' unless current['can_apply']
        raise ArgumentError, 'Vùng chọn không có dim T+ cũ.' if restore_only && current['legacy'] == 0
        stats = {dimensions: 0, restored: 0, locked: 0, unique: 0}
        started = false
        begin
          model.start_operation(restore_only ? 'T+ Dim · Trả về dim native' : 'T+ Dim · Chỉnh dim native', true)
          started = true
          material = nil
          if config['change_color'] && !restore_only
            color = config['dim_color']
            name = 'T+ DIM ' + color.upcase
            material = model.materials[name]
            expected = [color[1, 2].to_i(16), color[3, 2].to_i(16), color[5, 2].to_i(16)]
            material = nil if material && [material.color.red, material.color.green, material.color.blue] != expected
            unless material
              material = model.materials.add(name)
              material.color = Sketchup::Color.new(*expected)
            end
          end
          original_selection = model.selection.to_a
          replacements = original_selection.select { |e| CustomDim.view?(e) }.map { |e| [e, CustomDim.source(e)] }
          mutate(original_selection, config, material, stats, restore_only)
          replacements.each { |view, native| model.selection.add(native) if !view.valid? && native && native.valid? }
          # Retire beta 2's geometry/auto-new profile in this model, in the same Undo.
          # Never write font defaults to a private dictionary and call it Model Info.
          model.delete_attribute('TPlus_Dim', 'profile_json')
          model.delete_attribute('TPlus_Dim', 'schema')
          model.commit_operation
          started = false
          model.active_view.invalidate
          stats
        rescue StandardError
          model.abort_operation if started
          raise
        end
      end
    end
  end
end
