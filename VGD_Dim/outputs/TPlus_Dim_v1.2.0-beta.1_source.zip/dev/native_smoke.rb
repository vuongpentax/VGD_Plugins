# encoding: UTF-8
# Explicit opt-in: run only in a new empty model.
require 'json'
model = Sketchup.active_model
raise 'Chỉ chạy trên model mới, trống và chưa lưu.' unless model.path.empty? && model.entities.empty? && !model.modified?
load File.expand_path('../runtime/TPlus_Dim/main.rb', __dir__) unless defined?(TPlus::Dim::Engine)
engine = TPlus::Dim::Engine
model.start_operation('T+ Dim · Fixture native', true)
dim = model.entities.add_dimension_linear([0,0,0], [800.mm,0,0], [0,80.mm,0])
dim.text = '800'
model.commit_operation
model.selection.clear
model.selection.add(dim)
config = engine.validate({})
result = engine.apply(model, config, engine.context(model, config)['context_token'])
raise 'Native Above không được đặt.' unless dim.valid? && dim.has_aligned_text? && dim.aligned_text_position == Sketchup::DimensionLinear::ALIGNED_TEXT_ABOVE
raise 'Đã tạo geometry T+.' unless model.entities.to_a == [dim]
puts '[T+ Dim] PASS native: giữ DimensionLinear, đặt Above, không sinh group/edge/face.'
puts '[T+ Dim] Thử tiếp: Model Info → Font/Points/Height → Update selected dimensions; Orbit; Undo/Redo; Save/Open. Chưa tự kiểm chứng các bước này.'
TPlus::Dim.open_model_info('Dimensions')
