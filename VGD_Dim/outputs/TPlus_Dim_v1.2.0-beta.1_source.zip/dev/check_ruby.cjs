const fs = require('fs'), path = require('path');
const deps = path.resolve(__dirname, '../../TPlus_Cabinet_Codex_Handoff_2026-10-01/cabinet_dev/node_modules');
const {DefaultRubyVM} = require(path.join(deps, '@ruby/wasm-wasi/dist/cjs/node.js'));
(async () => {
  const wasm = await WebAssembly.compile(fs.readFileSync(require.resolve(path.join(deps, '@ruby/3.2-wasm-wasi/dist/ruby+stdlib.wasm'))));
  const {vm} = await DefaultRubyVM(wasm);
  const root = path.resolve(__dirname, '../runtime');
  const runtime = ['tplus_dim.rb', ...['defaults','custom_dim','engine','main','reload'].map(n=>'TPlus_Dim/'+n+'.rb')];
  const literal = value => JSON.stringify(Buffer.from(value, 'utf8').toString('base64')) + '.unpack1("m0")';
  for (const file of runtime) {
    vm.eval('RubyVM::InstructionSequence.compile(' + literal(fs.readFileSync(path.join(root, file), 'utf8')) + ')');
    console.log('Syntax OK:', file);
  }
  vm.eval(fs.readFileSync(path.join(__dirname, 'test_fixture.rb'), 'utf8'));
  for (const name of ['defaults','custom_dim','engine']) vm.eval(fs.readFileSync(path.join(root,'TPlus_Dim',name+'.rb'),'utf8'));
  vm.eval(fs.readFileSync(path.join(__dirname, 'test_engine.rb'), 'utf8'));
  vm.eval('run_engine_tests; $stdout.flush');
  const main = fs.readFileSync(path.join(root,'TPlus_Dim/main.rb'),'utf8').replace(/^require[^\n]*\n/gm,'');
  vm.eval(main); vm.eval(main);
  vm.eval('raise "Toolbar moved/duplicated" unless UI.toolbars.length == 1 && UI.toolbars.first.events == [:add]; raise "Background profile service installed" if defined?(TPlus::Dim::ProfileService); puts "PASS: one toolbar, no startup layout changes or background profile service"; $stdout.flush');
})().catch(error => {console.error(error); process.exitCode = 1;});
