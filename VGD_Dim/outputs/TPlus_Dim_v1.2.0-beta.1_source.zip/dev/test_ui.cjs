const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const deps=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
if(!deps) throw Error('Set CODEX_PRIMARY_RUNTIME_NODE_MODULES to the bundled Node packages directory');
const {chromium}=require(path.join(deps,'playwright'));
const assert=(value,message)=>{if(!value)throw Error(message);};
(async()=>{
  const browser=await chromium.launch({headless:true,...(process.env.TPLUS_BROWSER_PATH ? {executablePath:process.env.TPLUS_BROWSER_PATH} : {channel:'msedge'})});
  try {
    const page=await browser.newPage({viewport:{width:470,height:720}});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript(()=>{window.calls=[];window.sketchup=new Proxy({},{get:(_,action)=>payload=>calls.push({action,payload})});});
    await page.goto(pathToFileURL(path.resolve(__dirname,'../runtime/TPlus_Dim/dialog.html')).href);
    const base={model_id:'a',dimensions:12,legacy:0,locked:0,blocked:null,can_apply:true,context_token:'a'};
    const receive=async(c={},s={})=>page.evaluate(([c,s])=>TPlusDim.receive(c,s),[{...base,...c},s]);
    const last=async()=>page.evaluate(()=>calls.at(-1));
    assert(await page.locator('#apply').isDisabled(),'Unsynced apply enabled');
    assert(await page.locator('#dim_info').isEnabled(),'Model Info requires a selection');
    await page.click('#dim_info');assert((await last()).action==='model_info' && (await last()).payload==='Dimensions','Dimensions page routing wrong');
    await page.click('#text_info');assert((await last()).payload==='Text','Text page routing wrong');
    await receive();await page.click('#apply');
    let call=await last(),data=JSON.parse(call.payload);
    assert(call.action==='apply' && data.alignment==='aligned' && data.position==='above' && !data.change_color && !('custom_dim' in data) && !('font' in data),'Native payload wrong');
    assert(await page.locator('#apply').isDisabled(),'Duplicate apply enabled');
    await receive();await page.selectOption('#alignment','screen');
    assert(await page.locator('#position').isDisabled(),'Screen alignment allowed Above position');
    await receive({}, {alignment:'aligned'});
    assert(await page.locator('#alignment').inputValue()==='screen','Selection event overwrote draft');
    await page.uncheck('#deep');assert(await page.locator('#apply').isDisabled(),'Scope change retained old token');
    assert((await last()).action==='refresh' && !JSON.parse((await last()).payload).deep,'Deep scope refresh missing');
    await receive({legacy:2,context_token:'restore-token'});await page.click('#restore');
    call=await last();assert(call.action==='restore' && JSON.parse(call.payload).context_token==='restore-token','Restore action/token missing');
    await receive({blocked:'Nhóm dùng chung',can_apply:false});assert(await page.locator('#apply').isDisabled(),'Blocked context mutable');
    await receive({model_id:'b',dimensions:0,legacy:0,can_apply:false},{alignment:'aligned',position:'above',deep:true});
    assert(await page.locator('#alignment').inputValue()==='aligned' && await page.locator('#restore').isDisabled(),'New model/legacy state wrong');
    assert(await page.locator('#dim_info').isEnabled(),'Empty model cannot edit Model Info');
    const output=path.resolve(__dirname,'../outputs');fs.mkdirSync(output,{recursive:true});
    await receive({model_id:'preview',legacy:3},{alignment:'aligned',position:'above',deep:true});
    for(const [width,height] of [[470,720],[380,500]]) {
      await page.setViewportSize({width,height});
      await page.evaluate(()=>document.querySelector('main').scrollTop=0);
      const layout=await page.evaluate(()=>({horizontal:document.documentElement.scrollWidth>innerWidth,footer:document.querySelector('footer').getBoundingClientRect().bottom<=innerHeight,pane:document.querySelector('main').scrollWidth<=document.querySelector('main').clientWidth}));
      assert(!layout.horizontal && layout.footer && layout.pane,'Clipped layout '+width);
      await page.screenshot({path:path.join(output,'native_'+width+'.png')});
    }
    await page.setViewportSize({width:470,height:720});await page.click('#theme');
    await page.screenshot({path:path.join(output,'native_dark.png')});
    assert(errors.length===0,errors.join(';'));
    console.log('PASS: native Model Info routing, apply/restore payload, stale scope, screen alignment, model switch, empty selection, light/dark responsive UI');
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
