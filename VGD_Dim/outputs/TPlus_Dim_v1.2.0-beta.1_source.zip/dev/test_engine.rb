def assert(value, message); raise message unless value; end
def rejects(message)
  begin; yield; rescue ArgumentError; return; end
  raise message
end
def add_dim(model)
  dim = Sketchup::DimensionLinear.new; model.entities << dim; dim
end
def apply_test(model, overrides = {}, restore_only = false)
  engine = TPlus::Dim::Engine
  config = engine.validate(overrides)
  engine.apply(model, config, engine.context(model, config)['context_token'], restore_only)
end
def legacy_pair(model, native, hidden = false)
  c = TPlus::Dim::CustomDim
  model.entities << native unless model.entities.include?(native)
  view = model.entities.add_group
  view.set_attribute(c::DICT, 'kind', native.is_a?(Sketchup::Text) ? 'text' : 'dimension')
  pair = native.persistent_id.to_s
  view.set_attribute(c::DICT, 'pair', pair)
  native.set_attribute(c::DICT, 'pair', pair)
  native.set_attribute(c::DICT, 'kind', 'source')
  native.set_attribute(c::DICT, 'original_hidden', hidden)
  native.hidden = true
  [native, view]
end
def run_engine_tests
  engine = TPlus::Dim::Engine; custom = TPlus::Dim::CustomDim
  config = TPlus::Dim::DEFAULTS
  model = Sketchup::FakeModel.new
  rejects('Empty selection accepted') { apply_test(model) }
  rejects('Invalid arrow accepted') { engine.validate('arrow'=>'invalid') }
  rejects('Non-boolean deep accepted') { engine.validate('deep'=>'true') }
  rejects('Invalid color accepted') { engine.validate('dim_color'=>'#BAD') }
  assert(!engine.validate('custom_dim'=>true).key?('custom_dim'), 'Old geometry option enabled')
  dim = add_dim(model); outside = add_dim(model); dim.text='OS'; dim.layer='keep-tag'; model.selection << dim
  result = apply_test(model)
  assert(result[:dimensions] == 1 && dim.has_aligned_text? && dim.aligned_text_position == 0, 'Native Above failed')
  assert(dim.valid? && !dim.hidden? && custom.partner(dim).nil? && model.entities.length == 2, 'Native dim replaced or geometry added')
  assert(dim.text == 'OS' && dim.layer == 'keep-tag' && dim.material.nil? && model.layers.empty?, 'Override/tag/material changed without request')
  assert(!outside.has_aligned_text? && model.get_attribute('TPlus_Dim','profile_json').nil?, 'Outside dim or profile changed')
  apply_test(model, 'alignment'=>'screen', 'position'=>'center', 'arrow'=>'dot', 'change_color'=>true)
  assert(!dim.has_aligned_text? && dim.aligned_text_position==0 && dim.arrow_type==2, 'Screen alignment/position conflict')
  original_material = dim.material
  apply_test(model, 'change_color'=>true, 'dim_color'=>'#CC3300')
  assert(original_material.color.blue == 255 && dim.material.color.red==204, 'Existing material recolored')
  token = engine.context(model, config)['context_token']
  model.selection << outside
  rejects('Stale selection accepted') { engine.apply(model, config, token) }
  model.selection.clear

  native, view = legacy_pair(model, Sketchup::DimensionLinear.new)
  model.set_attribute('TPlus_Dim', 'profile_json', '{"auto_new":true,"custom_dim":true}')
  model.set_attribute('TPlus_Dim', 'schema', 2)
  native.text='giữ chữ'; model.selection << view
  result = apply_test(model)
  assert(result[:restored]==1 && !view.valid? && !native.hidden? && native.text=='giữ chữ', 'Old dim restore failed')
  assert(model.selection.include?(native) && native.get_attribute(custom::DICT,'kind').nil?, 'Source not reselected/cleared')
  assert(model.get_attribute('TPlus_Dim','profile_json').nil? && model.get_attribute('TPlus_Dim','schema').nil?, 'Old auto-geometry profile retained in SKP')
  native, view = legacy_pair(model, Sketchup::Text.new, true)
  model.selection.clear; model.selection << view
  result = apply_test(model, {}, true)
  assert(result[:restored]==1 && !view.valid? && native.hidden?, 'Old text/original visibility lost')

  native, view = legacy_pair(model, Sketchup::DimensionLinear.new)
  model.selection.clear; model.selection << native; model.selection << view
  result = apply_test(model)
  assert(result[:restored]==1 && result[:dimensions]==1, 'Pair updated twice')

  native, view = legacy_pair(model, Sketchup::DimensionLinear.new)
  model.selection.clear; model.selection << native
  result = apply_test(model, {}, true)
  assert(result[:restored]==1 && !view.valid? && !native.hidden?, 'Selected native source cannot be restored')

  native, view = legacy_pair(model, Sketchup::DimensionLinear.new)
  copy = view.copy_to(model.entities); copy.definition.instances << copy; model.entities << copy
  model.selection.clear; model.selection << copy
  rejects('Display copy may restore original source') { apply_test(model) }
  assert(native.valid? && native.hidden? && view.valid? && copy.valid? && model.aborts>0, 'Missing source damaged original')
  native.erase!
  model.selection.clear; model.selection << view
  rejects('Orphan view silently erased') { apply_test(model) }
  assert(view.valid?, 'Orphan geometry erased')

  model = Sketchup::FakeModel.new
  original = Sketchup::DimensionLinear.new
  nested_def = Sketchup::Definition.new(model,[original]); model.definitions << nested_def
  nested = Sketchup::ComponentInstance.new(nested_def)
  parent_def = Sketchup::Definition.new(model,[nested]); model.definitions << parent_def
  selected = Sketchup::ComponentInstance.new(parent_def); unselected = Sketchup::ComponentInstance.new(parent_def)
  model.entities << selected; model.entities << unselected; model.selection << selected
  token = engine.context(model, config)['context_token']
  extra = Sketchup::DimensionLinear.new; nested_def.entities << extra
  rejects('Changed nested content reused token') { engine.apply(model, config, token) }
  result = apply_test(model)
  updated = selected.definition.entities.first.definition.entities.first
  assert(result[:unique]==2 && updated.has_aligned_text? && !original.has_aligned_text? && unselected.definition==parent_def, 'Nested shared isolation failed')
  selected.locked=true
  rejects('Locked-only selection accepted') { apply_test(model) }
  selected.locked=false
  model.active_path=[unselected]; another=Sketchup::ComponentInstance.new(parent_def)
  rejects('Shared active edit path accepted') { apply_test(model) }
  model.active_path=nil
  model.selection.clear; model.selection << selected
  rejects('Deep scope off still changed nested dim') { apply_test(model,'deep'=>false) }
  assert(!custom.respond_to?(:convert) && !custom.respond_to?(:updates), 'Geometry renderer/background scan still exposed')
  puts 'PASS: native Above/screen/arrows/color, unchanged content/tags, stale scope, nested shared isolation, locked contexts, legacy dim/text restoration, copy/orphan protection, no geometry creation'
end
