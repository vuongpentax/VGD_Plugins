# T+ Dim · 1.2.0-beta.1

Bản gọn dùng **dim native** của SketchUp. Không tạo chữ bằng edge/face, không đóng gói bộ font mesh, không quét và dựng lại dim sau mỗi transaction. Không đổi T+ Cabinet, đơn vị model, tag, nội dung ghi đè hoặc hình học đo.

## Font và cỡ chữ: dùng đúng Model Info

1. Mở Extensions → T+ Dim → **Font & cỡ chữ — Model Info**.
2. Trong Dimensions, chọn Font và cỡ chữ theo **Points (pt)** hoặc **Height**. Points giữ cỡ chữ theo màn hình khi zoom; Height giữ chiều cao trong model. Để xuất ảnh đồng bộ, dùng cùng chế độ/cỡ chữ và cùng thiết lập kích thước xuất ảnh.
3. Bấm **Update selected dimensions** cho dim đã chọn. Muốn đồng bộ tất cả, bấm **Select all dimensions** trước.
4. Hướng chữ, vị trí Above và đầu dim mặc định cho dim mới cũng đặt trong Model Info.
5. Ctrl+S để lưu thiết lập và dim đã cập nhật vào SKP. Máy nhận không cần plugin để xem dim native; font được chọn cần có trên máy nhận.

Ruby API của SketchUp 2022 không cung cấp setter font/cỡ chữ của Dimension hoặc các mặc định Dimensions trong Model Info. Bản này mở bảng native để người dùng đặt các thông số đó; **không tự ghi font/size vào Model Info từ form plugin**. Các mục áp dụng vùng chọn bên dưới là tùy chỉnh trực tiếp từng dim, không được quảng cáo là mặc định của Model Info.

Tài liệu: [Dimension Ruby API](https://ruby.sketchup.com/Sketchup/Dimension.html), [UI.show_model_info](https://ruby.sketchup.com/UI.html#show_model_info-class_method), [Dimensions của SketchUp](https://help.sketchup.com/en/sketchup/adding-text-labels-and-dimensions-model).

## Chỉnh dim native trong vùng chọn

Chọn dim hoặc nhóm chứa dim, đặt hướng chữ Theo đường dim / Theo màn hình, vị trí Above / Giữa / Bên ngoài, đầu dim và màu nếu cần; bấm **ÁP DỤNG VÙNG CHỌN**. Above áp dụng khi chữ theo đường dim; hướng Theo màn hình giữ chữ theo camera. Có thể Undo.

Mặc định giữ màu và đầu dim hiện có, dùng chữ theo đường dim và Above. Không đổi font/cỡ chữ từ nút này. Component dùng chung được tách riêng cho vùng chọn; nhóm khóa được bỏ qua. Đóng edit context thuộc definition dùng chung rồi chọn nhóm cha.

## Trả dim T+ cũ về native

Chọn nhóm chứa cả nguồn đo ẩn và chữ T+ cũ; bấm **Trả dim T+ cũ về dim native**. Nút Áp dụng cũng khôi phục nguồn trước khi chỉnh diện mạo. Giữ nguồn đo, nội dung nhập đè và trạng thái ẩn trước chuyển đổi; bỏ phần hiển thị hình học T+. Text T+ cũ cũng được trả về nguồn Text native.

Nếu đã xóa nguồn hoặc chỉ copy riêng chữ T+, plugin báo lỗi và Undo operation; không tự suy đoán điểm đo. Bản sao chung được tách riêng trước khi khôi phục. Lệnh bỏ cấu hình tự dựng chữ beta 2 trong model hiện tại, trong cùng một Undo; Ctrl+S lưu thay đổi. Không tự chuyển đổi toàn model khi khởi động.

## Cài và nạp lại

RBZ: outputs/TPlus_Dim_v1.2.0-beta.1.rbz. Với phiên SketchUp đang mở, chạy một lần trong Window → Ruby Console:

~~~ruby
load File.join(Sketchup.find_support_file('Plugins'), 'TPlus_Dim', 'reload.rb')
~~~

Các lần sau dùng Extensions → Nạp lại T+ Dim. Reload dừng observer T+ Dim cũ, giữ toolbar hiện có và chỉ nạp file T+ Dim. Script dev/deploy.ps1 lấy APPDATA theo tài khoản Windows, sao lưu và đối chiếu SHA256 10 file trong SU2022. Các tài nguyên beta 2 cũ trên ổ đĩa không còn được nạp; không xóa hoặc sửa plugin khác.

## Kiểm tra

- node dev/check_ruby.cjs: Ruby WASM 3.2, native Above/screen/color/arrow, phạm vi vùng chọn, nhóm dùng chung, dim/text legacy, nguồn mất/copy và toolbar.
- node dev/test_ui.cjs: Chromium/Edge headless, callback Model Info, apply/restore, token vùng chọn, sáng/tối và 470×720 / 380×500.
- python dev/package.py: RBZ và source ZIP nhẹ, danh sách runtime cố định, CRC và SHA256.
- Dependency Ruby ở ../TPlus_Cabinet_Codex_Handoff_2026-10-01/cabinet_dev/node_modules, cài theo lockfile. UI test lấy Playwright từ CODEX_PRIMARY_RUNTIME_NODE_MODULES; TPLUS_BROWSER_PATH có thể chỉ định trình duyệt.

Các kiểm tra tự động dùng stub và browser. Chưa kiểm chứng native: font/cỡ chữ Model Info, Orbit, Undo/Redo, Save/Open, liên kết số đo sau Stretch và hồi phục dữ liệu beta 2 trong SketchUp. dev/native_smoke.rb là bài thử chủ động, chỉ cho model trống.
