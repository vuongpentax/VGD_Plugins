const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const deps=process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES;
if(!deps)throw Error('Set CODEX_PRIMARY_RUNTIME_NODE_MODULES');
const {chromium}=require(path.join(deps,'playwright'));
const assert=(v,m)=>{if(!v)throw Error(m);};
(async()=>{
  const browser=await chromium.launch({headless:true,...(process.env.TPLUS_BROWSER_PATH?{executablePath:process.env.TPLUS_BROWSER_PATH}:{channel:'msedge'})});
  try{
    const page=await browser.newPage({viewport:{width:550,height:740}});
    const errors=[];page.on('pageerror',e=>errors.push(e.message));
    await page.addInitScript(()=>{window.calls=[];window.sketchup=new Proxy({},{get:(_,action)=>payload=>calls.push({action,payload})});});
    await page.goto(pathToFileURL(path.resolve(__dirname,'../runtime/TPlus_Dim/dialog.html')).href);
    const style={font:'Arial',size:2.5,size_unit:'mm',bold:false,italic:false,apply_font:true,color:'#000000'};
    const settings={scope:'entire',include_nested:true,include_components:true,include_hidden:false,include_locked:false,apply_model_units:false,
      dimension:{...style,arrow:'closed',alignment:'aligned',position:'above',unit:'mm',precision:0,show_unit:false},
      text:{...style},label:{...style,arrow:'closed',leader:'view',display:'keep'}};
    let presets={'T+ STANDARD':settings,'T+ Working':{...settings,text:{...style,size:10,size_unit:'pt'}}};
    const caps={dimension_font:false,text_font_pt:false,label_font_pt:false,font_mm:false};
    const base={dimension:326,text:147,label:82,nested:194,unique:440,legacy:2,hidden_skipped:4,locked_skipped:1,can_apply:true,blocked:null,scan_token:'scan-a'};
    const receive=async(c=base,s=settings,id='model-a',p=presets,cap=caps)=>page.evaluate(([c,s,p,cap,id])=>TPlusAnnotation.receive(c,s,p,cap,id),[c,s,p,cap,id]);
    const last=async()=>page.evaluate(()=>calls.at(-1));
    await receive(null);
    assert(await page.locator('#normalize').isDisabled(),'Normalize enabled before Scan');
    assert(await page.locator('#scope').inputValue()==='entire','Entire Model not default');
    assert(await page.locator('#dimension_font_note').innerText().then(t=>t.includes('chưa đổi')),'Font limitation hidden');
    await page.click('#scan');
    let call=await last(),data=JSON.parse(call.payload);
    assert(call.action==='scan' && data.include_nested && data.include_components && !data.include_hidden && !data.include_locked,'Scan scope/options wrong');
    assert(!data.apply_model_units && data.dimension.font==='Arial' && data.dimension.size===2.5 && data.dimension.size_unit==='mm','Native target/defaults wrong');
    await receive();
    assert(await page.locator('#count_dimension').innerText()==='326' && await page.locator('#count_label').innerText()==='82','Scan counts absent');
    await page.click('#normalize');
    data=JSON.parse((await last()).payload);
    assert(data.scan_token==='scan-a' && data.types.join(',')==='dimension,text,label','Normalize all omitted type/token');
    assert(await page.locator('#normalize').isDisabled(),'Repeated Normalize enabled');
    await receive();await page.selectOption('#dimension_alignment','screen');
    assert(await page.locator('#dimension_position').isDisabled(),'Screen/Above conflict');
    await page.click('[data-apply="dimension"]');
    assert(JSON.parse((await last()).payload).types.join(',')==='dimension','Dimension apply wrong types');
    await receive();await page.click('[data-page="text"]');
    await page.click('[data-apply="text"]');assert(JSON.parse((await last()).payload).types.join(',')==='text','Text apply included Label');
    await receive();await page.click('[data-page="label"]');
    await page.selectOption('#label_leader','model');await page.selectOption('#label_display','hide');await page.click('[data-apply="label"]');
    data=JSON.parse((await last()).payload);assert(data.types.join(',')==='label'&&data.label.leader==='model'&&data.label.display==='hide','Label style payload wrong');
    await receive();await page.selectOption('#scope','selected');
    assert(await page.locator('#normalize').isDisabled() && await page.locator('#count_text').innerText()==='—','Scope change kept old scan');
    await page.click('#scan');assert(JSON.parse((await last()).payload).scope==='selected','Selected scope omitted');
    await receive();await page.check('#include_locked');assert(await page.locator('#normalize').isDisabled(),'Locked filter retained stale scan');
    await receive();await page.evaluate(()=>TPlusAnnotation.invalidate('model-a'));assert(await page.locator('#apply').isDisabled(),'Transaction did not invalidate scan');
    await receive({...base,label:0});assert(await page.locator('#apply').isDisabled(),'Apply active empty type enabled');
    await receive({...base,blocked:'Edit context dùng chung',can_apply:false});assert(await page.locator('#normalize').isDisabled(),'Blocked context writable');
    await receive();await page.click('[data-page="quick"]');await page.click('[data-quick="text"]');
    call=await last();data=JSON.parse(call.payload);assert(call.action==='quick_fix'&&data.scope==='entire'&&data.types.join(',')==='text','Quick Fix scope/kind wrong');
    assert(await page.locator('#scope').inputValue()==='entire','Quick Fix scope not visible');
    await receive();await page.click('[data-info="Dimensions"]');assert((await last()).action==='model_info'&&(await last()).payload==='Dimensions','Model Info routing wrong');
    await page.click('[data-page="dimension"]');await page.locator('details').evaluate(e=>e.open=true);
    await page.check('#apply_model_units');await page.click('#normalize');data=JSON.parse((await last()).payload);assert(data.apply_model_units,'Units opt-in missing');
    await receive();await page.fill('#preset_name','My Style');await page.click('#save_preset');
    call=await last();data=JSON.parse(call.payload);assert(call.action==='preset'&&data.action==='save'&&data.name==='My Style','Save preset wrong');
    presets={...presets,'My Style':settings};await receive(base,settings,'model-a',presets);
    await page.selectOption('#preset','T+ Working');await page.click('#load_preset');
    const loaded={...settings,text:{...style,size:10,size_unit:'pt'}};
    await receive(base,loaded,'model-a',presets);
    assert(await page.locator('#text_size').inputValue()==='10' && !await page.locator('#apply_model_units').isChecked(),'Preset style not loaded/permission persisted');
    await page.click('#update_preset');data=JSON.parse((await last()).payload);assert(data.action==='update'&&data.name==='T+ Working','Update preset wrong');
    await receive(base,loaded,'model-a',presets);
    await page.click('#delete_preset');assert(await page.locator('#delete_confirm').isVisible(),'Delete confirmation missing');
    assert(JSON.parse((await last()).payload).action==='update','Delete sent before confirmation');
    await page.click('#confirm_delete');data=JSON.parse((await last()).payload);assert(data.action==='delete'&&data.name==='T+ Working','Preset deletion wrong');
    await receive(null,settings,'model-b',presets);
    assert(await page.locator('#text_size').inputValue()==='2.5' && await page.locator('#normalize').isDisabled(),'Model switch kept draft/scan');
    await page.fill('#dimension_size','0');await page.click('#scan');assert((await page.locator('#status').innerText()).includes('giới hạn'),'Bad size accepted');
    await page.fill('#dimension_size','2.5');
    await receive(base,settings,'preview',presets);await page.selectOption('#preset','T+ STANDARD');await page.fill('#preset_name','');
    await page.evaluate(()=>TPlusAnnotation.status('SCAN: 326 Dim · 147 Text · 82 Label. Sẵn sàng áp định dạng; font/cỡ chữ cần Model Info.',false));
    await page.locator('details').evaluate(e=>e.open=false);
    const output=path.resolve(__dirname,'../outputs');fs.mkdirSync(output,{recursive:true});
    for(const [width,height]of[[550,740],[440,540]]){
      await page.setViewportSize({width,height});
      for(const kind of['dimension','text','label','quick']){
        await page.click('[data-page="'+kind+'"]');
        const layout=await page.evaluate(()=>({wide:document.documentElement.scrollWidth>innerWidth,footer:document.querySelector('footer').getBoundingClientRect().bottom<=innerHeight,pane:document.querySelector('main').scrollWidth<=document.querySelector('main').clientWidth,positive:document.querySelector('main').clientHeight>80}));
        assert(!layout.wide && layout.footer && layout.pane && layout.positive,'Clipped layout '+width+'/'+kind);
        await page.screenshot({path:path.join(output,'annotation_'+kind+'_'+width+'.png')});
      }
    }
    await page.setViewportSize({width:550,height:740});await page.click('[data-page="dimension"]');await page.click('#theme');await page.screenshot({path:path.join(output,'annotation_dark.png')});
    assert(errors.length===0,errors.join(';'));
    console.log('PASS: Annotation Manager defaults, Scan/apply types, stale scope/model events, Quick Fix, unsupported-font notice, Units opt-in, preset CRUD/delete confirmation, tabs/light/dark/responsive UI');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
