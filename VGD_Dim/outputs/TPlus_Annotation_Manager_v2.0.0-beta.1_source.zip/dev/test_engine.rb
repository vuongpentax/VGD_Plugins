def assert(value, message); raise message unless value; end
def rejects(message)
  begin; yield; rescue ArgumentError; return; end
  raise message
end
def native_dim(model, collection = model.entities)
  e=Sketchup::DimensionLinear.new; collection << e; e
end
def native_text(model, label=false, collection=model.entities)
  e=Sketchup::Text.new; e.leader=label; collection << e; e
end
def apply_test(model, overrides={}, types=TPlus::Dim::Engine::TYPES)
  engine=TPlus::Dim::Engine; config=engine.validate(overrides); scan=engine.scan(model,config)
  engine.apply(model,config,scan[:scan_token],types)
end
def run_engine_tests
  engine=TPlus::Dim::Engine; presets=TPlus::Dim::Presets
  model=Sketchup::FakeModel.new
  dim=native_dim(model); dim.text='OS'; dim.layer='keep-tag'
  text=native_text(model); label=native_text(model,true)
  edge=Sketchup::Edge.new([Geom::Point3d.new(0,0,0),Geom::Point3d.new(1,0,0)]);model.entities << edge
  before=[dim.start_point.to_a,dim.end_point.to_a,dim.offset_vector.to_a,text.point.to_a,label.point.to_a,label.vector.to_a,edge.points.map(&:to_a)]
  config=engine.validate({});scan=engine.scan(model,config)
  assert(scan.values_at(:dimension,:text,:label,:nested,:unique)==[1,1,1,0,3],'Text/Label classification or scan counts wrong')
  assert(model.operations==0 && dim.material.nil?,'Scan changed model')
  result=apply_test(model)
  assert(result.values_at(:dimension,:text,:label)==[1,1,1] && model.operations==1 && model.commits==1,'Not one operation/all types')
  assert(result[:font_pending].values==[1,1,1] && result[:font_applied]==0,'SU2022 unsupported font falsely reported applied')
  assert(dim.arrow_type==3 && dim.has_aligned_text? && dim.aligned_text_position==0 && label.arrow_type==3 && label.leader_type==1,'Dimension/Label native setters wrong')
  assert(dim.text=='OS' && text.text=='Kích thước tủ' && label.text=='Kích thước tủ' && dim.layer=='keep-tag' && model.layers.empty?,'Content or tags changed')
  after=[dim.start_point.to_a,dim.end_point.to_a,dim.offset_vector.to_a,text.point.to_a,label.point.to_a,label.vector.to_a,edge.points.map(&:to_a)]
  assert(before==after && model.entities.size==4,'Annotation moved/deleted or geometry changed')
  assert(model.options['UnitsOptions']['LengthUnit']==0,'Units changed without opt-in')
  apply_test(model,{'apply_model_units'=>true,'dimension'=>{'unit'=>'mm','precision'=>2,'show_unit'=>true}})
  assert(model.options['UnitsOptions'].values_at('LengthUnit','LengthPrecision','SuppressUnitsDisplay')==[2,2,false],'Global units opt-in failed')
  model.options['UnitsOptions']['LengthUnit']=4
  apply_test(model,{'apply_model_units'=>true,'dimension'=>{'unit'=>'model','precision'=>0}})
  assert(model.options['UnitsOptions']['LengthUnit']==4,'Model unit selection changed length unit')
  unit_snapshot=model.options['UnitsOptions'].dup
  apply_test(model,{'apply_model_units'=>true},['text'])
  assert(model.options['UnitsOptions']==unit_snapshot,'Text-only action changed model units')
  applies_before=model.operations
  stale=engine.scan(model,config)[:scan_token];native_dim(model)
  rejects('Stale nested content scan accepted'){engine.apply(model,config,stale)}
  assert(model.operations==applies_before,'Stale scan started an operation')
  rejects('Invalid color accepted'){engine.validate('text'=>{'color'=>'BAD'})}
  rejects('NaN size accepted'){engine.validate('dimension'=>{'size'=>Float::NAN})}
  rejects('Empty font accepted'){engine.validate('label'=>{'font'=>' '})}
  rejects('Invalid scope accepted'){engine.validate('scope'=>'elsewhere')}
  rejects('Invalid type accepted'){engine.apply(model,config,engine.scan(model,config)[:scan_token],['geometry'])}
  assert(!engine.validate('dimension'=>{'arrow_size'=>99})['dimension'].key?('arrow_size'),'Unsupported arrow size carried into mutation')

  model=Sketchup::FakeModel.new
  inside=Sketchup::DimensionLinear.new
  inner_def=Sketchup::Definition.new(model,[inside]);model.definitions << inner_def
  inner=Sketchup::ComponentInstance.new(inner_def)
  outer_def=Sketchup::Definition.new(model,[inner]);model.definitions << outer_def
  chosen=Sketchup::Group.new(outer_def);outside=Sketchup::Group.new(outer_def)
  model.entities << chosen;model.entities << outside;model.selection << chosen
  result=apply_test(model,{'scope'=>'selected'})
  updated=chosen.entities.first.definition.entities.first
  assert(result[:unique]==2 && updated.material && inside.material.nil? && outside.definition==outer_def,'Selected shared/nested isolation leaked')
  assert(engine.scan(model,engine.validate('scope'=>'selected','include_components'=>false))[:dimension]==0,'Components off ignored')
  assert(engine.scan(model,engine.validate('scope'=>'selected','include_nested'=>false))[:dimension]==0,'Nested off ignored')
  direct=Sketchup::DimensionLinear.new;chosen.entities << direct
  assert(engine.scan(model,engine.validate('scope'=>'selected','include_nested'=>false))[:dimension]==1,'Selected root group not inspected')
  cfg=engine.validate('scope'=>'selected');old_token=engine.scan(model,cfg)[:scan_token]
  model.selection.clear;model.selection << outside
  rejects('Changed selection reused scan'){engine.apply(model,cfg,old_token)}
  chosen.locked=true;model.selection.clear;model.selection << chosen
  assert(engine.scan(model,cfg)[:dimension]==0,'Locked branch included by default')
  result=apply_test(model,{'scope'=>'selected','include_locked'=>true})
  assert(chosen.locked? && result[:dimension]==2,'Locked branch not restored')
  chosen.locked=false;chosen.hidden=true
  assert(engine.scan(model,cfg)[:dimension]==0,'Hidden ancestor included by default')
  apply_test(model,{'scope'=>'selected','include_hidden'=>true})
  assert(chosen.hidden?,'Hidden object unhidden')
  chosen.hidden=false
  model.active_path=[chosen]
  assert(engine.scan(model,engine.validate('scope'=>'context'))[:dimension]==2,'Current Context roots wrong')
  assert(engine.scan(model,engine.validate('scope'=>'entire'))[:blocked],'Entire Model allowed while editing')
  model.active_path=[outside];duplicate=Sketchup::Group.new(outer_def)
  rejects('Shared edit context accepted'){apply_test(model,{'scope'=>'context'})}
  model.active_path=nil

  model=Sketchup::FakeModel.new
  d=Sketchup::Definition.new(model,[Sketchup::DimensionLinear.new]);model.definitions << d
  visible=Sketchup::ComponentInstance.new(d);hidden=Sketchup::ComponentInstance.new(d);hidden.hidden=true
  model.entities << visible;model.entities << hidden
  result=apply_test(model)
  assert(result[:dimension]==1 && result[:unique]==1 && hidden.definition==d && d.entities.first.material.nil?,'Entire Model filter leaked into hidden shared copy')
  model=Sketchup::FakeModel.new;dim=Sketchup::DimensionLinear.new
  d=Sketchup::Definition.new(model,[dim]);model.definitions << d
  2.times{model.entities << Sketchup::ComponentInstance.new(d)}
  all=engine.validate('include_hidden'=>true,'include_locked'=>true)
  assert(engine.scan(model,all).values_at(:dimension,:nested,:unique)==[2,2,1],'Placed vs unique counts wrong')
  result=apply_test(model,all)
  assert(result[:dimension]==1 && result[:unique]==0 && dim.material,'Unfiltered shared definitions not processed once')
  cycle=Sketchup::ComponentInstance.new(d);d.entities << cycle
  assert(engine.scan(model,all)[:dimension]==2,'Cycle protection failed')
  model.selection << model.entities.first
  result=apply_test(model,{'scope'=>'selected'})
  assert(result[:dimension]==1 && result[:unique]==1,'Scoped cyclic graph expanded after make_unique')

  model=Sketchup::FakeModel.new
  view=model.entities.add_group;view.set_attribute(TPlus::Dim::CustomDim::DICT,'kind','dimension')
  native=native_dim(model);native.set_attribute(TPlus::Dim::CustomDim::DICT,'kind','source')
  native.set_attribute(TPlus::Dim::CustomDim::DICT,'pair','pair')
  view.set_attribute(TPlus::Dim::CustomDim::DICT,'pair','pair')
  native.hidden=true
  text=native_text(model)
  assert(engine.scan(model,config).values_at(:dimension,:legacy,:text)==[0,1,1],'Legacy geometry mixed with native count')
  apply_test(model)
  assert(view.valid? && native.valid? && native.hidden? && native.material.nil?,'Normalize converted/deleted old geometry')
  text.define_singleton_method(:font=){|value|@font=value}
  text.define_singleton_method(:font){@font}
  result=apply_test(model,{'text'=>{'size'=>10,'size_unit'=>'pt','bold'=>true}},['text'])
  assert(result[:font_applied]==1 && text.font=={name:'Arial',size:10,bold:true,italic:false},'Public Text font setter not used')
  result=apply_test(model,{'text'=>{'size'=>2.5,'size_unit'=>'mm'}},['text'])
  assert(result[:font_applied]==0 && result[:font_pending]['text']==1 && text.font[:size]==10,'mm wrongly converted to point size')
  text.define_singleton_method(:material=){|_|raise 'setter failed'}
  group=model.entities.add_group;group.locked=true
  model.entities.delete(text);group.entities << text
  config_locked=engine.validate('include_locked'=>true)
  token=engine.scan(model,config_locked)[:scan_token]
  begin;engine.apply(model,config_locked,token,['text']);rescue RuntimeError;end
  assert(group.locked? && model.aborts==1,'Failure did not re-lock and abort operation')

  names=presets.all.keys
  assert(names==['T+ STANDARD','T+ Working','T+ Layout'],'Builtin presets unavailable')
  presets.mutate('save','My Style',{'text'=>{'font'=>'Tahoma','size'=>12,'size_unit'=>'pt'},'scope'=>'selected','include_locked'=>true,'apply_model_units'=>true})
  stored=presets.all['My Style']
  assert(stored['text']['font']=='Tahoma' && !stored.key?('scope') && !stored.key?('apply_model_units'),'Preset stored scope/global permission')
  rejects('Duplicate save accepted'){presets.mutate('save','My Style',{})}
  presets.mutate('update','My Style',{'text'=>{'font'=>'Arial'}})
  assert(presets.all['My Style']['text']['font']=='Arial','Preset update failed')
  presets.mutate('delete','My Style')
  assert(!presets.all.key?('My Style'),'Preset delete failed')
  presets.mutate('update','T+ STANDARD',{'text'=>{'color'=>'#123456'}})
  assert(presets.all['T+ STANDARD']['text']['color']=='#123456','Default preset update prohibited')
  assert(!engine.capabilities['dimension_font'] && !engine.capabilities['font_mm'],'Unsupported capability advertised')
  puts 'PASS: native Dim/Text/Label scan, all scopes/filters, hidden/shared isolation, temporary unlock/relock, cycle guard, content/position/tag preservation, one operation/abort, legacy untouched, font capability boundaries, global Units opt-in, preset CRUD'
end
