# encoding: UTF-8
# Explicit opt-in, only a new empty model; never run on user's working SKP.
model = Sketchup.active_model
raise 'Chỉ chạy trên model mới, trống và chưa lưu.' unless model.path.empty? && model.entities.empty? && !model.modified?
raise 'Cài và nạp lại Annotation Manager 2.0 trước.' unless defined?(TPlus::Dim::Engine) && TPlus::Dim::Engine.respond_to?(:scan)
engine = TPlus::Dim::Engine
model.start_operation('T+ Annotation · Fixture native', true)
dim = model.entities.add_dimension_linear([0,0,0],[800.mm,0,0],[0,80.mm,0])
text = model.entities.add_text('Text giữ nguyên',[0,200.mm,0])
label = model.entities.add_text('Label giữ nguyên',[200.mm,200.mm,0],[0,100.mm,0])
model.commit_operation
config = engine.validate({})
scan = engine.scan(model,config)
raise 'Scan phân loại sai.' unless scan.values_at(:dimension,:text,:label) == [1,1,1]
points = [dim.start[1].to_a,dim.end[1].to_a,dim.offset_vector.to_a,text.point.to_a,label.point.to_a]
result = engine.apply(model,config,scan[:scan_token])
raise 'Native format thất bại.' unless result.values_at(:dimension,:text,:label) == [1,1,1] && dim.has_aligned_text? && dim.aligned_text_position == Sketchup::DimensionLinear::ALIGNED_TEXT_ABOVE
raise 'Nội dung thay đổi.' unless text.text=='Text giữ nguyên' && label.text=='Label giữ nguyên'
raise 'Annotation bị move.' unless points == [dim.start[1].to_a,dim.end[1].to_a,dim.offset_vector.to_a,text.point.to_a,label.point.to_a]
raise 'Geometry sinh thêm.' unless model.entities.to_a.sort_by(&:persistent_id)==[dim,text,label].sort_by(&:persistent_id)
puts '[T+ Annotation] PASS native format, giữ nội dung/vị trí; chưa kiểm chứng font.'
puts '[T+ Annotation] Thử tiếp trên fixture: Ctrl+Z/Redo, Save/Open, nhóm chia sẻ/hidden/locked và Model Info. Không coi các bước đó đã đạt.'
