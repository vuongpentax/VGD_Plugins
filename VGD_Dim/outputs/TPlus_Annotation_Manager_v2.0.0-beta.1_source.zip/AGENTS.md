# T+ Dim

Tên hiển thị từ 2.0 là T+ Annotation Manager. Giữ loader `tplus_dim.rb`, namespace `TPlus::Dim` và thư mục `TPlus_Dim` để nâng cấp cùng extension, không tạo bản cài trùng.

- Giao diện và tài liệu bằng tiếng Việt, theo font/màu của T+ Cabinet.
- Chỉ triển khai `tplus_dim.rb` và các file liệt kê trong `dev/deploy.ps1` vào SketchUp 2022.
- Không thay đổi T+ Cabinet hoặc các plugin khác.
- Kiểm tra Ruby, luồng vùng chọn và UI trước khi đóng gói.
- Phân biệt kiểm thử mô phỏng với kiểm thử thực tế trong SketchUp.
- Đọc `ANNOTATION_REQUIREMENTS.md` và `FEATURE_STATUS.md` trước khi thay đổi logic.
- Scan không ghi model; chỉ chạy khi người dùng yêu cầu. Apply/Normalize có một operation, giữ nội dung, vị trí, điểm đo, tag và hình học. Không tự khôi phục/xóa chữ hình học beta 2 trong Normalize.
- Không giả lập font native bằng edge/face, không đổi mm sang pt rồi báo đã đạt chiều cao native. Báo rõ các trường chưa áp dụng vì API.
- Units/precision là toàn model: chỉ đổi khi checkbox `apply_model_units` được bật, trong cùng operation. Preset không lưu scope hoặc quyền đổi Units.
- Include Locked chỉ mở khóa tạm trong operation và phải khóa lại cả khi gặp lỗi. Giữ phạm vi khi xử lý definition chia sẻ.
