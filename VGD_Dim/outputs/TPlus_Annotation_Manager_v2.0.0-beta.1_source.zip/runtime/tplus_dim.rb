# encoding: UTF-8
require 'sketchup.rb'
require 'extensions.rb'

module TPlus
  module Dim
    VERSION = '2.0.0-beta.1'.freeze unless const_defined?(:VERSION)
    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new('T+ Annotation Manager', 'TPlus_Dim/main')
      extension.description = 'Scan và chuẩn định dạng Dimension, Text, Label native theo phạm vi/preset. Font/size SU2022 cần Model Info.'
      extension.version = VERSION
      extension.creator = 'T+'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
