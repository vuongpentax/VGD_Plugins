(function () {
  'use strict';
  var types = ['dimension','text','label'], scan = null, modelId = null, initialized = false, busy = false, presetPending = null, deleting = null;
  var capabilities = {dimension_font:false,text_font_pt:false,label_font_pt:false,font_mm:false};
  var el = function (id) { return document.getElementById(id); };
  var scopeKeys = ['include_nested','include_components','include_hidden','include_locked'];
  var styleKeys = ['font','size','size_unit','bold','italic','apply_font','color'];
  var extra = {dimension:['arrow','alignment','position','unit','precision','show_unit'],text:[],label:['arrow','leader','display']};
  types.forEach(function(kind) {
    document.querySelector('.font-style[data-kind="'+kind+'"]').innerHTML =
      '<div class="row font-row"><label for="'+kind+'_font">Font mục tiêu</label><input id="'+kind+'_font" type="text" value="Arial" maxlength="256"></div>'+
      '<div class="row"><label for="'+kind+'_size">Cỡ chữ mục tiêu</label><div class="size-pair"><input id="'+kind+'_size" type="number" value="2.5" step="0.1" min="0.01" max="100000"><select id="'+kind+'_size_unit"><option value="mm">mm</option><option value="pt">pt</option></select></div></div>'+
      '<div class="font-weight"><label class="check"><input id="'+kind+'_bold" type="checkbox">Đậm</label><label class="check"><input id="'+kind+'_italic" type="checkbox">Nghiêng</label><label class="check"><input id="'+kind+'_apply_font" type="checkbox" checked>Áp font / size</label></div>'+
      '<div id="'+kind+'_font_note" class="font-note"></div>'+
      '<div class="row"><label for="'+kind+'_color">Màu</label><input id="'+kind+'_color" type="color" value="#000000"></div>';
  });
  ['dimension_arrow','label_arrow'].forEach(function(id) {
    el(id).innerHTML='<option value="closed">Mũi tên kín</option><option value="open">Mũi tên mở</option><option value="dot">Chấm tròn</option><option value="slash">Gạch chéo /</option><option value="none">Không có</option><option value="keep">Giữ nguyên</option>';
  });
  function call(action, payload) {
    if (window.sketchup && typeof window.sketchup[action] === 'function') { window.sketchup[action](payload); return true; }
    return false;
  }
  function status(message, error) { el('status').textContent=message; el('status').classList.toggle('error', !!error); }
  function controls() {
    var usable = scan && scan.can_apply && !scan.blocked && !busy;
    var page=document.querySelector('[data-page][aria-current]').dataset.page;
    el('apply').disabled = !usable || (types.includes(page) && !scan[page]); el('normalize').disabled = !usable;
    document.querySelectorAll('[data-apply]').forEach(function(button) { button.disabled=!usable || !scan[button.dataset.apply]; });
    document.querySelectorAll('[data-quick]').forEach(function(button) {button.disabled=busy;});
    el('scan').disabled=busy;
    ['load_preset','update_preset','delete_preset'].forEach(function(id) {el(id).disabled=busy || !el('preset').value;});
    el('save_preset').disabled=busy;
    el('dimension_position').disabled=el('dimension_alignment').value==='screen';
    types.forEach(function(kind) {
      var unit=el(kind+'_size_unit').value, supported=kind!=='dimension' && capabilities[kind+'_font_pt'] && unit==='pt';
      var note=el(kind+'_font_note');
      note.replaceChildren();
      var text=document.createElement('div');
      text.textContent=supported ? 'Font native hỗ trợ cỡ pt nguyên. Size mm vẫn cần Model Info.' : 'Font / size này lưu trong preset; trên bản SketchUp này cần đặt bằng Model Info. Apply chưa đổi được mục này.';
      note.appendChild(text);
      var button=document.createElement('button');
      button.type='button';button.textContent='Model Info · '+(kind==='dimension'?'Dimensions':'Text / Label')+' ↗';
      button.addEventListener('click',function(){call('model_info',kind==='dimension'?'Dimensions':'Text');});
      note.appendChild(button);
    });
  }
  function clearScan(message) {
    scan=null;
    ['dimension','text','label','nested'].forEach(function(kind){el('count_'+kind).textContent='—';});
    controls();
    if(message) status(message);
  }
  function config() {
    var data={scope:el('scope').value,apply_model_units:el('apply_model_units').checked};
    scopeKeys.forEach(function(key){data[key]=el(key).checked;});
    types.forEach(function(kind) {
      var s={};
      styleKeys.concat(extra[kind]).forEach(function(key) {
        var input=el(kind+'_'+key);
        s[key]=input.type==='checkbox' ? input.checked : input.type==='number' ? Number(input.value) : input.value;
        if(input.type==='number' && (!input.value.trim() || !Number.isFinite(s[key]))) throw Error('Nhập số hợp lệ cho '+kind+' '+key+'.');
      });
      var min=s.size_unit==='pt'?1:0.01, max=s.size_unit==='pt'?1000:100000;
      if(s.size<min||s.size>max) throw Error('Cỡ chữ '+kind+' ngoài giới hạn '+min+'–'+max+' '+s.size_unit+'.');
      if(!s.font.trim()) throw Error('Nhập font mục tiêu cho '+kind+'.');
      data[kind]=s;
    });
    return data;
  }
  function setConfig(settings, stylesOnly) {
    if(!stylesOnly) {
      el('scope').value=settings.scope || 'entire';
      scopeKeys.forEach(function(key){if(settings[key]!==undefined)el(key).checked=settings[key];});
      el('apply_model_units').checked=!!settings.apply_model_units;
    }
    types.forEach(function(kind) {
      var s=settings[kind]||{};
      styleKeys.concat(extra[kind]).forEach(function(key) {
        var input=el(kind+'_'+key);
        if(s[key]!==undefined){if(input.type==='checkbox')input.checked=s[key];else input.value=s[key];}
      });
    });
  }
  function receive(next, settings, presets, caps, id) {
    var changed=modelId!==id;
    capabilities=caps||capabilities;
    if(!initialized || changed) {setConfig(settings,false);initialized=true;modelId=id;}
    else if(presetPending && presetPending.action==='load') {setConfig(settings,true);el('apply_model_units').checked=false;}
    var chosen=presetPending?presetPending.name:el('preset').value;
    el('preset').replaceChildren();
    Object.keys(presets||{}).forEach(function(name){var option=document.createElement('option');option.value=name;option.textContent=name;el('preset').appendChild(option);});
    if(Object.prototype.hasOwnProperty.call(presets||{},chosen))el('preset').value=chosen;
    presetPending=null;deleting=null;el('delete_confirm').hidden=true;
    scan=next;busy=false;
    ['dimension','text','label','nested'].forEach(function(kind){el('count_'+kind).textContent=next?next[kind]:'—';});
    el('scan_details').textContent=next ? 'SCAN theo vị trí đặt: '+(next.dimension+next.text+next.label)+' annotation; '+next.unique+' entity độc lập. Bỏ qua '+next.hidden_skipped+' đối tượng/nhóm ẩn, '+next.locked_skipped+' nhóm khóa, '+next.legacy+' annotation T+ hình học cũ.' : 'Chưa SCAN phạm vi hiện tại.';
    controls();
  }
  function invalidate(id) {
    if(id!==modelId){initialized=false;modelId=null;call('ready');}
    clearScan('Model/phạm vi đã đổi. Bấm SCAN trước khi áp dụng.');
  }
  function runScan() {
    try {
      var data=config();busy=true;controls();status('Đang SCAN phạm vi…');
      if(!call('scan',JSON.stringify(data))){busy=false;controls();status('SCAN hoạt động trong SketchUp.');}
    } catch(error){busy=false;controls();status(error.message,true);}
  }
  function apply(chosen, quick) {
    if(busy || (!quick && (!scan||!scan.can_apply||scan.blocked)))return;
    try {
      var data=config();data.types=chosen;
      if(quick){data.scope='entire';el('scope').value='entire';clearScan();}
      else data.scan_token=scan.scan_token;
      busy=true;controls();status(quick?'Đang Quick Fix toàn model…':'Đang áp định dạng…');
      if(!call(quick?'quick_fix':'apply',JSON.stringify(data))){busy=false;controls();status('Apply hoạt động trong SketchUp.');}
    } catch(error){busy=false;controls();status(error.message,true);}
  }
  function presetAction(action,name) {
    try {
      if(!name || !name.trim())throw Error('Nhập hoặc chọn tên preset.');
      presetPending={action:action,name:name.trim()};busy=true;controls();
      if(!call('preset',JSON.stringify({action:action,name:name.trim(),config:config()}))){busy=false;presetPending=null;controls();status('Lưu/nạp preset hoạt động trong SketchUp.');}
    } catch(error){busy=false;presetPending=null;controls();status(error.message,true);}
  }
  document.querySelectorAll('[data-page]').forEach(function(button){
    button.addEventListener('click',function(){
      document.querySelectorAll('[data-page]').forEach(function(b){if(b===button)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
      document.querySelectorAll('[data-panel]').forEach(function(panel){panel.hidden=panel.dataset.panel!==button.dataset.page;});
      el('panels').scrollTop=0;
      controls();
    });
  });
  document.querySelectorAll('[data-apply]').forEach(function(button){button.addEventListener('click',function(){apply([button.dataset.apply],false);});});
  document.querySelectorAll('[data-quick]').forEach(function(button){button.addEventListener('click',function(){apply(button.dataset.quick==='all'?types:[button.dataset.quick],true);});});
  document.querySelectorAll('[data-info]').forEach(function(button){button.addEventListener('click',function(){call('model_info',button.dataset.info);});});
  el('scan').addEventListener('click',runScan);
  el('apply').addEventListener('click',function(){var page=document.querySelector('[data-page][aria-current]').dataset.page;apply(types.includes(page)?[page]:types,false);});
  el('normalize').addEventListener('click',function(){apply(types,false);});
  el('load_preset').addEventListener('click',function(){presetAction('load',el('preset').value);});
  el('save_preset').addEventListener('click',function(){presetAction('save',el('preset_name').value);});
  el('update_preset').addEventListener('click',function(){presetAction('update',el('preset').value);});
  el('delete_preset').addEventListener('click',function(){deleting=el('preset').value;el('delete_question').textContent='Xóa preset “'+deleting+'”? ';el('delete_confirm').hidden=false;});
  el('cancel_delete').addEventListener('click',function(){deleting=null;el('delete_confirm').hidden=true;});
  el('confirm_delete').addEventListener('click',function(){if(deleting)presetAction('delete',deleting);});
  el('preset').addEventListener('change',function(){deleting=null;el('delete_confirm').hidden=true;controls();});
  ['scope'].concat(scopeKeys).forEach(function(id){el(id).addEventListener('change',function(){clearScan('Phạm vi đã đổi. Bấm SCAN.');});});
  document.addEventListener('change',controls);
  function theme(dark){document.body.classList.toggle('dark',dark);el('theme').textContent=dark?'Sáng':'Tối';}
  el('theme').addEventListener('click',function(){var dark=!document.body.classList.contains('dark');theme(dark);try{localStorage.setItem('tplus_theme',dark?'dark':'light');}catch(_error){}});
  window.TPlusAnnotation={receive:receive,status:function(message,error){busy=false;presetPending=null;controls();status(message,error);},invalidate:invalidate};
  try{theme(localStorage.getItem('tplus_theme')==='dark');}catch(_error){theme(false);}
  controls();
  if(!call('ready'))status('Bản xem trước. SCAN / Apply / Preset hoạt động trong SketchUp.');
})();
