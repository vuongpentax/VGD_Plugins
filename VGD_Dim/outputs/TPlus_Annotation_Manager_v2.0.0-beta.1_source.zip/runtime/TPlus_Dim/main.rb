# encoding: UTF-8
require 'sketchup.rb'
require 'json'
require_relative 'defaults'
require_relative 'custom_dim'
require_relative 'engine'
require_relative 'presets'
module TPlus
  module Dim
    extend self
    PREF_KEY = 'TPlus_Dim'.freeze unless const_defined?(:PREF_KEY, false)
    ProfileService.shutdown if defined?(ProfileService)
    class SelectionWatch < Sketchup::SelectionObserver
      def onSelectionBulkChange(_selection); Dim.selection_changed; end
      def onSelectionAdded(_selection, _entity); Dim.selection_changed; end
      def onSelectionRemoved(_selection, _entity); Dim.selection_changed; end
      def onSelectionCleared(_selection); Dim.selection_changed; end
    end
    class ModelWatch < Sketchup::ModelObserver
      def onActivePathChanged(_model); Dim.queue_sync; end
      def onTransactionUndo(_model); Dim.queue_sync; end
      def onTransactionRedo(_model); Dim.queue_sync; end
      def onTransactionCommit(_model); Dim.queue_sync; end
    end
    class AppWatch < Sketchup::AppObserver
      def onActivateModel(_model); Dim.attach_model; Dim.queue_sync; end
      def onNewModel(_model); Dim.attach_model; Dim.queue_sync; end
      def onOpenModel(_model); Dim.attach_model; Dim.queue_sync; end
    end
    def settings
      return @settings if @settings
      saved = JSON.parse(Sketchup.read_default(PREF_KEY, 'annotation_settings', '{}')) rescue {}
      @settings = Engine.validate(saved.is_a?(Hash) ? saved : {})
      @settings['apply_model_units'] = false
      @settings
    rescue ArgumentError
      @settings = Engine.clone_defaults
    end
    def attach_model
      model = Sketchup.active_model
      return if @watched_model == model
      detach_model
      @scan = nil
      @settings['apply_model_units'] = false if @settings
      @watched_model = model
      @selection_watch = SelectionWatch.new
      @model_watch = ModelWatch.new
      model.selection.add_observer(@selection_watch)
      model.add_observer(@model_watch)
    end
    def detach_model
      if @watched_model
        @watched_model.selection.remove_observer(@selection_watch) if @selection_watch
        @watched_model.remove_observer(@model_watch) if @model_watch
      end
      @watched_model = @selection_watch = @model_watch = nil
    rescue StandardError
      @watched_model = @selection_watch = @model_watch = nil
    end
    def selection_changed; queue_sync if settings['scope'] == 'selected'; end
    def queue_sync
      return unless @dialog && @ready && !@applying
      UI.stop_timer(@sync_timer) if @sync_timer
      @scan = nil
      @sync_timer = UI.start_timer(0.12, false) do
        @sync_timer = nil
        attach_model
        @dialog.execute_script("TPlusAnnotation.invalidate(#{JSON.generate(Sketchup.active_model.guid)});") if @dialog && @ready
      end
    end
    def sync
      return unless @dialog && @ready
      attach_model
      @dialog.execute_script("TPlusAnnotation.receive(#{JSON.generate(@scan)}, #{JSON.generate(settings)}, #{JSON.generate(Presets.all)}, #{JSON.generate(Engine.capabilities)}, #{JSON.generate(Sketchup.active_model.guid)});")
    end
    def report(message, error = false)
      @dialog.execute_script("TPlusAnnotation.status(#{JSON.generate(message)}, #{error ? 'true' : 'false'});") if @dialog && @ready
    end
    def parse(payload)
      data = payload.is_a?(String) ? JSON.parse(payload) : payload
      raise ArgumentError, 'Dữ liệu không hợp lệ.' unless data.is_a?(Hash)
      data
    end
    def scan_payload(payload)
      data = parse(payload)
      @settings = Engine.validate(data)
      @scan = Engine.scan(Sketchup.active_model, @settings)
      sync
      report(@scan[:blocked] || "SCAN: #{@scan[:dimension]} Dim · #{@scan[:text]} Text · #{@scan[:label]} Label; #{@scan[:nested]} annotation lồng nhóm. Chưa sửa model.", !!@scan[:blocked])
    rescue StandardError => error
      @scan = nil
      sync
      report(error.message, true)
    end
    def result_message(result)
      message = "Đã áp định dạng: #{result[:dimension]} Dim · #{result[:text]} Text · #{result[:label]} Label"
      message += " · tách riêng #{result[:unique]} nhóm/component" if result[:unique] > 0
      pending = result[:font_pending].values.sum
      message += ". Chưa chuẩn font/cỡ chữ của #{pending} annotation; cần Model Info" if pending > 0
      message += '. Đã đổi Units/precision cho toàn model' if result[:model_units_changed]
      message += '. Units/precision giữ theo model hiện tại' if result[:model_units_kept]
      message += ". Bỏ qua #{result[:legacy_skipped]} annotation T+ hình học cũ" if result[:legacy_skipped] > 0
      message + '. Một Undo; Ctrl+S để lưu SKP.'
    end
    def apply_payload(payload, quick = false)
      data = parse(payload)
      config = Engine.validate(data)
      config['scope'] = 'entire' if quick
      types = data.fetch('types', Engine::TYPES)
      token = quick ? Engine.scan(Sketchup.active_model, config)[:scan_token] : data['scan_token']
      @applying = true
      result = Engine.apply(Sketchup.active_model, config, token, types)
      @settings = config
      saved = config.merge('apply_model_units' => false)
      Sketchup.write_default(PREF_KEY, 'annotation_settings', JSON.generate(saved))
      @scan = nil
      sync
      report(result_message(result), result[:font_pending].values.sum > 0 || result[:legacy_skipped] > 0)
    rescue StandardError => error
      puts "[T+ Annotation] #{error.class}: #{error.message}"
      @scan = nil
      sync
      report(error.message, true)
    ensure
      @applying = false
    end
    def preset_payload(payload)
      data = parse(payload)
      config = Engine.validate(data.fetch('config', {}))
      @scan = nil unless (%w[scope include_nested include_components include_hidden include_locked]).all? { |key| config[key] == settings[key] }
      if data['action'] == 'load'
        preset = Presets.all.fetch(data['name']) { raise ArgumentError, 'Không tìm thấy preset.' }
        @settings = Engine.validate(config.merge(preset))
        @settings['apply_model_units'] = false
      else
        Presets.mutate(data['action'], data['name'], config)
        @settings = config
      end
      # A preset changes styles, not the last scanned scope. Apply revalidates the token.
      sync
      report(data['action'] == 'load' ? 'Đã nạp preset. Font/cỡ chữ chưa hỗ trợ vẫn cần Model Info.' : 'Đã lưu thay đổi preset; không sửa model.')
    rescue StandardError => error
      report(error.message, true)
    end
    def open_model_info(page)
      name = page == 'Dimensions' ? 'Dimensions' : 'Text'
      ok = UI.show_model_info(name)
      report(ok ? 'Chỉnh font/cỡ chữ trong Model Info rồi Update Selected. Mặc định của file lưu bằng Ctrl+S.' : 'Mở Window → Model Info để chỉnh font/cỡ chữ.', !ok)
    end
    def reload_extension; load File.join(__dir__, 'reload.rb'); end
    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        return
      end
      @ready = false; @settings = nil; @scan = nil
      dialog = UI::HtmlDialog.new(dialog_title: 'T+ Annotation Manager · 2.0 beta 1',
        preferences_key: PREF_KEY, scrollable: true, resizable: true, width: 550, height: 740,
        min_width: 440, min_height: 540, style: UI::HtmlDialog::STYLE_DIALOG)
      @dialog = dialog
      dialog.set_file(File.join(__dir__, 'dialog.html'))
      dialog.add_action_callback('ready') { @ready = true; attach_model; sync }
      dialog.add_action_callback('scan') { |_, payload| scan_payload(payload) }
      dialog.add_action_callback('apply') { |_, payload| apply_payload(payload) }
      dialog.add_action_callback('quick_fix') { |_, payload| apply_payload(payload, true) }
      dialog.add_action_callback('preset') { |_, payload| preset_payload(payload) }
      dialog.add_action_callback('model_info') { |_, page| open_model_info(page) }
      dialog.add_action_callback('close') { dialog.close }
      dialog.set_on_closed do
        if @dialog.equal?(dialog)
          UI.stop_timer(@sync_timer) if @sync_timer
          @sync_timer = nil; @dialog = nil; @ready = false; @scan = nil
          detach_model
          Sketchup.remove_observer(@app_watch) if @app_watch
          @app_watch = nil
        end
      end
      @app_watch ||= AppWatch.new
      Sketchup.add_observer(@app_watch)
      dialog.show
    end
    unless @command
      @command = UI::Command.new('T+ Annotation Manager') { show_dialog }
      @command.small_icon = @command.large_icon = File.join(__dir__, 'dim.svg')
      UI.menu('Extensions').add_item(@command) unless file_loaded?(__FILE__)
      unless @toolbar
        @toolbar = UI::Toolbar.new('T+ Annotation Manager')
        @toolbar.add_item(@command)
      end
      UI.menu('Extensions').add_item('Hiện toolbar T+ Annotation') { @toolbar.show }
      UI.menu('Extensions').add_item('Nạp lại T+ Annotation') { reload_extension }
      file_loaded(__FILE__)
    end
    @command.tooltip = 'T+ Annotation Manager · Scan / Apply / Normalize'
    @command.status_bar_text = 'Chuẩn định dạng Dim, Text, Label native theo phạm vi và preset.'
  end
end
