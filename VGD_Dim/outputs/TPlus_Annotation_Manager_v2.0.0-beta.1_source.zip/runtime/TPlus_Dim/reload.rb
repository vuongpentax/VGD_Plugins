# encoding: UTF-8
require 'sketchup.rb'
# Only T+ Dim files; do not touch other extensions, models or toolbar placement.
files = %w[defaults custom_dim engine presets main].map { |name| File.join(__dir__, name + '.rb') }
files.each { |path| RubyVM::InstructionSequence.compile_file(path) }
if defined?(TPlus::Dim)
  dialog = TPlus::Dim.instance_variable_get(:@dialog)
  dialog.close if dialog
  TPlus::Dim::ProfileService.shutdown if defined?(TPlus::Dim::ProfileService)
  TPlus::Dim.detach_model if TPlus::Dim.respond_to?(:detach_model)
  TPlus::Dim.send(:remove_const, :DEFAULTS) if TPlus::Dim.const_defined?(:DEFAULTS, false)
  TPlus::Dim.send(:remove_const, :VERSION) if TPlus::Dim.const_defined?(:VERSION, false)
  TPlus::Dim.const_set(:VERSION, '2.0.0-beta.1'.freeze)
end
files.each { |path| load path }
TPlus::Dim.show_dialog
