# encoding: UTF-8
require 'json'
module TPlus
  module Dim
    module Presets
      extend self
      KEY = 'TPlus_Dim'.freeze unless const_defined?(:KEY, false)
      TYPES = %w[dimension text label].freeze unless const_defined?(:TYPES, false)
      def styles(config); TYPES.to_h { |kind| [kind, config.fetch(kind).dup] }; end
      def builtins
        layout = styles(Engine.validate({}))
        working = JSON.parse(JSON.generate(layout))
        working.each_value { |s| s.merge!('size' => 10.0, 'size_unit' => 'pt') }
        {'T+ STANDARD' => layout, 'T+ Working' => working, 'T+ Layout' => layout}
      end
      def read
        raw = JSON.parse(Sketchup.read_default(KEY, 'annotation_presets', 'null')) rescue nil
        return nil unless raw.is_a?(Hash)
        raw.each_with_object({}) do |(name, value), result|
          next unless valid_name?(name) && value.is_a?(Hash)
          begin
            result[name] = styles(Engine.validate(value))
          rescue ArgumentError
            next
          end
        end
      end
      def all; read || builtins; end
      def valid_name?(name); name.is_a?(String) && !name.strip.empty? && name.length <= 80 && !name.match?(/[\x00-\x1f]/); end
      def mutate(action, name, config = nil)
        raise ArgumentError, 'Tên preset phải từ 1–80 ký tự.' unless valid_name?(name)
        name = name.strip
        saved = all
        case action
        when 'save'
          raise ArgumentError, 'Tên đã có. Dùng Cập nhật preset.' if saved.key?(name)
          saved[name] = styles(Engine.validate(config))
        when 'update'
          raise ArgumentError, 'Không tìm thấy preset để cập nhật.' unless saved.key?(name)
          saved[name] = styles(Engine.validate(config))
        when 'delete'
          raise ArgumentError, 'Không tìm thấy preset để xóa.' unless saved.key?(name)
          saved.delete(name)
        else
          raise ArgumentError, 'Thao tác preset không hợp lệ.'
        end
        Sketchup.write_default(KEY, 'annotation_presets', JSON.generate(saved))
        all
      end
    end
  end
end
