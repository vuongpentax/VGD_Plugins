# encoding: UTF-8
module TPlus
  module Dim
    DEFAULTS = {
      'scope' => 'entire', 'include_nested' => true, 'include_components' => true,
      'include_hidden' => false, 'include_locked' => false, 'apply_model_units' => false,
      'dimension' => {'font' => 'Arial', 'size' => 2.5, 'size_unit' => 'mm', 'bold' => false, 'italic' => false,
        'apply_font' => true, 'color' => '#000000', 'arrow' => 'closed', 'alignment' => 'aligned',
        'position' => 'above', 'unit' => 'mm', 'precision' => 0, 'show_unit' => false},
      'text' => {'font' => 'Arial', 'size' => 2.5, 'size_unit' => 'mm', 'bold' => false, 'italic' => false,
        'apply_font' => true, 'color' => '#000000'},
      'label' => {'font' => 'Arial', 'size' => 2.5, 'size_unit' => 'mm', 'bold' => false, 'italic' => false,
        'apply_font' => true, 'color' => '#000000', 'arrow' => 'closed', 'leader' => 'view', 'display' => 'keep'}
    }.freeze unless const_defined?(:DEFAULTS, false)
  end
end
