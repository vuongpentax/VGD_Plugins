# encoding: UTF-8
require 'json'
require 'digest'
module TPlus
  module Dim
    module Engine
      extend self
      TYPES = %w[dimension text label].freeze unless const_defined?(:TYPES, false)
      FILTERS = %w[include_nested include_components include_hidden include_locked apply_model_units].freeze unless const_defined?(:FILTERS, false)
      def clone_defaults; JSON.parse(JSON.generate(Dim::DEFAULTS)); end
      def validate(data)
        raise ArgumentError, 'Cấu hình không hợp lệ.' unless data.is_a?(Hash)
        config = clone_defaults
        config['scope'] = data['scope'] if data.key?('scope')
        raise ArgumentError, 'Phạm vi không hợp lệ.' unless %w[selected context entire].include?(config['scope'])
        FILTERS.each do |key|
          config[key] = data[key] if data.key?(key)
          raise ArgumentError, "Tùy chọn #{key} không hợp lệ." unless [true, false].include?(config[key])
        end
        TYPES.each do |kind|
          input = data.fetch(kind, {})
          raise ArgumentError, "Style #{kind} không hợp lệ." unless input.is_a?(Hash)
          s = config[kind].merge(input.select { |key, _| config[kind].key?(key) })
          raise ArgumentError, 'Tên font không hợp lệ.' unless s['font'].is_a?(String) && !s['font'].strip.empty? && s['font'].length <= 256 && !s['font'].match?(/[\x00-\x1f]/)
          s['font'] = s['font'].strip
          s['size'] = Float(s['size'])
          raise ArgumentError, 'Đơn vị cỡ chữ không hợp lệ.' unless %w[pt mm].include?(s['size_unit'])
          limit = s['size_unit'] == 'pt' ? (1.0..1000.0) : (0.01..100000.0)
          raise ArgumentError, 'Cỡ chữ phải là số dương trong giới hạn pt 1–1000 hoặc mm 0,01–100.000.' unless s['size'].finite? && limit.cover?(s['size'])
          %w[bold italic apply_font].each { |key| raise ArgumentError, 'Tùy chọn font không hợp lệ.' unless [true, false].include?(s[key]) }
          raise ArgumentError, 'Màu phải ở dạng #RRGGBB.' unless s['color'].is_a?(String) && s['color'].match?(/\A#[0-9a-fA-F]{6}\z/)
          s['color'] = s['color'].upcase
          raise ArgumentError, 'Kiểu đầu dim/leader không hợp lệ.' if s.key?('arrow') && !%w[keep none slash dot closed open].include?(s['arrow'])
          if kind == 'dimension'
            raise ArgumentError, 'Hướng chữ không hợp lệ.' unless %w[keep aligned screen].include?(s['alignment'])
            raise ArgumentError, 'Vị trí chữ không hợp lệ.' unless %w[keep above center outside].include?(s['position'])
            raise ArgumentError, 'Đơn vị không hợp lệ.' unless %w[model mm cm m inch].include?(s['unit'])
            s['precision'] = Integer(s['precision'].to_s, 10)
            raise ArgumentError, 'Precision phải từ 0 đến 6.' unless (0..6).cover?(s['precision'])
            raise ArgumentError, 'Hiển thị đơn vị không hợp lệ.' unless [true, false].include?(s['show_unit'])
          elsif kind == 'label'
            raise ArgumentError, 'Kiểu leader không hợp lệ.' unless %w[keep view model].include?(s['leader'])
            raise ArgumentError, 'Hiển thị leader không hợp lệ.' unless %w[keep show hide].include?(s['display'])
          end
          config[kind] = s
        end
        config
      rescue TypeError, ArgumentError => error
        raise ArgumentError, error.message
      end
      def container?(e); e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance); end
      def children(e); e.is_a?(Sketchup::Group) ? e.entities : e.definition.entities; end
      def locked?(e); container?(e) && e.locked?; end
      def hidden?(e); e.hidden? || (e.layer && e.layer.respond_to?(:visible?) && !e.layer.visible?); end
      def legacy?(e); CustomDim.view?(e) || CustomDim.source?(e); end
      def kind(e)
        return nil if legacy?(e)
        return 'dimension' if e.is_a?(Sketchup::Dimension)
        return (e.has_leader? ? 'label' : 'text') if e.is_a?(Sketchup::Text)
        nil
      end
      def descend?(e, config, depth)
        return false unless container?(e)
        return false if !e.is_a?(Sketchup::Group) && !config['include_components']
        config['include_nested'] || (config['scope'] == 'selected' && depth == 0)
      end
      def allowed?(e, config)
        e.valid? && !legacy?(e) && (config['include_hidden'] || !hidden?(e)) && (config['include_locked'] || !locked?(e))
      end
      def roots(model, config)
        case config['scope']
        when 'selected'; model.selection.to_a
        when 'context'; model.active_entities.to_a
        else; model.entities.to_a
        end
      end
      def blocked_context(model, config)
        path = model.active_path || []
        return 'Đóng chế độ sửa Group/Component trước khi chạy Entire Model.' if config['scope'] == 'entire' && !path.empty?
        return 'Đóng edit context dùng chung rồi chọn nhóm cha để giữ đúng phạm vi.' if path.any? { |e| e.definition.instances.length > 1 }
        return 'Ngữ cảnh đang mở bị khóa; bật Include Locked Objects hoặc đóng ngữ cảnh.' if !config['include_locked'] && path.any? { |e| locked?(e) }
        nil
      end
      def walk(entities, config, stats, path = [], ancestry = [], depth = 0, &block)
        entities.each do |e|
          next unless e.valid?
          pids = path + [e.persistent_id]
          if legacy?(e)
            stats[:legacy] += 1 unless CustomDim.source?(e) && CustomDim.partner(e)
            stats[:signature] << [pids, 'legacy']
            next
          end
          unless config['include_hidden'] || !hidden?(e)
            stats[:hidden_skipped] += 1
            stats[:signature] << [pids, 'hidden']
            next
          end
          unless config['include_locked'] || !locked?(e)
            stats[:locked_skipped] += 1
            stats[:signature] << [pids, 'locked']
            next
          end
          type = kind(e)
          if type
            stats[type.to_sym] += 1
            stats[:nested] += 1 if depth > 0 || !path.empty?
            stats[:unique][e.persistent_id] = true
            stats[:signature] << [pids, type]
            block.call(e, type) if block
          elsif descend?(e, config, depth) && !ancestry.include?(e.definition)
            walk(children(e), config, stats, pids, ancestry + [e.definition], depth + 1, &block)
          end
        end
      end
      def scan(model, config)
        stats = {dimension: 0, text: 0, label: 0, nested: 0, legacy: 0, hidden_skipped: 0,
          locked_skipped: 0, signature: [], unique: {}}
        base_path = config['scope'] == 'entire' ? [] : (model.active_path || []).map(&:persistent_id)
        walk(roots(model, config), config, stats, base_path, (model.active_path || []).map(&:definition), 0)
        signature = [model.guid, base_path, config['scope'], FILTERS.reject { |k| k == 'apply_model_units' }.map { |k| config[k] },
          config['scope'] == 'selected' ? model.selection.to_a.map(&:persistent_id).sort : [], stats.delete(:signature)]
        stats[:scan_token] = Digest::SHA256.hexdigest(JSON.generate(signature))
        stats[:unique] = stats[:unique].size
        stats[:blocked] = blocked_context(model, config)
        stats[:model_id] = model.guid
        stats[:can_apply] = stats[:dimension] + stats[:text] + stats[:label] > 0 && stats[:blocked].nil?
        stats
      end
      def has_targets?(entities, config, types, depth, ancestry)
        entities.any? do |e|
          next false unless allowed?(e, config)
          next true if types.include?(kind(e))
          descend?(e, config, depth) && !ancestry.include?(e.definition) &&
            has_targets?(children(e), config, types, depth + 1, ancestry + [e.definition])
        end
      end
      def material(model, hex)
        name = 'T+ Annotation ' + hex
        expected = [hex[1,2].to_i(16), hex[3,2].to_i(16), hex[5,2].to_i(16)]
        found = model.materials[name]
        return found if found && [found.color.red, found.color.green, found.color.blue] == expected
        found = model.materials.add(name)
        found.color = Sketchup::Color.new(*expected)
        found
      end
      def arrow(value)
        {'none' => Sketchup::Dimension::ARROW_NONE, 'slash' => Sketchup::Dimension::ARROW_SLASH,
         'dot' => Sketchup::Dimension::ARROW_DOT, 'closed' => Sketchup::Dimension::ARROW_CLOSED,
         'open' => Sketchup::Dimension::ARROW_OPEN}.fetch(value)
      end
      def style_entity(entity, type, style, colors, stats)
        entity.material = colors[type]
        if type == 'dimension'
          entity.arrow_type = arrow(style['arrow']) unless style['arrow'] == 'keep'
          entity.has_aligned_text = style['alignment'] == 'aligned' unless style['alignment'] == 'keep'
          if entity.is_a?(Sketchup::DimensionLinear) && entity.has_aligned_text? && style['position'] != 'keep'
            entity.aligned_text_position = {'above' => Sketchup::DimensionLinear::ALIGNED_TEXT_ABOVE,
              'center' => Sketchup::DimensionLinear::ALIGNED_TEXT_CENTER, 'outside' => Sketchup::DimensionLinear::ALIGNED_TEXT_OUTSIDE}.fetch(style['position'])
          end
        elsif type == 'label'
          entity.arrow_type = arrow(style['arrow']) unless style['arrow'] == 'keep'
          entity.leader_type = style['leader'] == 'view' ? ALeaderView : ALeaderModel unless style['leader'] == 'keep'
          entity.display_leader = style['display'] == 'show' unless style['display'] == 'keep'
        end
        if style['apply_font']
          # The public Text setter supports integer points from SU2026.2, not world height.
          if type != 'dimension' && entity.respond_to?(:font=) && style['size_unit'] == 'pt' && style['size'] == style['size'].round
            entity.font = {name: style['font'], size: style['size'].round, bold: style['bold'], italic: style['italic']}
            stats[:font_applied] += 1
          else
            stats[:font_pending][type] += 1
          end
        end
        stats[type.to_sym] += 1
      end
      def mutate(entities, model, config, types, colors, stats, depth = 0, ancestry = [], visited = nil)
        entities.each do |e|
          next unless allowed?(e, config)
          type = kind(e)
          if types.include?(type)
            style_entity(e, type, config[type], colors, stats)
          elsif descend?(e, config, depth) && !ancestry.include?(e.definition) &&
              has_targets?(children(e), config, types, depth + 1, ancestry + [e.definition])
            was_locked = e.locked?
            original_definition = e.definition
            begin
              e.locked = false if was_locked
              if visited
                next if visited[e.definition]
                visited[e.definition] = true
              elsif e.definition.instances.length > 1
                e.make_unique
                stats[:unique] += 1
              end
              mutate(children(e).to_a, model, config, types, colors, stats, depth + 1, (ancestry + [original_definition, e.definition]).uniq, visited)
            ensure
              e.locked = true if was_locked && e.valid?
            end
          end
        end
      end
      def apply(model, config, scan_token, types = TYPES)
        raise ArgumentError, 'Loại annotation không hợp lệ.' unless types.is_a?(Array) && !types.empty? && (types - TYPES).empty?
        fresh = scan(model, config)
        raise ArgumentError, 'Phạm vi đã thay đổi. Bấm SCAN trước khi áp dụng.' unless fresh[:scan_token] == scan_token
        raise ArgumentError, fresh[:blocked] if fresh[:blocked]
        raise ArgumentError, 'Không có annotation thuộc loại được chọn trong phạm vi này.' unless types.sum { |k| fresh[k.to_sym] } > 0
        stats = {dimension: 0, text: 0, label: 0, unique: 0, font_applied: 0,
          font_pending: TYPES.to_h { |k| [k, 0] }, model_units_changed: false,
          legacy_skipped: fresh[:legacy], model_units_kept: types.include?('dimension') && !config['apply_model_units']}
        started = false
        unlocked = []
        begin
          model.start_operation('T+ Annotation Normalize', true)
          started = true
          (model.active_path || []).each do |e|
            if locked?(e)
              e.locked = false
              unlocked << e
            end
          end
          colors = types.to_h { |k| [k, material(model, config[k]['color'])] }
          # Only the unfiltered Entire Model route can safely edit shared definitions once.
          full = config['scope'] == 'entire' && %w[include_nested include_components include_hidden include_locked].all? { |k| config[k] }
          mutate(roots(model, config), model, config, types, colors, stats, 0, (model.active_path || []).map(&:definition), full ? {} : nil)
          if config['apply_model_units'] && types.include?('dimension')
            s = config['dimension']; units = model.options['UnitsOptions']
            units['LengthFormat'] = Length::Decimal
            units['LengthUnit'] = {'mm' => 2, 'cm' => 3, 'm' => 4, 'inch' => 0}.fetch(s['unit']) unless s['unit'] == 'model'
            units['LengthPrecision'] = s['precision']
            units['SuppressUnitsDisplay'] = !s['show_unit']
            stats[:model_units_changed] = true
          end
          unlocked.reverse_each { |e| e.locked = true if e.valid? }
          unlocked.clear
          model.commit_operation
          started = false
          model.active_view.invalidate
          stats
        rescue StandardError
          unlocked.reverse_each { |e| e.locked = true if e.valid? }
          model.abort_operation if started
          raise
        end
      end
      def capabilities
        {'dimension_font' => false, 'text_font_pt' => Sketchup::Text.instance_methods.include?(:font=),
         'label_font_pt' => Sketchup::Text.instance_methods.include?(:font=),
         'font_mm' => false, 'arrow_size' => false, 'text_gap' => false, 'text_alignment' => false}
      end
    end
  end
end
