# T+ Annotation Manager · 2.0.0-beta.1

Nâng cấp từ T+ Dim, theo yêu cầu tại ANNOTATION_REQUIREMENTS.md. Giữ nguyên bộ nạp tplus_dim.rb và namespace TPlus::Dim để không tạo plugin trùng. Plugin quản lý **Dimension / Text không có leader / Label có leader** native.

**Phần chuẩn font/cỡ chữ hàng loạt trên SU2022 chưa thực hiện được bằng Ruby API.** Apply/Normalize hiện chuẩn màu, hướng/vị trí chữ dim, đầu dim, kiểu/hiển thị leader và Units khi được bật riêng. Font/cỡ chữ lưu làm mục tiêu preset; vẫn cần thao tác Model Info. Không tạo chữ bằng edge/face. Xem FEATURE_STATUS.md cho trạng thái từng yêu cầu.

## Workflow

1. Chọn phạm vi Selected / Current Context / Entire Model. Mặc định Entire Model, Nested Groups và Components bật; Hidden và Locked tắt.
2. Nạp preset hoặc chỉnh style riêng trong ba tab Dimension / Text / Label.
3. Bấm **SCAN**. Chỉ đếm, không ghi model. Báo số theo vị trí đặt; một component đặt hai lần có thể được đếm hai lần. Số entity độc lập có trong Quick Fix.
4. **Apply Dimension/Text/Label Style** chỉ áp loại tương ứng. Nút APPLY áp loại của tab hiện tại; tại Quick Fix, APPLY áp ba loại. **NORMALIZE ALL** áp cả ba loại trong phạm vi đã chọn.
5. Mỗi Apply/Normalize có một operation **T+ Annotation Normalize**. Ctrl+Z hoàn tác; Ctrl+S lưu SKP.

Quick Fix có FIX ALL DIMENSIONS / TEXT / LABELS / ALL: quét rồi áp cho **Entire Model**, dùng các bộ lọc đang chọn. Không cần Scan trước riêng; báo phần font/cỡ chữ chưa hỗ trợ sau khi chạy. Muốn chạy Entire Model, đóng edit context trước.

## Những gì được giữ nguyên

Giữ nội dung Text/Label và dim nhập đè, vị trí/chân leader, điểm đo, khoảng cách dim tới vật thể, tag, hình học và trạng thái ẩn/khóa. Không move, explode, xóa annotation hoặc dựng chữ hình học.

Component/group dùng chung được make_unique khi cần cách ly phạm vi và đối tượng bị loại bởi bộ lọc; hình học và transformation giữ nguyên. Entire Model với toàn bộ bộ lọc bật xử lý mỗi definition một lần để tránh nhân bản không cần thiết. Không đổi trong edit context thuộc definition chia sẻ: đóng edit và chọn nhóm cha.

Include Locked mở khóa tạm khi áp style, khóa lại trước commit hoặc khi lỗi. Bỏ chọn Hidden sẽ loại cả nhánh dưới nhóm/tag ẩn. Selected với Nested tắt vẫn xử lý nội dung trực tiếp của nhóm đã chọn; không xuống nhóm lồng tiếp. Components tắt bỏ cả component được chọn. Current Context bắt đầu từ entities của ngữ cảnh đang mở.

Annotation T+ hình học beta 2 được đếm riêng và bỏ qua; NORMALIZE không tự khôi phục hoặc xóa nguồn/chữ. Nếu toàn bộ phạm vi là loại này, không bắt đầu operation.

## Font/size và Model Info

Font, size pt/mm và đậm/nghiêng được lưu làm **mục tiêu** preset. Trên SU2022, chúng chưa được ghi vào Dimension/Text/Label bằng plugin. Giao diện và kết quả Apply ghi rõ phần chưa chuẩn font/cỡ chữ.

Bấm Model Info → Dimensions hoặc Text; chọn font và Points/Height, rồi Update Selected. Với toàn bộ dim có thể Select All Dimensions. Thao tác font bằng Model Info là riêng, không được gộp vào Undo của plugin hoặc quảng cáo là font đã được Normalize.

Nếu Text#font= tồn tại (API từ SU2026.2), Text/Label có thể dùng pt nguyên 1–1000 qua setter công khai. Chưa kiểm thử native phiên bản đó. Size mm, pt lẻ, font Dimension, cỡ arrow, khoảng cách chữ–đường dim và căn Text vẫn báo chưa hỗ trợ. Không quy đổi mm thành pt vì đây là hai chế độ hiển thị khác nhau.

## Units / Precision

Đây là lựa chọn toàn model, kể cả dim ngoài phạm vi. Mở mục Units / Precision và bật **Áp Units / Precision cho toàn model** để cho phép đổi. Checkbox mặc định tắt, không lưu trong preset và reset khi mở dialog/chuyển model/nạp preset.

Chọn “Theo Units của model” giữ LengthUnit hiện có; khi bật áp Units, chuyển định dạng chiều dài về Decimal và ghi precision/show unit. Text-only hoặc Label-only không đổi Units. Không đổi kích thước hình học.

## Preset

Có sẵn T+ STANDARD (Arial, 2.5 mm, đen, dim/leader Closed), T+ Working (10 pt), T+ Layout (2.5 mm). Có Lưu mới / Nạp / Cập nhật / Xóa; xóa cần xác nhận.

Preset lưu dưới khóa riêng TPlus_Dim trong preferences, chỉ lưu ba style; không lưu scope, bộ lọc hoặc checkbox đổi Units. Có thể cập nhật/xóa cả preset mẫu. Preset không phải mặc định của Model Info và không tự cài font trên máy nhận.

## Cài và nạp lại

outputs/TPlus_Annotation_Manager_v2.0.0-beta.1.rbz và source ZIP đi kèm. dev/deploy.ps1 đồng bộ 11 file riêng T+ Dim vào SU2022 theo APPDATA, sao lưu và đối chiếu SHA256; không đổi Cabinet hoặc plugin khác.

Phiên cũ đang mở: dùng Extensions → Nạp lại T+ Dim / T+ Annotation, hoặc Ruby Console:

~~~ruby
load File.join(Sketchup.find_support_file('Plugins'), 'TPlus_Dim', 'reload.rb')
~~~

Tái dùng toolbar/menu đang có; tên menu/toolbar T+ Dim cũ có thể còn trong phiên hot reload. Sau lần khởi động SketchUp tiếp theo, extension hiển thị T+ Annotation Manager. Không tự thay đổi bố cục toolbar.

## Kiểm thử

- node dev/check_ruby.cjs: Ruby WASM 3.2 + API fixture. Scope/filters, native properties, shared/hidden isolation, temporary lock restoration, recursion, stale scan, unsupported font reporting, preset CRUD, global Units opt-in, toolbar idempotence.
- node dev/test_ui.cjs: Edge/Chromium headless, Scan/Apply/Quick Fix, stale scope/model, font notices, preset confirmation, Units opt-in, light/dark, 550×740 và 440×540.
- python dev/package.py: whitelist runtime, CRC, đối chiếu source/RBZ và SHA256.

Dependency Ruby ở ../TPlus_Cabinet_Codex_Handoff_2026-10-01/cabinet_dev/node_modules theo lockfile; UI test dùng Playwright từ CODEX_PRIMARY_RUNTIME_NODE_MODULES, tùy chọn TPLUS_BROWSER_PATH.

Chưa kiểm chứng trực tiếp trong SketchUp cho bản 2.0: Model Info, Undo/Redo, Save/Open, actual shared definition isolation, locked editing, fonts của Text#font= mới và liên kết sau Stretch. dev/native_smoke.rb là bài thử chủ động chỉ trong model mới trống.
