# Trạng thái yêu cầu — 2.0.0-beta.1 · 2026-10-02

Bản beta hiện là bộ quản lý/chuẩn định dạng native; **chưa đạt mục tiêu một nút chuẩn toàn bộ font/cỡ chữ trên SketchUp 2022**. Không coi một preset đã lưu là font native đã được thay đổi.

| Nhóm yêu cầu | Trạng thái hiện tại |
|---|---|
| Dimension/Text/Label riêng | Đã có; Label là Text#has_leader? |
| SCAN + số lượng nested | Đã có; chỉ đọc, đếm theo vị trí đặt và số entity độc lập |
| Selected / Current Context / Entire Model | Đã có; giữ phạm vi ở definition chia sẻ |
| Nested / Components / Hidden / Locked | Đã có; khóa mở tạm và phục hồi, trạng thái ẩn giữ nguyên |
| Apply riêng ba loại / Normalize cả ba | Đã có cho các thuộc tính native hỗ trợ; báo font còn chờ |
| Quick Fix bốn loại | Đã có; Entire Model, dùng bộ lọc hiện tại |
| Save / Load / Update / Delete Preset | Đã có; preset lưu mục tiêu font/size và format, không lưu scope/quyền đổi Units |
| Màu Dimension / Text / Label | Đã có; màu dim dùng material chung cho chữ/đường, chưa tách hai màu riêng |
| Đầu arrow | Đã có cho Dimension và Label |
| Hướng/vị trí chữ dim | Đã có Aligned/Screen và Above/Center/Outside cho dim thẳng; không move điểm đo/offset |
| Leader View/Model, hiện/ẩn | Đã có, giữ nội dung và điểm gắn |
| Units mm/cm/m/inch/current + precision + show unit | Đã có qua UnitsOptions toàn model; chỉ chạy khi checkbox được bật và action gồm Dimension |
| Font/size native Dimension | Ruby API chưa có setter; cần Model Info, không tự áp từ preset |
| Font/size native Text/Label SU2022 | Chưa có setter; cần Model Info |
| Text/Label font native pt nguyên khi Text#font= tồn tại | Có nhánh API công khai có kiểm tra khả năng; API từ SU2026.2, chưa thử native |
| Height mm, font size pt lẻ | Lưu mục tiêu preset; chưa áp tự động; không giả đổi mm sang pt |
| Cỡ đầu arrow | Chưa hỗ trợ; control disabled |
| Chữ cách đường dim | Chưa hỗ trợ; control disabled; không dùng offset_vector để giả làm khoảng cách chữ |
| Căn chỉnh Text | Chưa có setter; giữ native |
| Nội dung, điểm đo, vị trí, geometry/tag | Không bị chỉnh trong Normalize; không explode/xóa/dựng mesh |
| Annotation mesh beta 2 | Báo riêng và bỏ qua; không tự phục hồi/xóa trong Normalize |
| Một Undo | Một start_operation/commit cho Apply hoặc Quick Fix; lỗi abort. Model Info thủ công riêng |
| Kiểm thử native, Undo/Save/Open | Chưa xác nhận; fixture và browser chỉ kiểm tra mô phỏng/giao diện |

Tài liệu API chính thức đã đối chiếu:

- https://ruby.sketchup.com/Sketchup/Dimension.html
- https://ruby.sketchup.com/Sketchup/DimensionLinear.html
- https://ruby.sketchup.com/Sketchup/Text.html
- https://ruby.sketchup.com/Sketchup/OptionsProvider.html
- https://ruby.sketchup.com/UI.html#show_model_info-class_method

Giới hạn giữ đúng thiết kế “nội dung + vị trí → chỉ format”. Không dùng các attribute tự đặt, mesh chữ hoặc phép quy đổi pt/mm để giả rằng font/height native đã được Normalize.
