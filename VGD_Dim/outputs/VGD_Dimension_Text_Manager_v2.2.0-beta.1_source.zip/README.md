# VGD Dimension & Text Manager · 2.2.0-beta.1

Một trang theo style T+ Cabinet, chỉ xử lý Dim/Text được chọn. Cabinet giữ nguyên.

1. Chọn trực tiếp Dimension, Text hoặc Label trong model. Nếu ở trong group, mở group rồi chọn Dim/Text. Chọn cả group/component không áp vào nội dung bên trong.
2. Chọn màu Dim/Text và Endpoint riêng cho Dimension/Label. Mặc định Endpoint giữ nguyên; có None, Slash, Dot, Closed Arrow và Open Arrow.
3. APPLY áp đúng các annotation đang chọn, đưa Dimension vào tag **000 DIM**, Text/Label vào **000 TEXT**. Không có hộp thông báo hoàn tất. Lỗi hiện ngay trong cửa sổ.
4. Font/cỡ chữ: chọn riêng các Dim hoặc riêng Text/Label, bấm **Chỉnh font & cỡ chữ của vùng chọn**. Plugin mở **Entity Info**; bấm **Font** và chỉnh cỡ chữ pt trong hộp native.
5. Với Dim cần chiều cao theo mm: chọn riêng Dim, bấm **Chỉnh chiều cao chữ Dim**, rồi trong Entity Info → Font chọn **Height** và nhập kèm đơn vị, ví dụ 3 mm.

**APPLY chưa tự đổi font, cỡ chữ hay Height trên SketchUp 2022.** Ruby API của SU2022 chưa có các setter này. Bản này thay các ô nhập không có tác dụng bằng lối mở Entity Info để chỉnh thật trên đúng vùng chọn. Không quy đổi Height sang pt và không dựng chữ bằng edge/mesh. Thao tác Font native là thao tác riêng của SketchUp.

APPLY có một operation/Undo, giữ nội dung, điểm đo, vị trí, hướng chữ, trạng thái ẩn/khóa, hình học và selection. Không đổi UnitsOptions hoặc font mặc định toàn model. Màu cũ dùng chung với đối tượng ngoài selection không bị ghi lại.

Nếu đang edit một definition có nhiều bản copy, plugin dừng trước khi sửa. Make Unique bản cần chỉnh rồi chọn lại để giữ nguyên các bản còn lại.

## Cài / nạp

RBZ: outputs/VGD_Dimension_Text_Manager_v2.2.0-beta.1.rbz.

Máy nhà: dev/deploy.ps1 chỉ cài 9 file VGD vào SketchUp 2022, backup, kiểm tra SHA256 và có rollback. Giữ cơ chế sao lưu/gỡ loader T+ Dim cũ khi chuyển thương hiệu; không đổi Cabinet/plugin khác.

Trong SketchUp đang chạy: **Extensions → Nạp lại VGD Dim/Text**. Nếu cài lần đầu, restart SketchUp. Ruby Console cũng có thể nạp:

```ruby
load File.join(Sketchup.find_support_file('Plugins'), 'VGD_Dim', 'reload.rb')
```

## Kiểm tra

- dev/check_ruby.cjs: cú pháp Ruby, selection-only, tag, endpoint, material isolation, bảo toàn geometry/Units/selection, guard context và abort; callback không popup, Font/Height qua inspector.
- dev/test_ui.cjs: màu/endpoint, tag chính xác, Font/Height native callbacks, lỗi inline và footer; không còn size giả, Units hoặc Deep Scan toàn model.
- dev/test_deploy.py: bộ cài trong APPDATA mô phỏng; backup/retire loader cũ, SHA nội dung, cài lặp và giữ nguyên Cabinet.
- dev/native_smoke.rb: chỉ chạy thủ công trong model thử trống, không chạy trên model đang làm.
- outputs/VALIDATION.json ghi rõ các kiểm tra đã chạy. Chưa thực hiện Apply/Undo/Font/Height/save/reopen thực tế trong SketchUp.

Tài liệu chính thức: [Dimension/Text/Height qua Entity Info](https://help.sketchup.com/en/sketchup/adding-text-labels-and-dimensions-model), [UI.show_inspector hỗ trợ EntityInfo từ SU2022](https://ruby.sketchup.com/UI.html#show_inspector-class_method), [Text font= từ SU2026.2](https://ruby.sketchup.com/Sketchup/Text.html#font=-instance_method).
