# VGD Dimension & Text Manager

Yêu cầu hiện tại ngày 2026-10-02 thay thế mẫu quét toàn model: chỉ Dim/Text được chọn, endpoint Dim/Label, tag 000 DIM/000 TEXT, không hộp thông báo hoàn tất.

- Giữ loader vgd_dim.rb, namespace VGD::Dim và thư mục VGD_Dim. Không đổi Cabinet.
- Style T+ Cabinet: nền sáng, header tối, nâu đồng #B48963, Segoe UI/Inter; một trang và APPLY ở footer.
- APPLY chỉ lấy Dimension/Text trực tiếp trong model.selection tại thời điểm bấm. Không quét Group/Component hay toàn model. Không có đối tượng phù hợp thì không ghi model.
- Dim vào 000 DIM; Text/Label vào 000 TEXT. Màu và endpoint áp bằng setter native trong một operation; lỗi abort.
- Không đổi UnitsOptions/model defaults vì có thể ảnh hưởng dim ngoài vùng chọn. Giữ nội dung, điểm đo, vị trí, hướng chữ, hình học, trạng thái ẩn/khóa và selection.
- Trong context definition chia sẻ, chặn thao tác trước mutation; không âm thầm đổi các bản copy ngoài vùng chọn.
- Trên SU2022 không có setter font/size/Height của Dim/Text. Dùng UI.show_inspector('EntityInfo') để người dùng chỉnh Font trên đúng selection. Height của Dim là chế độ native, không quy đổi mm sang pt.
- Không tạo ô nhập font/size/Height giả vờ APPLY được trên SU2022; không dùng edge/mesh, save/reimport model hoặc API bộ nhớ nội bộ.
- APPLY thành công im lặng; lỗi hiện inline trong dialog hoặc status bar, không UI.messagebox.
- Chỉ deploy whitelist của dev/deploy.ps1 vào SU2022; sao lưu và SHA256. Phân biệt fixture/UI với kiểm thử native.
