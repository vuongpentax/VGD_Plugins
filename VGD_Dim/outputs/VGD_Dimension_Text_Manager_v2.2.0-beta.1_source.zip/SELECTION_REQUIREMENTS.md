# Yêu cầu hiện tại · 2026-10-02

- Cỡ chữ phải thay đổi thật, không chỉ lưu giá trị trên giao diện.
- Thêm Height chữ, phân biệt Height mm native với cỡ pt.
- Chỉnh Endpoint riêng cho Dimension và Label.
- Sau APPLY, Dimension vào tag 000 DIM; Text/Label vào 000 TEXT.
- Chỉ xử lý các Dim/Text được chọn.
- Không hộp thông báo khi hoàn tất.
- Giữ thương hiệu VGD và style T+; chỉ sửa Dim/Text, Cabinet giữ nguyên.

Thiết kế thực hiện ở SU2022: màu/endpoint/tag qua APPLY; Font/Size/Height qua Entity Info của vùng chọn. Font/Height tự động từ ô nhập vẫn chưa có vì Ruby API không hỗ trợ. Không báo đã hoàn thành phần tự động này.
