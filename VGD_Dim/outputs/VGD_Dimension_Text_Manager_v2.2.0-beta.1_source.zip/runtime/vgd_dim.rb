# encoding: UTF-8
require 'sketchup.rb'
require 'extensions.rb'
module VGD
  module Dim
    VERSION = '2.2.0-beta.1'.freeze unless const_defined?(:VERSION)
    unless file_loaded?(__FILE__)
      extension = SketchupExtension.new('VGD Dimension & Text Manager', 'VGD_Dim/main')
      extension.description = 'Chỉnh màu, endpoint và tag cho Dim/Text đang chọn; Font/Size/Height qua Entity Info native. APPLY không có thông báo hoàn tất.'
      extension.version = VERSION
      extension.creator = 'VGD'
      Sketchup.register_extension(extension, true)
      file_loaded(__FILE__)
    end
  end
end
