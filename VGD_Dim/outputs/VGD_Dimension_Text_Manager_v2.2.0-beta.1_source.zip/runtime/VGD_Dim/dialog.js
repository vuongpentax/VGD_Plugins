'use strict';
const field = id => document.getElementById(id);
window.VGDForm = {
  error(message) { field('error').textContent = message; field('error').hidden = false; },
  clearError() { field('error').hidden = true; field('error').textContent = ''; }
};
field('settings').addEventListener('submit', event => {
  event.preventDefault();
  VGDForm.clearError();
  sketchup.apply(JSON.stringify({
    dim_color: field('dim_color').value, text_color: field('text_color').value,
    dim_endpoint: field('dim_endpoint').value, label_endpoint: field('label_endpoint').value
  }));
});
field('font').addEventListener('click', () => { VGDForm.clearError(); sketchup.font(); });
field('height').addEventListener('click', () => { VGDForm.clearError(); sketchup.height(); });
field('cancel').addEventListener('click', () => sketchup.cancel());
