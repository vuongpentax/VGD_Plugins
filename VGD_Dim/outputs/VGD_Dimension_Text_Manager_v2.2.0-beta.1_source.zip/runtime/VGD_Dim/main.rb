# encoding: UTF-8
require 'sketchup.rb'
require 'json'
require_relative 'defaults'
require_relative 'engine'
module VGD
  module Dim
    extend self
    def show_error(message)
      if @dialog
        @dialog.execute_script("VGDForm.error(#{JSON.generate(message)});")
      else
        Sketchup.status_text = message
      end
    end
    def apply_payload(payload)
      Engine.apply(Sketchup.active_model, JSON.parse(payload))
      # Deliberately silent: no completion popup or extra dismiss action.
    rescue StandardError => error
      show_error(error.message)
      puts "[VGD Dim/Text] #{error.class}: #{error.message}"
    end
    def open_font(height = false)
      model = Sketchup.active_model
      targets = Engine.selected(model)
      raise ArgumentError, 'Chọn Dim hoặc Text trước khi chỉnh font.' if targets.empty?
      Engine.check_context(model)
      dimensions = targets.count { |entity| entity.is_a?(Sketchup::Dimension) }
      if targets.length != model.selection.length || (dimensions > 0 && dimensions != targets.length)
        raise ArgumentError, 'Để chỉnh font, chọn riêng các Dim hoặc riêng Text/Label, không chọn kèm hình học.'
      end
      if height && dimensions != targets.length
        raise ArgumentError, 'Height (mm) dành cho Dim. Chọn riêng Dim rồi mở Font → Height.'
      end
      raise 'Mở Window → Default Tray → Entity Info, rồi nhấn Font.' unless UI.show_inspector('EntityInfo')
      Sketchup.focus
    rescue StandardError => error
      show_error(error.message)
    end
    def reload_extension
      load File.join(__dir__, 'reload.rb')
    end
    def show_dialog
      if @dialog && @dialog.visible?
        @dialog.bring_to_front
        return
      end
      dialog = UI::HtmlDialog.new(dialog_title: 'VGD Dimension & Text Manager',
        preferences_key: 'VGDDimTextManager', scrollable: true, resizable: false,
        width: 560, height: 650, style: UI::HtmlDialog::STYLE_DIALOG)
      @dialog = dialog
      dialog.set_file(File.join(__dir__, 'dialog.html'))
      dialog.add_action_callback('apply') { |_, payload| apply_payload(payload) }
      dialog.add_action_callback('font') { open_font }
      dialog.add_action_callback('height') { open_font(true) }
      dialog.add_action_callback('cancel') { dialog.close }
      dialog.set_on_closed { @dialog = nil if @dialog.equal?(dialog) }
      dialog.show
    end
    unless @command
      @command = UI::Command.new('VGD Dimension & Text Manager') { show_dialog }
      @command.small_icon = @command.large_icon = File.join(__dir__, 'dim.svg')
      UI.menu('Extensions').add_item(@command) unless file_loaded?(__FILE__)
      @toolbar ||= UI::Toolbar.new('VGD Dimension & Text Manager')
      @toolbar.add_item(@command)
      UI.menu('Extensions').add_item('Hiện toolbar VGD Dim/Text') { @toolbar.show }
      UI.menu('Extensions').add_item('Nạp lại VGD Dim/Text') { reload_extension }
      file_loaded(__FILE__)
    end
    @command.tooltip = 'VGD Dimension & Text Manager'
    @command.status_bar_text = 'Chỉ Dim/Text đang chọn: màu, endpoint và tag 000 DIM / 000 TEXT.'
  end
end
