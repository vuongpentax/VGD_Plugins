# Trạng thái · 2.2.0-beta.1

| Yêu cầu mới | Kết quả |
|---|---|
| Chỉ Dim/Text được chọn | Có; lấy trực tiếp model.selection, không quét nội dung group/component |
| Endpoint Dim và Label | Có; Keep/None/Slash/Dot/Closed/Open. Text không leader giữ endpoint cũ |
| Tag sau APPLY | Dim → 000 DIM; Text/Label → 000 TEXT |
| Không thông báo hoàn tất | Có; APPLY im lặng. Lỗi inline/status bar, không messagebox |
| Font/cỡ chữ SU2022 | Chưa tự áp từ Ruby. Có nút mở Entity Info → Font cho selection |
| Height chữ Dim (mm) | Chế độ Height native trong Entity Info → Font; chưa setter tự động trong plugin |
| mm → pt | Đã bỏ; Height native không phải cỡ pt quy đổi |
| Units/model font defaults | Không đổi trong APPLY, tránh ảnh hưởng annotation ngoài selection |
| Nội dung/vị trí/hướng/geometry | Giữ nguyên; tag thay theo yêu cầu |
| Definition chia sẻ | Guard trước mutation; cần Make Unique bản cần sửa |
| Kiểm thử | Ruby fixture và UI đạt; native Apply/Font/Height/Undo/save-reopen chưa chạy |

Phiên làm việc đọc được cây accessibility của SU2022 nhưng chụp/input UI lỗi “window capture timed out / coordinate input geometry is unavailable”. Không coi việc đọc được UI là xác nhận chức năng thay font native đã hoạt động.

API: [Dimension](https://ruby.sketchup.com/Sketchup/Dimension.html), [Text](https://ruby.sketchup.com/Sketchup/Text.html), [Entity Info](https://ruby.sketchup.com/UI.html#show_inspector-class_method), [hướng dẫn Font/Height](https://help.sketchup.com/en/sketchup/adding-text-labels-and-dimensions-model).
