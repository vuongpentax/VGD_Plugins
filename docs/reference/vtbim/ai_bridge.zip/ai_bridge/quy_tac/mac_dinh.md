Cách dùng lệnh VTBIM khi dựng (quy tắc kích thước / bố trí: phần KINH NGHIỆM VẼ bên dưới).

## Đơn vị, tầng
- Mọi kích thước là mm. Toạ độ mặt bằng [x, y], X sang phải, Y lên trên.
- Mỗi cấu kiện thuộc 1 tầng. Dựng tầng dưới trước rồi đến tầng trên; tường, cột mặc định cao tới tầng kế trên.

## Trục, cột
- KHÔNG vẽ trục bằng tay (create_grid). Đặt cột (create_columns) / tường bao trước, rồi gọi auto_grid: code tạo trục theo tim cột và tự tính chiều dài trục. Sửa cột -> gọi lại auto_grid.

## Tường
- Tường bao theo mặt ngoài: create_walls reference_line = "left" (đi chiều kim đồng hồ). Tường ngăn theo tim: reference_line = "center".
- Vẽ tường thành chuỗi điểm liền (create_walls nhiều điểm, closed = true cho vòng kín) để góc tự nối.

## Sàn
- create_slab luôn truyền thickness_mm (mặc định T5) trừ khi người dùng / bộ quy tắc nói khác.
- Sàn hạ (T6): tạo Zone đúng tên rồi bước Lập hồ sơ > Kiểm tra sàn hạ (hỏi người dùng trước). Tự dựng thì create_slab riêng phòng đó với top_offset_mm = -50 và khoét lỗ sàn chính.

## Vệ sinh
- Thiết bị (W5) đặt ở bước dựng: layout_wc (theo W1) rồi sửa bằng place_fixture / update_element.

## Cầu thang
- Vẽ thang ĐÚNG QUY TRÌNH công cụ Stair bằng create_stair: vẽ mặt bằng thang bằng nét 2D (line / pline) - mỗi bậc và chiếu nghỉ là 1 hình khép kín - gom Group, chọn Group bằng Stair rồi bấm bậc đầu tiên. KHÔNG dựng khối thang 3D (facade_build stair).

## Cửa
- Cửa đi / cửa sổ luôn thuộc 1 tường, tâm cửa nằm trên trục tường (place_opening). Không đặt cửa trùm qua giao tường.
- place_opening tự dời cửa khỏi cột (C10) và báo note.
- Chiều mở cửa (C1): place_opening truyền swing_to = 1 điểm trong phòng mà cánh mở vào (cửa phòng: điểm trong phòng; cửa WC: điểm trong WC; cửa chính: điểm trong nhà). Code tự tính phía mở theo hướng vẽ tường.

## Bản vẽ
- Mặt cắt / mặt đứng: đường cắt là 1 đoạn thẳng; hướng nhìn về phía cần thấy.
- Cốt cao độ dùng add_annotation type dim_level (không vẽ chữ tay).
- Số kích thước, cốt, tên trục dùng kiểu chữ "Ký hiệu số" (tự động). Nét chỉ dùng Pen + kiểu nét, không đặt màu riêng.

## Cách làm việc
- Trước khi dựng lớn: tóm tắt phương án (trục, tường, cửa...) cho người dùng.
- Sau mỗi nhóm việc: screenshot_plan hoặc screenshot_3d để tự kiểm tra, sai thì undo rồi làm lại.
- Không xoá / ghi đè thứ người dùng đã vẽ nếu họ không yêu cầu.
