Quy tắc vẽ NHÀ CÔNG NGHIỆP / NHÀ XƯỞNG (file mẫu - sửa theo thói quen của bạn).

- Lưới cột bước 6000, nhịp 18000-24000 (khung thép tiền chế).
- Cột thép thể hiện bằng cột chữ nhật 400x600 (đến khi có cột thép hình).
- Tường bao xây cao 1200-2000, phía trên tôn; tường bao gạch 220.
- Chiều cao đỉnh cột 7000-9000.
- Mái tôn dốc 10-15 %, đầu hồi 2 đầu theo phương nhịp (gable_edges cạnh ngắn).
- Cửa xe 4000x4500 trên trục biên; cửa đi thoát hiểm 1200 mở ra ngoài, cách nhau không quá 50 m.
- Sàn nền bê tông dày 200.
- Khu văn phòng / WC dùng quy tắc nhà ở.
