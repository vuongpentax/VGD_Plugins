Quy tắc vẽ NHÀ Ở (file mẫu - sửa theo thói quen của bạn, mỗi dòng 1 quy tắc).

- Chiều cao tầng 3300 (tầng 1 có thể 3600).
- Tường bao 220, tường ngăn 110; tường WC 110.
- Lưới trục bước 3300-4500, nhịp 3600-5000.
- Cột 220x220 tại giao trục; dầm 220x300.
- Sàn dày 120 (nhà phố), mặt sàn WC thấp hơn 50.
- Cửa chính >= 2400 hai cánh mở vào; cửa phòng ngủ 900 mở vào phòng, cửa WC 800 mở vào WC.
- Cửa sổ 1200-1600, cao bậu 900; WC cửa sổ 600x600 cao bậu 1600.
- Phòng: ghi tên + diện tích (create_zone) cho mọi phòng.
- Mặt bằng mỗi tầng ghi 2 lớp kích thước: lớp trục và lớp tổng.
- Lập hồ sơ: gọi docset_status -> phòng chưa duyệt vật liệu thì hỏi người dùng (docset_set_finish) hoặc docset_open_dialog -> docset_build -> docset_check -> viết thuyết minh / ghi chú chung từ project_summary. Không tự vẽ kích thước / mặt cắt / tờ khi docset_build làm được.
