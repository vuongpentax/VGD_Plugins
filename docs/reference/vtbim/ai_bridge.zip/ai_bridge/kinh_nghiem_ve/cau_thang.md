# Cầu thang

### R1 Bậc [DUYỆT]
- Chiều cao bậc = chiều cao tầng / (số mặt bậc + 1). Bậc ~170, chấp nhận 150–190.
- Số bậc cao lẻ, tốt nhất 4n+1 (17 / 21 / 25; 19 được).

### R2 Cấu tạo thang BTCT [DUYỆT]
- Bản thang BTCT đổ liền (dày 150) + bậc xây gạch trên bản + mặt bậc, mũi bậc, cổ bậc ốp đá.
- Thang gác lên dầm: dầm chiếu nghỉ dưới mép chiếu nghỉ nối vế, dầm chiếu tới dưới mép sàn tầng trên (220 x 450).
