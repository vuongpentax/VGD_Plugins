# Nội thất

### I1 Kích thước phòng ngủ [DUYỆT]
- Phòng ngủ cơ bản 3000 x 4000.
- Giường 1600 x 2000 + 2 tab 500 x 500 đầu giường. Bàn phấn 800 x 500. Tủ áo sâu 600, dài 2000 hoặc hết tường.
