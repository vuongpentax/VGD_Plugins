# Zone (phòng)

### Z1 Mỗi phòng 1 Zone, đúng loại [ĐỀ XUẤT]
- Mọi không gian có Zone: phòng, WC, sảnh, hành lang, thang, ban công, lô gia, hiên, sân phơi.
- Đặt đúng tên + loại: hồ sơ dựa vào loại để hạ sàn (T6), lát, trần, rải đèn, triển khai WC.
