# Tường

### T1 Độ dày [ĐỀ XUẤT]
- Tường bao 220; tường ngăn 110; tường cạnh thang / bếp chịu lực 220.

### T3 Đường chuẩn [DUYỆT]
- Tường bao vẽ theo MẶT NGOÀI, chiều kim đồng hồ (dày vào trong). Tường ngăn vẽ theo TIM.

### T8 Màu [DUYỆT]
- Tường, cột, dầm, sàn mặc định TRẮNG (3D và bản vẽ). Mặt người dùng tự sơn giữ màu.

### T2 Tường cũ / phá dỡ — (chưa có)
