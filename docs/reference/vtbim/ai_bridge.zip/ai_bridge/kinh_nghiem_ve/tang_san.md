# Tầng, sàn

### T7 Tên tầng [DUYỆT]
- Tầng ±0.000 = FL1, rồi FL2, FL3... tới mái. Cốt sân = GROUND FLOOR.

### S4 Cao độ tầng (nhà ở) [DUYỆT]
- ±0.000 = sàn hoàn thiện FL1. Sân −450.
- FL1 cao 3900; FL2 trở lên cao 3300.

### T5 Sàn dày [DUYỆT]
- Mặc định 120, trừ khi người dùng chỉ định.

### T6 Hạ sàn [DUYỆT]
- WC, ban công, lô gia, hiên, sân phơi hạ 50 so với sàn tầng (sàn 3D hạ theo).
