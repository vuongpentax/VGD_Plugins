# Cửa

### C1 Hướng mở [DUYỆT]
- Cửa phòng mở VÀO phòng; cửa WC mở VÀO WC.
- Bản lề phía tường gần: mở 90° thì cánh áp SÁT tường.
- [ĐỀ XUẤT] Cửa chính mở vào nhà.

### C12 Vị trí cửa phòng / WC [DUYỆT]
- Mép ô cửa cách tường vuông góc gần nhất 100.

### C2 Kích thước thường dùng [DUYỆT]
- Cửa chính >= 2400, 2 cánh. Cửa phòng: gỗ 900x2200. Cửa WC: nhôm kính mờ 800x2200. Cửa sổ rộng 1200–1600.
- Cửa đi 1 cánh rộng tối đa 1200; rộng hơn → 2 cánh.

### C10 Không đè cột [DUYỆT]
- Mép khuôn cửa cách mép cột ≥ 100. Cửa sát góc có cột → dời ra.
