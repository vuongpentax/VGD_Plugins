# Cột

### L2 Bố trí cột [DUYỆT]
- Lưới đều. Nhịp BTCT kinh tế 6–9 m; nhà ở / nhà phố 3,3–5 m. Ít loại nhịp.
- Cột thẳng hàng từ móng tới mái (không cột chuyển).
- Cột trong tường hoặc góc phòng; không giữa lối đi, chỗ đỗ xe, giữa cửa.
- Không vẽ trục, dầm: bước 2 (lập hồ sơ) tự tạo theo cột.
