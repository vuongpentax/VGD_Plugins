# KINH NGHIỆM VẼ — BƯỚC 1: DỰNG MÔ HÌNH

Một nơi duy nhất: đóng gói theo plugin, lệnh MCP `get_rules` gửi nguyên các nhánh cho AI dựng mô hình (không có bản sao). Dùng khi AI dựng: tầng, tường, cột, sàn, móng, mái, thang, cửa, Zone, thiết bị vệ sinh, nội thất. Đọc file này, rồi CHỈ mở nhánh cần.
KHÔNG vẽ ở bước này: trục, dầm, dim, chữ, cốt, tag, ký hiệu, bảng → Bước 2 lập hồ sơ tự làm (`docs/ai/quy_tac_ho_so/`).

## Áp dụng
- [DUYỆT] = bắt buộc. [ĐỀ XUẤT] = dùng khi không có yêu cầu khác, nhắc người dùng duyệt. (chưa có) = hỏi người dùng, không tự đoán.
- Ưu tiên: yêu cầu lần giao việc (kể cả ảnh / DWG mẫu) > [DUYỆT] > [ĐỀ XUẤT]. Đơn vị mm.

## Nhánh

| File | Tiền tố | Đọc khi dựng |
|---|---|---|
| `tang_san.md` | F | tầng, cao độ, sàn, hạ sàn |
| `tuong.md` | T | tường: dày, đường chuẩn, màu |
| `cot.md` | L | cột |
| `cua.md` | C | cửa: hướng mở, kích thước, vị trí |
| `zone.md` | Z | Zone phòng |
| `mai.md` | M | mái |
| `cau_thang.md` | R | cầu thang |
| `wc.md` | W | thiết bị vệ sinh |
| `noi_that.md` | I | nội thất |
| `tong_the.md` | Y | sân vườn, tổng thể |

Chưa có nhánh: móng, trần (trần do bước 2 tự dựng).

## Thêm / sửa quy tắc
- Chỉ ghi quy tắc DỰNG mô hình. Thể hiện bản vẽ (dim, chữ, nét, ký hiệu, tờ) → `quy_tac_ho_so/`. Một quy tắc chỉ nằm 1 nơi.
- Đặt vào đúng nhánh. Chưa có nhánh → tạo file mới + thêm 1 dòng bảng trên.
- Mã mới = tiền tố nhánh + số tiếp theo; mã cũ giữ nguyên. Tìm mã: `grep -rn "### C2" vtbim/ai_bridge/kinh_nghiem_ve docs/ai/quy_tac_ho_so`.
- Mẫu: `### <Mã> <Tên> [DUYỆT | ĐỀ XUẤT]` + gạch đầu dòng ngắn, số cụ thể.
- KHÔNG ghi: nguồn / ngày / mã I, tên hàm / file code, thao tác phần mềm (phím, nút, menu).
- Góp ý mới cùng chủ đề → sửa thẳng quy tắc cũ. Quy tắc bị thay → xoá (git giữ).
