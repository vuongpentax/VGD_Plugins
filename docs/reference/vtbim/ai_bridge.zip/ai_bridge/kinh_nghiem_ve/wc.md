# WC

### W5 Phạm vi bước 1 [DUYỆT]
- AI đặt: bệ xí, lavabo (kèm gương), sen tắm, tiểu nam / nữ, bồn tắm, máy giặt, vách kính.
- KHÔNG đặt: phễu thu, đèn, quạt hút, thăm trần, trần, lát ốp → bước 2 tự làm.

### W1 Bố trí [DUYỆT]
- WC dọc cơ bản 1400 x 2700, cửa ở đầu ngắn. Dọc 1 tường dài, từ phía cửa: lavabo bàn đá 800 → bệ xí 900 → khu tắm ~1000.
- Vách kính chừa cửa 600 (550) sát tường kia. Vòi sen ở tường cuối, áp sát tường.
- Thiết bị đặt sát MẶT TRONG tường, không ăn vào tường.
- Sàn hạ 50 (T6). Cửa: C1, C12.
