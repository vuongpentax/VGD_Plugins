# VTBIM MCP bridge (I447): MCP stdio <-> HTTP 127.0.0.1 (SketchUp, Extensions > VTBIM > Ket noi AI).
# Claude Desktop / Codex start this script. Port + token: %APPDATA%\VTBIM\ai_bridge.json (written by SketchUp).
# Keep this file ASCII only (Windows PowerShell 5.1 reads BOM-less scripts as ANSI).
# stdout = MCP messages only (1 JSON per line). Errors -> stderr.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::Expect100Continue = $false
$utf8 = New-Object System.Text.UTF8Encoding($false)
$stdin = New-Object System.IO.StreamReader([Console]::OpenStandardInput(), $utf8)
$stdout = New-Object System.IO.StreamWriter([Console]::OpenStandardOutput(), $utf8)
$stdout.AutoFlush = $true
$cfgPath = Join-Path $env:APPDATA 'VTBIM\ai_bridge.json'
$script:down = $false

function Send([string]$json) { $stdout.WriteLine($json) }

function Post([string]$body) {
  $cfg = [IO.File]::ReadAllText($cfgPath, $utf8) | ConvertFrom-Json
  $req = [Net.HttpWebRequest]::Create("http://127.0.0.1:$($cfg.port)/mcp")
  $req.Method = 'POST'
  $req.ContentType = 'application/json'
  $req.Accept = 'application/json, text/event-stream'
  $req.Headers.Add('Authorization', 'Bearer ' + $cfg.token)
  $req.Timeout = 600000
  $req.ReadWriteTimeout = 600000
  $req.KeepAlive = $false
  $req.Proxy = $null
  $bytes = $utf8.GetBytes($body)
  $req.ContentLength = $bytes.Length
  $s = $req.GetRequestStream()
  $s.Write($bytes, 0, $bytes.Length)
  $s.Close()
  $resp = $req.GetResponse()
  try {
    $r = New-Object System.IO.StreamReader($resp.GetResponseStream(), $utf8)
    return $r.ReadToEnd()
  } finally { $resp.Close() }
}

function Down-Reply($msg, [string]$err) {
  if ($null -eq $msg.id) { return }
  $id = ConvertTo-Json $msg.id -Compress
  $m = [string]$msg.method
  $hint = 'VTBIM chua ket noi: nguoi dung can mo SketchUp, Extensions > VTBIM > Ket noi AI (MCP) > Bat/tat (bat), roi goi lai.'
  if ($m -eq 'initialize') {
    $pv = [string]$msg.params.protocolVersion
    if (-not $pv) { $pv = '2025-06-18' }
    Send ('{"jsonrpc":"2.0","id":' + $id + ',"result":{"protocolVersion":' + (ConvertTo-Json $pv) +
      ',"capabilities":{"tools":{"listChanged":true}},"serverInfo":{"name":"vtbim","version":"bridge"},"instructions":' + (ConvertTo-Json $hint) + '}}')
  } elseif ($m -eq 'tools/list') {
    Send ('{"jsonrpc":"2.0","id":' + $id + ',"result":{"tools":[{"name":"vtbim_info","description":' + (ConvertTo-Json ('Kiem tra ket noi VTBIM. ' + $hint)) +
      ',"inputSchema":{"type":"object","properties":{}}}]}}')
  } elseif ($m -eq 'tools/call') {
    Send ('{"jsonrpc":"2.0","id":' + $id + ',"result":{"content":[{"type":"text","text":' + (ConvertTo-Json ($hint + ' (' + $err + ')')) + '}],"isError":true}}')
  } elseif ($m -eq 'ping') {
    Send ('{"jsonrpc":"2.0","id":' + $id + ',"result":{}}')
  } else {
    Send ('{"jsonrpc":"2.0","id":' + $id + ',"error":{"code":-32000,"message":' + (ConvertTo-Json ($hint + ' (' + $err + ')')) + '}}')
  }
}

while ($true) {
  $line = $stdin.ReadLine()
  if ($null -eq $line) { break }
  if ($line.Trim() -eq '') { continue }
  try {
    $resp = Post $line
    if ($script:down) {
      $script:down = $false
      Send '{"jsonrpc":"2.0","method":"notifications/tools/list_changed"}'
    }
    $resp = $resp.Trim()
    if ($resp -ne '') { Send $resp }
  } catch {
    $err = $_.Exception.Message
    [Console]::Error.WriteLine('vtbim_mcp: ' + $err)
    $script:down = $true
    try { $msg = $line | ConvertFrom-Json } catch { continue }
    Down-Reply $msg $err
  }
}
