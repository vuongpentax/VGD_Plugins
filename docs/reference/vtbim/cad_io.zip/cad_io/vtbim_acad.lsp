;; VTBIM -> AutoCAD (I454). Nap 1 lan: APPLOAD (hoac them vao Startup Suite) file nay.
;; Trong VTBIM: chon 2D tren cua so Plan -> chuot phai > Copy sang AutoCAD.
;; Trong AutoCAD: go VTPASTE -> bam diem chen (= goc duoi-trai vung da chon ben VTBIM).
(defun vtbim:clipfile (/ txt h f)
  (setq txt (strcat (getenv "APPDATA") "\\VTBIM\\clip\\last.txt"))
  (if (findfile txt)
    (progn (setq h (open txt "r") f (read-line h)) (close h)))
  (if (and f (findfile f)) f nil))

(defun c:VTPASTE (/ f p ce)
  (setq f (vtbim:clipfile))
  (if (not f)
    (princ "\nVTBIM: chua co ban copy (VTBIM: chuot phai > Copy sang AutoCAD).")
    (progn
      (setq p (getpoint "\nVTBIM - diem chen (goc duoi-trai): "))
      (if p
        (progn
          (setq ce (getvar "CMDECHO"))
          (setvar "CMDECHO" 0)
          (command "_.-INSERT" (strcat "*" f) p "1" "0")
          (setvar "CMDECHO" ce)
          (princ "\nVTBIM: da chen.")))))
  (princ))

(princ "\nVTBIM: lenh VTPASTE da nap.")
(princ)
